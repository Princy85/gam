<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>OUTILS STANDARD MAINTENANCE</title>
  </head>  

  <img src="jb2.jpg" style="width:30px; height:30px;" alt="jb" class="float-start">
                
  <h2 class="fw-bolder" style="display:flex; justify-content:center; margin-top:0%; color:#212529">Audit Outils Maintenances</h2>


<body style="background-color:lightskygreen;">

  
<form class="row" method="POST" action="Envoie.php">

   
          <p class="bg-light border border-3 border-danger">
                           
          <div id="liste" >

                  <div class="input-group mb-3">                                                                  
                          <span class="input-group-text">UAP:</span>                                
                          <select id="uap" class="form-select" name="UAP" style="margin-top: 0%;" required>            
                          <option value="1">Choisir</option> 
                          </select> 
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">Auditeur: </span>                                      
                          <input id="services" class="form-select" name="Auditeur"> 
                              
                  </div>

                  <div class="input-group mb-3">
                                <span class="input-group-text">TDM:</span>                 
                                <input id="services" class="form-select" name="TDM">                                
                               
                  </div>   
                  <div class="input-group mb-3">
                          <span class="input-group-text">OT TDM: </span>                   
                          <select class="form-select" name="OT_TDM">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                          </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                                                              
                            <input class="form-select" name="Observation1" placeholder="Observation">                                
                  </div>

                  <div class="input-group mb-3">
                          <span class="input-group-text">TDL RM: </span>                   
                          <select class="form-select" name="TDL_RM">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">              
                            <input class="form-select" name="Observation2" placeholder="Observation">                             
                  </div>

                  <div class="input-group mb-3">
                          <span class="input-group-text">GAM: </span>                   
                          <select class="form-select" name="GAM">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                
                            <input class="form-select" name="Observation3" placeholder="Observation">                              
                  </div>

                  <div class="input-group mb-3">
                          <span class="input-group-text">Check Specifique: </span>                   
                          <select class="form-select" name="Check_Specifique">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                
                            <input class="form-select" name="Observation4" placeholder="Observation">                             
                  </div>                  
                  <div class="input-group mb-3">
                          <span class="input-group-text">Synthese: </span>                   
                          <select class="form-select" name="Synthese">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">               
                            <input class="form-select" name="Observation5" placeholder="Observation">                            
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">Taux_MPC-MPS: </span>                   
                          <select class="form-select" name="Taux_MPC">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                
                            <input class="form-select" name="Observation6" placeholder="Observation">
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">Taux_Respect_MPC-MPS: </span>                   
                          <select class="form-select" name="Respect">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                 
                            <input class="form-select" name="Observation7" placeholder="Observation">                               
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">GIN: </span>                   
                          <select class="form-select" name="GIN">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                
                            <input class="form-select" name="Observation8" placeholder="Observation">                                
                  </div>                
                  <div class="input-group mb-3">
                          <span class="input-group-text">BPM: </span>                   
                          <select class="form-select" name="BPM">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">               
                            <input class="form-select" name="Observation9" placeholder="Observation">                               
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">Guide D'Intervention: </span>                   
                          <select class="form-select" name="Guide_Intervention">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">                 
                            <input class="form-select" name="Observation10" placeholder="Observation">                                
                  </div>
                  <div class="input-group mb-3">
                          <span class="input-group-text">Etat_Panne: </span>                   
                          <select class="form-select" name="Etat_Panne">
                            <option selected>Choisir...</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                        </select>
                  </div>
                  <div style="margin-top: 0.5%;" class="input-group mb-3">               
                            <input class="form-select" name="Observation11" placeholder="Observation">                               
                  </div>
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    
                    <input class="btn btn-success"type="submit" name="button" value="Envoyer" onclick="return myconfirm()"/>

                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Confirmer...'))
                      return true;
                      return false;
                      }
                    </script>       

                  </div>
                </div>

                 </form>
<script>
        var tbl_uap = [
          
      {"uap_code": "UAP1", "uap_nom": "UAP1"}, 
      {"uap_code": "UAP2", "uap_nom": "UAP2"},  
      {"uap_code": "UAP3", "uap_nom": "UAP3"},  
      {"uap_code": "UAP4", "uap_nom": "UAP4"}, 
      {"uap_code": "SG-ELEC-ATC-PR", "uap_nom": "SG-ELEC"},
      {"uap_code": "ATC-PR", "uap_nom": "ATC-PR"},
          
          ];
              
             
    // tri dans l'ordre alpha pour new r�gion
    tbl_region_2016.sort(function(a, b){
      if( a.reg_2016_nom < b.reg_2016_nom)
       return( -1);
      if( a.reg_2016_nom > b.reg_2016_nom)
       return( 1);
      return( 0);    
    });
      
        
        
        </script>      
      
       <script>
        
        /**
    * Fonction de r�cup�ration des données correspondant au crit�re de recherche
    * @param   {String} condition - Chaine indiquant la condition �  remplir
    * @param   {Array}  table - Tableau contenant les donn�es �  extraire
    * @returns {Array}  result - Tableau contenant les donn�es extraites
    */
    function getDataFromTable( condition, table) {
      // r�cupération de la clé et de la valeur
      var cde = condition.replace(/\s/g, '').split('='),
        key = cde[0],
        value = cde[1],
        result = [];
      
      // retour direct si *
      if (condition === '*') {
      return table.slice();
      }
      // retourne les éléments r�pondant �  la condition
      result = table.filter( function(obj){
         return obj[key] === value;
      });
      return result;
    }
    /**
    * Affichage du nombre d'<option> pr�sentes dans le <select>
    * @param {Object} obj - <select> parent
    * @param {Number} nb - nombre �  afficher
    */
    function setNombre( obj, nb){
      var oElem = obj.parentNode.querySelector('.nombre');
      if( oElem){
      oElem.innerHTML = nb ? '(' +nb +')' :'';
      }
    }
    /**
    * Fonction d'ajout des <option> �  un <select>
    * @param   {String} id_select - ID du <select> �  mettre �  jour
    * @param   {Array}  liste - Tableau contenant les données �  ajouter
    * @param   {String} valeur - Champ pris en compte pour la value de l'<option>
    * @param   {String} texte - Champ pris en compte pour le texte affich� de l'<option>
    * @returns {String} Valeur s�lectionnée du <select> pour chainage
    */
    function updateSelect( id_select, liste, valeur, texte){
      var oOption,
        oSelect = document.getElementById( id_select),
        i, nb = liste.length;
      // vide le select
      oSelect.options.length = 0;
      // d�sactive si aucune option disponible
      oSelect.disabled = nb ? false : true;
      // affiche info nombre options, facultatif
      setNombre( oSelect, nb);
      // ajoute 1st option
      if( nb){
      oSelect.add( new Option( 'Choisir', ''));
      // focus sur le select
      oSelect.focus();
      }
      // cr�ation des options d'apr�s la liste
      for (i = 0; i < nb; i += 1) {
      // création option
      oOption = new Option( liste[i][texte], liste[i][valeur]);
      // ajout de l'option en fin
      oSelect.add( oOption);
      }
      // si une seule option on la s�lectionne
      oSelect.selectedIndex = nb === 1 ? 1 : 0;
      // on retourne la valeur pour le select suivant
      return oSelect.value;
    }
    /**
    * fonction de chainage des <select>
    * @param {String|Object} ID du <select> �  traiter ou le <select> lui-m�me
    */
    function chainSelect( param){
      // affectation par d�faut
      param = param || 'init';
      var liste,
        id     = param.id || param,
        valeur = param.value || '';
        
      // test �  faire pour r�cup�ration de la value
      if( typeof id === 'string'){
       param = document.getElementById( id);
       valeur = param ? param.value : '';
       }
     
       switch (id){
      case 'init':
        // r�cup. des donn�es
        liste = getDataFromTable( '*', tbl_uap);
        // mise �  jour du select
        valeur = updateSelect( 'uap', liste, 'uap_code', 'uap_nom');
        // chainage sur le select li�
        chainSelect('uap');
        break;
      case 'uap':
        // r�cup. des donn�es
        liste = getDataFromTable( 'uap_code=' +valeur, tbl_region_2016);
        liste1 = getDataFromTable( 'uap_code=' +valeur, tbl_rm_uap);
        // mise �  jour du select
        valeur = updateSelect( 'services', liste, 'reg_2016_code', 'reg_2016_nom');
        valeur1 = updateSelect( 'responsable', liste1, 'rm_code', 'rm_nom');
        // chainage sur le select li�
        chainSelect('services');
        chainSelect('responsable');
        break;
      case 'services':
        // r�cup. des donn�es
        liste = getDataFromTable( 'reg_2016_code=' +valeur, tbl_Linge_prod);
        // mise �  jour du select
        valeur = updateSelect( 'Linge_prod', liste, 'reg_code', 'reg_nom');
        // chainage sur le select li�
        chainSelect('Linge_prod');
        break;
      case 'Linge_prod':
        // affichage final
        document.getElementById('prefecture').value = valeur;
        break;
      }
    }
    // Initialisation après chargement du DOM
    document.addEventListener("DOMContentLoaded", function(event) {
      var oSelects = document.querySelectorAll('#liste select'),
        i, nb = oSelects.length;
      // affectation de la fonction sur le onchange
      for( i = 0; i < nb; i += 1) {
      oSelects[i].onchange = function() {
        chainSelect(this);
        };
      }
      // init du 1st select
      if( nb){
      chainSelect('init');
      }
    });
        
        </script>         




  </body>


  </html>