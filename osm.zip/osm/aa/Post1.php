<?php

session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=check_rse_jb', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
         $req = $bdd->prepare('INSERT INTO resultat_rse (date,
                                                        Zones,
                                                        Actions,
                                                        Observations,
                                                        Situations) 
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,                                        
                                        ?)');
         $req->execute(array(
                             $_POST['Zones'],
                             $_POST['Actions'],
                             $_POST['Observations'],
                             $_POST['Situations']));  

header('location:http://10.0.3.34:8080/rse/check.php');
 ?>