<html>

    <head>
        <title>csv insert</title>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/sytle_formulaire.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
        <link rel="stylesheet" href="css/styl.css"/>
        <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
        <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>

    </head>
<body>

        <fieldset class="inputTextWrap">
         <legend>Upload base uap</legend>
            <form action="insert_uap.php" method="post" enctype="multipart/form-data">
                        
                <div class="inputTextWrap">
                    <input class="form-control" type="file" name="csvfile" required="required"/>
                </div>

                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>     

            </form>
                <form action="deletetable.php" method="post" enctype="multipart/form-data">
                <input class="btn btn-secondary" type="submit" value="Delete" />
            </form>
        </fieldset>

        <fieldset>
         <legend>Upload base ligne</legend>
            <form action="insert_lignes.php" method="post" enctype="multipart/form-data">
        
                <div>
                    <input class="btn btn-secondary" type="file" name="csvfile" required="required"/>
                </div>

                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>
            </form>

        <form action="deletetable.php" method="post" enctype="multipart/form-data">
            <input class="btn btn-secondary" type="submit" value="Delete" />
        </form>        
        </fieldset>


        <fieldset>
         <legend>Upload base machines</legend>
            <form action="insert_machines.php" method="post" enctype="multipart/form-data">

                <div>
                    <input class="btn btn-secondary" type="file" name="csvfile" required="required"/>
                </div>

                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>
            </form>

        <form action="deletetable.php" method="post" enctype="multipart/form-data">
            <input class="btn btn-secondary" type="submit" value="Delete" />
        </form>
        </fieldset>

        <fieldset>
         <legend>Upload base responsable</legend>
            <form action="insert_responsable.php" method="post" enctype="multipart/form-data">

                <div>
                    <input class="btn btn-secondary" type="file" name="csvfile" required="required"/>
                </div>

                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>
            </form>

        <form action="deletetable.php" method="post" enctype="multipart/form-data">
            <input class="btn btn-secondary" type="submit" value="Delete" />
        </form>
        </fieldset>


                <fieldset>
         <legend>Upload theme</legend>
            <form action="insert_theme.php" method="post" enctype="multipart/form-data">

                <div>
                    <input class="btn btn-secondary" type="file" name="csvfile" required="required"/>
                </div>

                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>
            </form>

        <form action="deletetable.php" method="post" enctype="multipart/form-data">
            <input class="btn btn-secondary" type="submit" value="Delete" />
        </form>
        </fieldset>

</body>
</html>