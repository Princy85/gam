<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'test');

	// initialize variables
	$date = "";
	$uap = "";
	$lignes = "";
	$machines = "";
	$responsable = "";
	$organes = "";
	$themes = "";
	$faits = "";
	$action_preventive = "";
	$delais = "";
	$id = 0;
	$update = false;


	
	if (isset($_GET['t'])) {
	$id = $_GET['t'];
	mysqli_query($db, "UPDATE base SET situations='1' WHERE id=$id");
	$_SESSION['message'] = "Address deleted!"; 
	header('location: afficher.php');
}