<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Check Liste Gamme Automaintenance</title>

    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
</head>
<body>


<!-- Edit Student Modal -->
<div class="modal fade" id="studentEditModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Student</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="updateStudent" class="container">
            <div class="modal-body">

                <div id="errorMessageUpdate" class="alert alert-warning d-none"></div>

                <input type="hidden" name="student_id" id="student_id" >

                <div class="mb-3">
                    <label for="">Zones</label>
                    <input type="text" name="email" id="email" class="form-control" />
                </div>
                <div class="mb-3">
                    <label for="">Actions</label>
                    <input type="text" name="phone" id="phone" class="form-control" />
                </div>
                <div class="mb-3">
                    <label for="">Observations</label>
                    <input type="text" name="phone" id="phone" class="form-control" />
                </div>

                <div class="mb-3">
                                        <td>
                                                 <div>
                                                  <input type="radio" id="huey" name="Situations" value="1"
                                                         checked>
                                                  <label for="huey">1</label>
                                                

                                                
                                                  <input type="radio" id="dewey" name="Situations" value="0">
                                                  <label for="dewey">0</label>
                                                </div>

                                        </td>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Update Student</button>
            </div>
        </form>
        </div>
    </div>
</div>

<div class="container">
    <div >
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">


                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                               
                                <th>Zones</th>
                                <th>Actions</th>
                                <th>Observations</th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require 'dbcon.php';

                            $query = "SELECT * FROM rse_jb";
                            $query_run = mysqli_query($bdd, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                foreach($query_run as $student)
                                {
                            ?>
                                    <form class="row" enctype="" method="POST" action="Post.php" style="width: 1366px;">
                                    <tr>
                                        <td><input class="form-control" style="border:none;background:transparent;" value="<?= $rse_jb['Zones']?>" name="Zones" readonly/></td>
                                        <td><input class="form-control" style="border:none;background:transparent;" value="<?= $rse_jb['Actions']?>" name="Actions" readonly/></td>
                                        <td><input class="form-control"style="border:none;background:transparent;" value="<?= $rse_jb['Observations']?>" name="Observations"/></td>
                                        
                                        <td>
                                                 <div>
                                                  <input type="radio" id="huey" name="Situations" value="1" checked>
                                                  <label for="huey">1</label>
                                                

                                                
                                                  <input type="radio" id="dewey" name="Situations" value="0">
                                                  <label for="dewey">0</label>
                                                </div>

                                        </td>
                                        
                                        <td>
                                            <input type="submit" value="valider" id="btn_envoyer" class="editStudentBtn btn btn-success btn-sm"/>
                                            
                                        </td>
                                    </tr>

            <script>
             $(function() 
             {
             $('#btn_envoyer').click(function()
             {
             $(this).attr("disabled", "disabled");
             });
             });
            </script>


</form>

                                    <?php
                                }
                            }
                            ?>
                            
                        </tbody>
                    </table>
            
                </div>
            
            </div>
        </div>
    </div>
</div>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

    <script>
        $(document).on('submit', '#saveStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("save_student", true);

            $.ajax({
                type: "POST",
                url: "code.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessage').removeClass('d-none');
                        $('#errorMessage').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessage').addClass('d-none');
                        $('#studentAddModal').modal('hide');
                        $('#saveStudent')[0].reset();

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });

        $(document).on('click', '.editStudentBtn', function () {

            var student_id = $(this).val();
            
            $.ajax({
                type: "GET",
                url: "code.php?student_id=" + student_id,
                success: function (response) {

                    var res = jQuery.parseJSON(response);
                    if(res.status == 404) {

                        alert(res.message);
                    }else if(res.status == 200){

                        $('#id').val(res.data.id);
                        $('#Zones').val(res.data.Zones);
                        $('#Actions').val(res.data.Actions);
                        $('#Observations').val(res.data.Observations);

                        $('#studentEditModal').modal('show');
                    }

                }
            });

        });

        $(document).on('submit', '#updateStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("update_student", true);

            $.ajax({
                type: "POST",
                url: "code.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessageUpdate').addClass('d-none');

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);
                        
                        $('#studentEditModal').modal('hide');
                        $('#updateStudent')[0].reset();

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });

    </script>

</body>
</html>