 <?php
$bdd = new mysqli("localhost","root","","sm_jb");

// Check connection
if ($bdd -> connect_errno) {
  echo "Failed to connect to MySQL: " . $bdd -> connect_error;
  exit();
}
?> 