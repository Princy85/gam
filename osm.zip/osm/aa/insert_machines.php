<?php
$con=mysqli_connect("localhost","root","","sm_jb");
if($con)
{
$file=$_FILES['csvfile']['tmp_name'];
$handle=fopen($file,"r");
$i=0;
while(($cont=fgetcsv($handle,2000,","))!==false)
    {
        $osm=rtrim($_FILES['csvfile']['name'],".csv");
        if($i==0)
        {            
        $id=$cont[0];
        $machines=$cont[1];
        $s_id=$cont[2];
        $s_id1=$cont[3];
        
        
        
        $query="CREATE TABLE $osm($id INT(255), $machines VARCHAR(255), $s_id VARCHAR(255), $s_id1 VARCHAR(255);";
        mysqli_query($con,$query);
        }
        else{
            $query="INSERT INTO $osm($dates,$machines,$s_id,$s_id1) VALUES ('$cont[0]','$cont[1]','$cont[2]','$cont[3]')";
            mysqli_query($con,$query);
            }
        $i++;
    }
}else{
    echo"conncetion failed";
}

  header('location:http://10.0.3.37:8080/rse/Uploadanddelete.php');
?>