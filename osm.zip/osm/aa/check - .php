<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>Check RSE</title>

    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="text-center">
                    <h4 style="display:flex;justify-content:center;margin-top:2%;margin-bottom:0%;color:forestgreen;">Check RSE JB</h4>
                </div>
                <div class="card-body">

                    <table id="myTable" class="table table-success table-striped table-bordered border-primary">
                        <thead>
                            <tr>
                               
                                <th style="text-align: center;font-size:5vw;">Actions à Vérifier</th>                                                
                                                             
                            </tr>
                        </thead>

                        <tbody>
                            
                            <?php
                            require 'dbcon.php';

                            $query = "SELECT * FROM rse_jb";
                            $query_run = mysqli_query($bdd, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                foreach($query_run as $student)
                                {
                            ?>
                <form class="container" enctype="" method="POST" action="Post.php" width=45%>
                        
                        <body>





                        <tr class="container">                                        
                            <td> <input style="text-align: center; font-size:5vw;" class="form-control-plaintext" name="Zones" placeholder="<?= $student['Zones'] ?>" readonly/>                                
                                 <textarea style="font-size:4vw;" class="form-control-plaintext" name="Actions" placeholder="<?=$student['Actions'] ?>" readonly/></textarea>
                                 <textarea style="font-size:4vw;" class="form-control" name="Observations" list="datalistOptions" id="exampleDataList" placeholder="Observations"></textarea>                       
                                 <input style="justify-content:center;margin-top:4%;margin-left:35%;" type="radio" id="huey" name="Situations" value="OK" checked>
                                 <label for="huey">OK</label>
                                 <input style="justify-content:center;margin-top:3%;margin-left:10%;" type="radio" id="dewey" name="Situations" value="KO">
                                 <label for="dewey">KO</label>
                                 <div style="justify-content:center">
                                 <input style="text-align: center; margin-top:3%;margin-left:40%;" type="submit" value="Envoyer" id="btn_envoyer" class="btn btn-primary btn-block"/> </td>          
                                 </div>
                        </tr>
                        </body>

                        <script>
                         $(function()
                         {
                         $('#btn_envoyer').click(function()
                         {
                         $(this).attr("disabled", "disabled");
                         });
                         });
                        </script>
                    </form>

                                        <?php
                                                    }
                                                    }
                                                    ?>
                            
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

    <script>
        $(document).on('submit', '#saveStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("save_student", true);

            $.ajax({
                type: "POST",
                url: "code.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessage').removeClass('d-none');
                        $('#errorMessage').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessage').addClass('d-none');
                        $('#studentAddModal').modal('hide');
                        $('#saveStudent')[0].reset();

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });

        $(document).on('click', '.editStudentBtn', function () {

            var student_id = $(this).val();
            
            $.ajax({
                type: "GET",
                url: "code.php?student_id=" + student_id,
                success: function (response) {

                    var res = jQuery.parseJSON(response);
                    if(res.status == 404) {

                        alert(res.message);
                    }else if(res.status == 200){

                        $('#id').val(res.data.id);
                        $('#Zones').val(res.data.Zones);
                        $('#Actions').val(res.data.Actions);
                        $('#Observations').val(res.data.Observations);
                        $('#studentEditModal').modal('show');
                    }

                }
            });

        });

        $(document).on('submit', '#updateStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("update_student", true);

            $.ajax({
                type: "POST",
                url: "code.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessageUpdate').addClass('d-none');

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);
                        
                        $('#studentEditModal').modal('hide');
                        $('#updateStudent')[0].reset();

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });

    </script>
   

</body>
</html>