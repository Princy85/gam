<?php

session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=resultat_osm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
         $req = $bdd->prepare('INSERT INTO resultat_osm_jb (date,
                                                        Outils,
                                                        Resultats,
                                                        Observations)
                                                       
                                  VALUES(now(),
                                        ?,                                        
                                        ?,                                        
                                        ?)');
         $req->execute(array(
                             $_POST['Outils'],
                             $_POST['Resultats'],
                             $_POST['Observations'])); 
         
header('location:http://10.0.3.37:8080/osm/check.php');
 ?>