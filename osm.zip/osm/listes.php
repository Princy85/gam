<?php
  $host = 'localhost';
  $dbname = 'sm_jb';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM osm";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head>
<script>
    function AutoRefresh(t){
      setTimeout("location.reload(true);", t);
      }
</script>
</head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  


<body onload="javascript:AutoRefresh(12000000);">
    <center>
 <h1>RESULTATS OSM</h1>

 <table class="table table-striped table-bordered border-primary">
   <thead class="bg-info sticky-top">
     <tr>      
       <th class="text-center">UAP</th> 
       <th class="text-center">Auditeur</th>
       <th class="text-center">TDM</th>
       <th class="text-center">OT TDM</th>
       <th class="text-center">TDL RM</th>    
       <th class="text-center">GAM</th>       
       <th class="text-center">Check Specifique</th>  
       <th class="text-center">Synthese</th>       
       <th class="text-center">MPC-MPS</th>       
       <th class="text-center">Respect MPC-MPS</th>      
       <th class="text-center">GIN</th>    
       <th class="text-center">BPM</th>       
       <th class="text-center">Guide d'Intervention</th>       
       <th class="text-center">Etat Panne</th>      
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>       
       <td class="text-center"><?php echo htmlspecialchars($row['UAP']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Auditeur']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['TDM']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['OT_TDM']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['TDL_RM']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['GAM']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Check_Specifique']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Synthese']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Taux_MPC']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Respect']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['GIN']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['BPM']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['Guide_Intervention']); ?></td>     
       <td class="text-center"><?php echo htmlspecialchars($row['Etat_Panne']); ?></td>

      
     </tr>
     <?php endwhile; ?>
   </tbody>

      <div style="margin-bottom: 1%"; class="d-grid gap-2 col-2 mx-auto">
      <form>
        <input type=button class="btn btn-success" style="margin-bottom: 1%;" ; value=Retour>

	     </form>
	    </div>

 </table>

 <script type="text/javascript">
		function tableToCSV() {

			// Variable to store the final csv data
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "eau.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
	</script>
    </center>
</body>
</html>