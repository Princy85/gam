<?php

$bdd = mysqli_connect("localhost","root","","sm_jb");

if (!$bdd){
  die('Connection Failed'. mysqli_connect_error());
}
 ?>