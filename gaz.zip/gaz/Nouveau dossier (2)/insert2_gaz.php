<?php
 $connection=new mysqli("localhost","root","","consommation");
 $laser1 = $_POST['laser1'];
 $laser2 = $_POST['laser2'];
 $laser3 = $_POST['laser3'];
 $fox = $_POST['fox'];
 $chaudiere = $_POST['chaudiere'];
 $tpj = $_POST['tpj'];
 $jbu2 = $_POST['jbu2'];
 $stockpr = $_POST['stockpr'];

 $sql ="INSERT INTO `gaz_jbu2` (`date`, `laser1`, `laser2`, `laser3` , `fox`, `chaudiere`, `tpj`, `jbu2`, `stockpr`) VALUES ((SELECT CURDATE() - INTERVAL 1 DAY) ,'$laser1','$laser2','$laser3','$fox','$chaudiere','$tpj','$jbu2','$stockpr')";

$result = mysqli_query($connection, $sql);
if($result){

  //send mail
   $from = "MPR"; // sender
   $subject = " CONSO_GAZ_USINE";
 
$message .=
"Bonjour,

Veuillez voir ci-dessous la valeur du stock MPR ainsi que le lien de consultation du consomation gaz aujourd'hui 

Valeur du Stock MPR : ".$_POST['stockpr']." [Milliard Ar]

Lien de consultation : http://10.0.3.100:8080/gaz/gaz_jbu2.php

Cordialement\n";

   $to = " FreginahFaniry.Rakotonirina@basan.mg, Rijaniaina.Rafanoharana@basan.mg, Enintsoa.Rasolofomandimby@basan.mg, elisaha.rakotoarisoa@basan.mg";

   $array = explode(',', $to);

   $count = count($array);
   
   $res = array_slice($array, 0, 16);

print_r($res);

   mail( $to,$subject,$message,"From: $from\n");



     header ("location: gaz_jbu2.php");
   }
   


