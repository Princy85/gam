<?php
 $connection=new mysqli("localhost","root","","consommation");
 $id = $_POST['id'];
 $compteur_gaz = $_POST['compteur_gaz'];
 $consommation_gaz = $_POST['consommation_gaz'];
 $baremage = $_POST['baremage'];
 $pellets = $_POST['pellets'];
 $curl = $_POST['curl'];
 $essai = $_POST['essai'];
 $piwi = $_POST['piwi'];
 $kidz_ballz = $_POST['kidz_ballz_fromage'];
 $tsiky_ballz = $_POST['tsiky_balls_fromage'];
 $tubz_pizza = $_POST['tubz_pizza'];
 $tubz_fromage = $_POST['tubz_fromage'];
 $total = $_POST['total_tonnage'];
 $ratio = $_POST['ratio_gaz'];

 $sql ="UPDATE `gaz_jbu2` SET `compteur_gaz`='$compteur_gaz',`consommation_gaz`='$consommation_gaz',`baremage`='$baremage',`pellets`='$pellets',`curl`='$curl',`essai`='$essai',`piwi`='$piwi',`kidz_ballz_fromage`='$kidz_ballz',
 `tsiky_balls_fromage`='$tsiky_ballz',`tubz_pizza`='$tubz_pizza',`tubz_fromage`='$tubz_fromage',`total_tonnage`='$total',`ratio_gaz`='$ratio' WHERE id=$id";

$result = mysqli_query($connection, $sql);
if($result){
    //send mail
   $from = "RELEVEE_GAZ_JBU2"; // sender
   $subject = " CONSO_GAZ_JBU2";
 
$message .=
"Bonjour,

L'insertion du relevée consommation gaz a été effectué par l'equipe jbu2,

-Compteur: ".$_POST['compteur_gaz']." m3
-Baremage: ".$_POST['baremage']." %

lien de consultation : http://10.0.3.100:8080/gaz/gaz_jbu2.php

Cordialement\n";

   $to = " FreginahFaniry.Rakotonirina@basan.mg, Rijaniaina.Rafanoharana@basan.mg, elisaha.rakotoarisoa@basan.mg, Enintsoa.Rasolofomandimby@basan.mg ";

   $array = explode(',', $to);

   $count = count($array);
   
   $res = array_slice($array, 0, 16);

print_r($res);

   mail( $to,$subject,$message,"From: $from\n");



     header ("location: gaz_jbu2.php");
   
}