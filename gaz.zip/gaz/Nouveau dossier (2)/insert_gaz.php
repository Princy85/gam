           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
           <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
 $connection=new mysqli("localhost","root","","consommation");
 
 $sql = "SELECT count(id) as nbr FROM `gaz_jbu2` where date = date(now())";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result))
                          {
                            $date = (int)$row['nbr'];
                          }
                        }
if($date == 0){
  if(isset($_POST['submit'])){
    $compteur_gaz = $_POST['compteur_gaz'];
    $consommation_gaz = $_POST['consommation_gaz'];
    $baremage = $_POST['baremage'];
    $pellets = $_POST['pellets'];
    $curl = $_POST['curl'];
    $essai = $_POST['essai'];
    $piwi = $_POST['piwi'];
    $kidz_ballz = $_POST['kidz_ballz_fromage'];
    $tsiky_ballz = $_POST['tsiky_balls_fromage'];
    $tubz_pizza = $_POST['tubz_pizza'];
    $tubz_fromage = $_POST['tubz_fromage'];
    $total = $_POST['total_tonnage'];
    $ratio = $_POST['ratio_gaz'];
   
    $sql ="INSERT INTO `gaz_jbu2`( `date`, `compteur_gaz`, `consommation_gaz`, `baremage`, `pellets`, `curl`, `essai`, `piwi`, `kidz_ballz_fromage`, `tsiky_balls_fromage`, `tubz_pizza`, `tubz_fromage`, `total_tonnage`, `ratio_gaz`) VALUES 
    ((SELECT CURDATE() - INTERVAL 1 DAY),'$compteur_gaz','$consommation_gaz','$baremage','$pellets','$curl','$essai','$piwi','$kidz_ballz','$tsiky_ballz','$tubz_pizza','$tubz_fromage','$total','$ratio')";
   
   echo "$sql";
   $result = mysqli_query($connection, $sql);
   if($result){


//send mail
   $from = "RELEVEE_GAZ_JBU2"; // sender
   $subject = " CONSO_GAZ_JBU2";
 
$message .=
"Bonjour,

L'insertion du relevé consommation gaz a été effectué par l'equipe jbu2,

-Compteur: ".$_POST['compteur_gaz']."  m3
-Baremage: ".$_POST['baremage']." %

lien de consultation : http://10.0.3.100:8080/gaz/gaz_jbu2.php

Cordialement\n";

   $to = "FreginahFaniry.Rakotonirina@basan.mg, Rijaniaina.Rafanoharana@basan.mg, elisaha.rakotoarisoa@basan.mg, Enintsoa.Rasolofomandimby@basan.mg ";

   $array = explode(',', $to);

   $count = count($array);
   
   $res = array_slice($array, 0, 16);

print_r($res);

   mail( $to,$subject,$message,"From: $from\n");



     header ("location: gaz_jbu2.php");
   }
    }


  
}else

{
         echo "c";
       ?>
          <script>
              Swal.fire(
              {
                icon: 'error',
                title: 'Erreur',
                text: 'Vous avez déjà executé une insertion aujourd\'hui',          
              });
                     
              setTimeout(function() 
              {
                window.location.href = "gaz_jbu2.php";
              }, 3000); 
          </script>
                    
        <?php
                }
        ?>




