<?php
session_start();

$connection=new mysqli("localhost","root","","consommation");
 $sql = "SELECT * FROM `gaz_jbu2` order by id ASC";
 $result = mysqli_query($connection,$sql);
 if($result){
     while($row=mysqli_fetch_assoc($result)){
         $compteur_gaz1 = $row['compteur_gaz'];
         $consommation_gaz1 = $row['consommation_gaz'];
         $baremage1 = $row['baremage'];
     }}
     
     $sql = "SELECT count(id) as nbr FROM `gaz_jbu2` where date = (SELECT CURDATE() - INTERVAL 1 DAY)";
                        $result = mysqli_query($connection,$sql);
                        if($result){
                            while($row=mysqli_fetch_assoc($result))
                              {
                                $date = (int)$row['nbr'];
                              }
                            }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css" />  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>       
    <link rel="stylesheet" href="css/bootstrap.min.css"/>     
    <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
    <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../bootsrap/js/bootstrap.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Relevée gaz JBU2</title>

                <style>
                  .sticky-column {
                    position: sticky;
                    left: 0;
                    z-index: 1;
                    background-color: yellow;
                  }
                </style>
</head>
                <style>
                    .fixed-column-width-table th,
                .fixed-column-width-table td {
                    width: 100px;
                }
                

                </style>
<body>
      <div class="fixed-top">
        <h1 style="text-align:center; margin-top:15px ;font-family:times new roman;  font-weight:bold">CONSOMMATIONS GAZ USINE</h1>
          <div style="text-align:center">
              <button class="btn btn-primary button  mb-3 mt-2"data-toggle="modal" data-target="#modalConnexion">Connexion</button> 
              <a href="deconnection.php" class="btn btn-danger ml-3 mb-3 mt-2" style="text-align:center">Déconnexion</a>
          </div>
      </div>

      <table class="table table-striped table-bordered border-dark sticky-top text-center fixed-column-width-table" style="width: 200%; margin-top: 150px">
            <thead class=" text-light sticky-top align-middle">
                <tr > 
                    <th class="sticky-column" style="background: blue;" rowspan="2" >Date</th>
                    <th colspan="3" style="background-color: rgb(40, 86, 136);"> Relevé jbu2</th>
                    <th colspan="8" style="background-color: rgb(40, 86, 136);"> Gaz usine</th>
                </tr>

                <tr >       
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Compteur gaz [m³]</td>
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Consommation gaz [m³]</td>
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Baremage [%]</td>
                <?php
                   if(isset($_SESSION["test"]))
                      {
                ?>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)"></td>
                <?php
                      }
                ?>
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Laser1 [kg]</td>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)" >Laser2 [kg]</td>
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Laser3 [kg]</td>
                    <td class="text-center" style="background-color: rgb(40, 86, 136)">Fox...   [kg]</td>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)">Chaudi [kg]</td>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)">T P J.. [kg]</td>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)">JBU2 [kg]</td>
                <?php
                    if(isset($_SESSION["mpr"]))
                    {
                ?>
                    <td class="text-center"style="background-color: rgb(40, 86, 136)">Stock</td>
               <?php
                     }
               ?>
                    <td style="background-color: rgb(40, 86, 136)">action</td>
                </tr>
            </thead>

            <tbody> 

  <?php
  // INSERTION JBU2 VOHALOHANY
  ?>           
                <?php
                // Créer un objet DateTime représentant la date d'aujourd'hui
                $dateAujourdhui = new DateTime();

                // Soustraire un intervalle d'un jour
                $dateMoinsUnJour = $dateAujourdhui->sub(new DateInterval('P1D'));
                ?>
            <tr>
                    <?php 
                    if(isset($_SESSION["test"]) ){
                    ?>
                                        <!--forme input jbu2-->
                    <form action="insert_gaz.php" method="POST">
                      
                    <th class=" sticky-column">
                        <input type="date" name="date" class="form-control" required>
                    </th>
                    <th>
                        <div align="center">
                            <input type="number" step="any" name="compteur_gaz" class="form-control"  required min="<?= $compteur_gaz1 ?>">
                        </div>
                    </th>

                    <th> 
                        <div align="center">
                            <input type="number" step="any"  class="form-control" name="consommation_gaz"  required >
                        </div>
                    </th>
                    <th>
                        <div align="center">
                            <input type="number" step="any" name="baremage" class="form-control"  required >
                        </div>
                    </th>
                     
                     

                      <th>
                        <div align="center">
                            <input type="submit" class="btn btn-primary"  name="submit" value="Envoyer">
                        </div>
                    </th>    
                  </form>
                    <?php
                    }
                    ?>
                    
            </tr>

<?php
  // INSERTION MPR VOHALOHANY
  ?> 

            <tr>
                <?php 
                
                if(isset($_SESSION["mpr"])){
                ?>

                   <form action="insert2_gaz.php" method="post">

                    <th class="sticky-column">
                        <input type="date" name="date" class="form-control" id="" required>
                    </th>
                    <td></td>
                    <td></td>
                    <td></td>
                    
                    <td class="bg-success">
                        <input type="number" name="laser1" class="form-control" required>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="laser2" class="form-control" required>
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="laser3" class="form-control" required>
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="fox" class="form-control" required>
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="chaudiere" class="form-control" required>
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="tpj" class="form-control" required>
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="number" name="jbu2" class="form-control" >
                        </div>
                    </td>

                    <td class="bg-success"> 
                        <div align="center">
                            <input type="text" name="stockpr" class="form-control" required>
                        </div>
                    </td>

                    <td>
                        <input type="submit" class="btn btn-primary"  name="submit" value="Envoyer">
                    </td>
                </form>

                <?php
                }
                ?>
            
            </tr>    
                    <?php
                    $connection=new mysqli("localhost","root","","consommation");
                    $sql = "SELECT * FROM `gaz_jbu2` order by id DESC";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $date = $row['date'];
                            $compteur_gaz = $row['compteur_gaz'];
                            $consommation_gaz = $row['consommation_gaz'];
                            $baremage = $row['baremage'];
                            $laser1 = $row['laser1'];
                            $laser2 = $row['laser2'];
                            $laser3 = $row['laser3'];
                            $fox = $row['fox'];
                            $chaudiere = $row['chaudiere'];
                            $tpj = $row['tpj'];
                            $jbu2 = $row['jbu2'];
                            $stockpr = $row['stockpr'];

                            ?>

<?php  
                            //input jbu2 deuxieme
?>
                <tr>
                            <form action="update2_gaz.php" method="post">
                                <td class="sticky-column" style="background: #f2f2f2;border-block: thick; ">
                                    <?= $date?>
                                </td>
                                <td >
                                <?php
                                    if(empty($compteur_gaz) && empty($consommation_gaz) && empty($baremage) &&  isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" step="any" name="compteur_gaz" class="form-control" required min="<?= $compteur_gaz1 ?>">
                                    <?php
                                }else{
                                   //$io1=number_format($compteur_gaz, 3);
                            echo "$compteur_gaz";
                                }
                                ?>
                                </td>

                                <td> 
                                    <input type="number" value="<?= $id ?>" name="id" class="collapse">
                                    <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($compteur_gaz) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" step="any" name="consommation_gaz" class="form-control">
                                    <?php
                                }else{
                                    //$cons=number_format($consommation_gaz, 3);
                            echo "$consommation_gaz";
                                }
                                ?>
                                </td>

                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($compteur_gaz) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" step="any" name="baremage" class="form-control">
                                  
                                    <?php
                                }else{
                                   // $bar=number_format($baremage, 3);
                            echo "$baremage";
                                }
                                ?>

<?php // bouton update jbu2 faharoa ?>
                                <?php
                if(isset($_SESSION["test"])){
                ?>
                    <td>
                        <?php
                        if(empty($consommation_gaz) &&  (isset($_SESSION["test"]))){
                            ?>
                            <div align="center">
                              <input type="submit" class="btn btn-primary"  name="submit" value="Envoyer">
                            <?php
                        }else {
                            
                            echo "";
                        }
                        ?>    
                        </td>
                        <?php
                             }
                        ?>
                                </td>
                                
                               
                        </form>


<?php // insertion MPR 2 deuxieme ?>

                    <form action="update_gaz.php" method="post">
                        <td class="bg-success"> 
                                        <input type="number" value="<?= $id ?>" name="id" class="collapse">
                                        <?php
                                             if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                                        ?>
                                        <input class="form-control"type="number" name="laser1" step="any">
                                        <?php
                              }else {
                                  echo "$laser1";
                              }
                              ?>
                        </td>


                        <td class="bg-success" >
                            <?php
                            if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="form-control" type="number" name="laser2" step="any">
                            <?php
                        }else {
                            echo "$laser2";
                        }
                        ?>
                        </td>


                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="form-control" type="number" name="laser3" step="any">
                            <?php
                        }else {
                            echo "$laser3";
                        }
                        ?>
                    </td>
                        <td class="bg-success">
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="form-control" type="number" name="fox" step="any">
                            <?php
                        }else {
                            echo "$fox";
                        }
                        ?>
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="form-control" type="number" name="chaudiere" step="any">
                            <?php
                        }else {
                            echo "$chaudiere";
                        }
                        ?>    
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="form-control" type="number" name="tpj" step="any">
                            <?php
                        }else {
                            echo "$tpj";
                        }
                        ?>    
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <div align="center">
                           <input class="form-control" type="number" name="jbu2" step="any"></div>
                            <?php
                        }else {
                            echo "$jbu2";
                        }
                        ?>    
                        </td>
                       




<?php //Manapoitra input stock pr?>

                    <?php
                if(isset($_SESSION["mpr"])){
                ?>
                    <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && empty($stockpr) && (isset($_SESSION["mpr"]))){
                            ?>
                            
                            <input class="form-control" type="number" name="stockpr" step="any">
                            <?php
                        }else {

                                                        $io=number_format($stockpr, 3);
                            echo "$io";
                        }
                        ?>    
                        </td>
                        <?php
                             }
                        ?>


<?php //Manapoitra boutton stock pr?>
                        
                        <td>
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="submit" class="btn btn-primary"  name="submit" value="Envoyer">
                            <?php
                        }
                        ?>        
                        </td>

                    </form>
                </tr>
                <?php
                            }
                        }


                        
                ?>
        </tbody>
    </table>
                
          <!-- POPUP MODAL-->
          
<div class="modal fade" id="modalConnexion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="text-align: center;">
        <h1 style="color:#000;">Connexion</h1>
     </div>
      <form action="connection.php" method="POST">
       
      <div class="modal-body">
      
          <div class="form-group">
            <label  style="font-weight:bold;margin-bottom:20px;color:#000"for="">Mot de Passe</label><br>
            <input type="password" name="password" placeholder="Veuillez entrer votre mot de passe" class="form-control">
              
         </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary" name="submit" ><img src="image/connection.png" alt="" width="30px">Connecter</button>
         </form>
      </div>
    </div>
  </div>
</div>      
</body>
</html>