<?php
$password = $_POST['password'];

if($password === "jbu2"){
    session_start();
    $_SESSION["test"]= "test";

    header ("location:gaz_jbu2.php");
}elseif($password === "mpr"){
    session_start();
    $_SESSION["mpr"]= "mpr";
    header ("location:gaz_jbu2.php");
}else{
    header ("location:index.php");
}