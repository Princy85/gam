<?php
 $connection=new mysqli("localhost","root","","consommation");
 $id = $_POST['id'];
 $compteur_gaz = $_POST['compteur_gaz'];
 $consommation_gaz = $_POST['consommation_gaz'];
 $baremage = $_POST['baremage'];
 $pellets = $_POST['pellets'];
 $curl = $_POST['curl'];
 $essai = $_POST['essai'];
 $piwi = $_POST['piwi'];
 $kidz_ballz = $_POST['kidz_ballz_fromage'];
 $tsiky_ballz = $_POST['tsiky_balls_fromage'];
 $tubz_pizza = $_POST['tubz_pizza'];
 $tubz_fromage = $_POST['tubz_fromage'];
 $total = $_POST['total_tonnage'];
 $ratio = $_POST['ratio_gaz'];

 $sql ="UPDATE `gaz_jbu2` SET `compteur_gaz`='$compteur_gaz',`consommation_gaz`='$consommation_gaz',`baremage`='$baremage',`pellets`='$pellets',`curl`='$curl',`essai`='$essai',`piwi`='$piwi',`kidz_ballz_fromage`='$kidz_ballz',
 `tsiky_balls_fromage`='$tsiky_ballz',`tubz_pizza`='$tubz_pizza',`tubz_fromage`='$tubz_fromage',`total_tonnage`='$total',`ratio_gaz`='$ratio' WHERE id=$id";

$result = mysqli_query($connection, $sql);
if($result){
    header ("location: gaz_jbu2.php");
}