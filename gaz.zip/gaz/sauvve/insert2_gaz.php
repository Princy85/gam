<?php
 $connection=new mysqli("localhost","root","","consommation");
 $fox = $_POST['fox'];
 $tpj = $_POST['tpj'];
 $chaudiere = $_POST['chaudiere'];
 $laser1 = $_POST['laser1'];
 $laser2 = $_POST['laser2'];
 $laser3 = $_POST['laser3'];

 $sql ="INSERT INTO `gaz_jbu2` (`date`, `fox`, `tpj`, `chaudiere`, `laser1`, `laser2`, `laser3`) VALUES (date(now()) ,'$fox','$tpj','$chaudiere','$laser1','$laser2','$laser3')";

$result = mysqli_query($connection, $sql);
if($result){
    header ("location: gaz_jbu2.php");
}else{
  echo "erreur";
}