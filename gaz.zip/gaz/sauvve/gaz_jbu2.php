<?php
session_start();
$connection=new mysqli("localhost","root","","consommation");
 $sql = "SELECT * FROM `gaz_jbu2` order by id ASC";
 $result = mysqli_query($connection,$sql);
 if($result){
     while($row=mysqli_fetch_assoc($result)){
         $compteur_gaz1 = $row['compteur_gaz'];
         $consommation_gaz1 = $row['consommation_gaz'];
         $baremage1 = $row['baremage'];
     }}
     
     $sql = "SELECT count(id) as nbr FROM `gaz_jbu2` where date = date(now())";
                        $result = mysqli_query($connection,$sql);
                        if($result){
                            while($row=mysqli_fetch_assoc($result))
                              {
                                $date = (int)$row['nbr'];
                              }
                            }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
           
          
           <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Relevée gaz JBU2</title>
</head>
<body>
<h1 style="text-align:center">Consommations/Consultations gaz JBU2                    mpr     dti</h1>
<a href="index.php" class="btn btn-primary mr-3 mb-5">Connection</a>
<a href="deconnection.php" class="btn btn-danger ml-5 mb-5">Déconnection</a>
        <table class="table table-striped table-bordered border-primary sticky-top">
            <thead class="bg-info sticky-top">
                <tr>       
                    <th class="text-center" width="7%">Date</th>
                    <th class="text-center" width="10%">Compteur gaz(m³)</th>
                    <th class="text-center" width="7%">Consommation gaz(m³)</th>
                    <th class="text-center">Baremage(%)</th>
                    <th class="text-center" width="7%">Pellets</th>
                    <th class="text-center" width="7%">Curl</th>
                    <th class="text-center" width="7%">Essai</th>
                    <th class="text-center" width="7%">Piwi</th>
                    <th class="text-center" width="10%">Kidz Ballz Fromage</th>
                    <th class="text-center" width="10%">Tsiky Balls Fromage</th>
                    <th class="text-center" width="10%">Tubz Pizza</th>
                    <th class="text-center" width="10%">Tubz Fromage</th>
                    <th class="text-center">Total Tonnage</th>
                    <th class="text-center">Ratio Gaz</th>
                    <th class="text-center" width="10%">Laser1</th>
                    <th class="text-center" width="10%">Laser2</th>
                    <th class="text-center" width="10%">Laser3</th>
                    <th class="text-center" width="10%">Fox</th>
                    <th class="text-center">Chaudiere</th>
                    <th class="text-center">TPJ</th>
                    <th>action</th>
                </tr>
            </thead>
            <tbody>
                <tr class="
                <?php if(isset($_SESSION["test"]) && $date == 0){
                }else{
                    echo "collapse" ;
                }
                ?> ">
                    <form action="insert_gaz.php" method="POST">
                        <th><?= date('Y-m-d') ?></th>
                        <th><input type="number" name="compteur_gaz" style="width: 100px" required min="<?= $compteur_gaz1 ?>"></th>
                        <th><input type="number" name="consommation_gaz" style="width: 100px" required min="<?= $consommation_gaz1 ?>"></th>
                        <th><input type="number" name="baremage" style="width: 100px" required min="<?= $baremage1 ?>"></th>
                        <th><input type="number" name="pellets" style="width: 100px"></th>
                        <th><input type="number" name="curl" style="width: 100px"></th>
                        <th><input type="number" name="essai" style="width: 100px"></th>
                        <th><input type="number" name="piwi" style="width: 100px"></th>
                        <th><input type="number" name="kidz_ballz_fromage" style="width: 100px"></th>
                        <th><input type="number" name="tsiky_balls_fromage" style="width: 100px"></th>
                        <th><input type="number" name="tubz_pizza" style="width: 100px"></th>
                        <th><input type="number" name="tubz_fromage" style="width: 100px"></th>
                        <th><input type="number" name="total_tonnage" style="width: 100px"></th>
                        <th><input type="number" name="ratio_gaz" style="width: 100px"></th>
                        <th class="bg-success"></th>
                        <th class="bg-success"></th>
                        <th class="bg-success"></th>
                        <th class="bg-success"></th>
                        <th class="bg-success"></th>
                        <th class="bg-success"></th>
                        <th><input type="submit" class="btn btn-primary"  name="submit" value="Envoyer"></th>    
                    </form>      
                </tr>
                <tr class="
                <?php if(isset($_SESSION["mpr"]) && $date == 0){
                }else{
                    echo "collapse" ;
                }
                ?> ">
                <form action="insert2_gaz.php" method="post">
                    <th><?= date('Y-m-d') ?></th>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="bg-success"> <input type="number" name="fox" style="width: 100px"></td>
                    <td class="bg-success"> <input type="number" name="tpj" style="width: 100px"></td>
                    <td class="bg-success"> <input type="number" name="chaudiere" style="width: 100px"></td>
                    <td class="bg-success"> <input type="number" name="laser1" style="width: 100px"></td>
                    <td class="bg-success"> <input type="number" name="laser2" style="width: 100px"></td>
                    <td class="bg-success"> <input type="number" name="laser3" style="width: 100px"></td>
                    <td><input type="submit" value="Ajouter" class="btn btn-primary"></td>
                </form>
                </tr>    
                    <?php
                    $connection=new mysqli("localhost","root","","consommation");
                    $sql = "SELECT * FROM `gaz_jbu2` order by id DESC";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $date = $row['date'];
                            $compteur_gaz = $row['compteur_gaz'];
                            $consommation_gaz = $row['consommation_gaz'];
                            $baremage = $row['baremage'];
                            $pellets = $row['pellets'];
                            $curl = $row['curl'];
                            $essai = $row['essai'];
                            $piwi = $row['piwi'];
                            $kidz_ballz = $row['kidz_ballz_fromage'];
                            $tsiky_ballz = $row['tsiky_balls_fromage'];
                            $tubz_pizza = $row['tubz_pizza'];
                            $tubz_fromage = $row['tubz_fromage'];
                            $total = $row['total_tonnage'];
                            $ratio = $row['ratio_gaz'];
                            $fox = $row['fox'];
                            $tpj = $row['tpj'];
                            $chaudiere = $row['chaudiere'];
                            $laser1 = $row['laser1'];
                            $laser2 = $row['laser2'];
                            $laser3 = $row['laser3'];

                            ?>
                <tr>
                            <form action="update2_gaz.php" method="post">
                                <td><?= $date?></td>
                                <td>
                                <?php
                                    if(empty($compteur_gaz) && empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="compteur_gaz" style="width: 100px" required min="<?= $compteur_gaz1 ?>">
                                    <?php
                                }else{
                                    echo "$compteur_gaz";
                                }
                                ?>
                                </td>
                                <td> 
                                    <input type="number" value="<?= $id ?>" name="id" class="collapse">
                                    <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="consommation_gaz" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$consommation_gaz";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="baremage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$baremage";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="pellets" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$pellets";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="curl" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$curl";
                                }
                                ?>
                                    </td>
                                <td>   
                                    <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="essai" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$essai";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="piwi" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$piwi";
                                }
                                ?>        
                            </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="kidz_ballz_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$kidz_ballz";
                                }
                                ?>    
                            </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tsiky_balls_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tsiky_ballz";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tubz_pizza" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tubz_pizza";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tubz_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tubz_fromage";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="total_tonnage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$total";
                                }
                                ?>
                                </td>
                                <td>   <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="ratio_gaz" style="width: 50px">
                                    <input type="submit" value="update" class="btn btn-warning">
                                    <?php
                                }else{
                                    echo "$ratio";
                                }
                                ?></td>
                        </form>

                        <form action="update_gaz.php" method="post">
                        <td class="bg-success">  <input type="number" value="<?= $id ?>" name="id" class="collapse"><?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="fox" style="width: 100px">
                            <?php
                        }else {
                            echo "$fox";
                        }
                        ?></td>
                        <td class="bg-success">
                            <?php
                            if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="tpj" style="width: 100px">
                            <?php
                        }else {
                            echo "$tpj";
                        }
                        ?></td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="chaudiere" style="width: 100px">
                            <?php
                        }else {
                            echo "$chaudiere";
                        }
                        ?>
                    </td>
                        <td class="bg-success">
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="laser1" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser1";
                        }
                        ?>
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="laser2" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser2";
                        }
                        ?>    
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="laser3" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser3";
                        }
                        ?>    
                        </td>
                        <td>
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="submit" value="update" class="btn btn-warning">
                            <?php
                        }
                        ?>

                            
                        </td>
                    </form>
                </tr>
                <?php
                            }
                        }


                        
                ?>
        </tbody>
    </table>
                
                
</body>
</html>