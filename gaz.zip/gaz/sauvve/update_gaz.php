<?php
 $connection=new mysqli("localhost","root","","consommation");
 $id = $_POST['id'];
 $fox = $_POST['fox'];
 $tpj = $_POST['tpj'];
 $chaudiere = $_POST['chaudiere'];
 $laser1 = $_POST['laser1'];
 $laser2 = $_POST['laser2'];
 $laser3 = $_POST['laser3'];

 $sql ="UPDATE `gaz_jbu2` SET `fox`='$fox',`tpj`='$tpj',
 `chaudiere`='$chaudiere',`laser1`='$laser1',`laser2`='$laser2',
 `laser3`='$laser3' WHERE id=$id";

$result = mysqli_query($connection, $sql);
if($result){
    header ("location: gaz_jbu2.php");
}