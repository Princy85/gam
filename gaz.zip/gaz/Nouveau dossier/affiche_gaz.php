<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
           
          
           <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Document</title>
</head>
<body>
<h1 style="text-align:center">Consommation gaz</h1>
        <table class="table table-striped table-bordered border-primary sticky-top">
            <thead class="bg-info sticky-top">
                <tr>       
                    <th class="text-center" width="7%">Date</th>
                    <th class="text-center" width="10%">Compteur gaz(m³)</th>
                    <th class="text-center" width="7%">Consommation gaz(m³)</th>
                    <th class="text-center">Baremage(%)</th>
                    <th class="text-center" width="7%">Pellets</th>
                    <th class="text-center" width="7%">Curl</th>
                    <th class="text-center" width="7%">Essai</th>
                    <th class="text-center" width="7%">Piwi</th>
                    <th class="text-center" width="10%">Kidz Ballz Fromage</th>
                    <th class="text-center" width="10%">Tsiky Balls Fromage</th>
                    <th class="text-center" width="10%">Tubz Pizza</th>
                    <th class="text-center" width="10%">Tubz Fromage</th>
                    <th class="text-center">Total Tonnage</th>
                    <th class="text-center">Ratio Gaz</th>
                    <th>action</th>
                </tr>
            </thead>
            <tbody>
                <tr >
                    <form action="insert_gaz.php" method="POST">
                        <th><?= date('Y-m-d') ?></th>
                        <th><input type="number" name="compteur_gaz" style="width: 100px"></th>
                        <th><input type="number" name="consommation_gaz" style="width: 100px"></th>
                        <th><input type="number" name="baremage" style="width: 100px"></th>
                        <th><input type="number" name="pellets" style="width: 100px"></th>
                        <th><input type="number" name="curl" style="width: 100px"></th>
                        <th><input type="number" name="essai" style="width: 100px"></th>
                        <th><input type="number" name="piwi" style="width: 100px"></th>
                        <th><input type="number" name="kidz_ballz_fromage" style="width: 100px"></th>
                        <th><input type="number" name="tsiky_balls_fromage" style="width: 100px"></th>
                        <th><input type="number" name="tubz_pizza" style="width: 100px"></th>
                        <th><input type="number" name="tubz_fromage" style="width: 100px"></th>
                        <th><input type="number" name="total_tonnage" style="width: 100px"></th>
                        <th><input type="number" name="ratio_gaz" style="width: 100px"></th>
                        <th><input type="submit" class="btn btn-primary"  name="submit" value="Envoyer"></th>    
                    </form>      
                </tr>    
                    <?php
                    $connection=new mysqli("localhost","root","","consommation");
                    $sql = "SELECT * FROM `gaz` order by id DESC";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result)){
                            $date = $row['date'];
                            $compteur_gaz = $row['compteur_gaz'];
                            $consommation_gaz = $row['consommation_gaz'];
                            $baremage = $row['baremage'];
                            $pellets = $row['pellets'];
                            $curl = $row['curl'];
                            $piwi = $row['essai'];
                            $essai = $row['piwi'];
                            $kidz_ballz = $row['kidz_ballz_fromage'];
                            $tsiky_ballz = $row['tsiky_balls_fromage'];
                            $tubz_pizza = $row['tubz_pizza'];
                            $tubz_fromage = $row['tubz_fromage'];
                            $total = $row['total_tonnage'];
                            $ratio = $row['ratio_gaz'];
                            ?>
                <tr>
                    <td><?= $date?></td>
                    <td><?= $compteur_gaz?></td>
                    <td><?= $consommation_gaz?></td>
                    <td><?= $baremage?></td>
                    <td><?= $pellets?></td>
                    <td><?= $curl?></td>
                    <td><?= $essai ?></td>
                    <td><?= $piwi?></td>
                    <td><?= $kidz_ballz?></td>
                    <td><?= $tsiky_ballz?></td>
                    <td><?= $tubz_pizza ?></td>
                    <td><?= $tubz_fromage?></td>
                    <td><?= $total ?></td>
                    <td><?= $ratio ?></td>
                </tr>
                <?php
                            }
                        }
                ?>
        </tbody>
    </table>
                <?php
                if(isset($_GET['pop'])){
                    ?>
                    <script>
                        Swal.fire({
                             icon: 'error',
                            title: 'Erreur',
                            text: 'Vous avez déjà executé une insertion aujourd\'hui',
                             
                    })
                    </script>
                    <?php
                }
                ?>
</body>
</html>