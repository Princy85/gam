<?php
 $connection=new mysqli("localhost","root","","consommation");
 
 $sql = "SELECT count(id) as nbr FROM `gaz` where date = date(now())";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result))
                        {
                            $date = (int)$row['nbr'];
                          }
                        }
if($date == 0){
  if(isset($_POST['submit'])){
    $compteur_gaz = $_POST['compteur_gaz'];
    $consommation_gaz = $_POST['consommation_gaz'];
    $baremage = $_POST['baremage'];
    $pellets = $_POST['pellets'];
    $curl = $_POST['curl'];
    $essai = $_POST['essai'];
    $piwi = $_POST['piwi'];
    $kidz_ballz = $_POST['kidz_ballz_fromage'];
    $tsiky_ballz = $_POST['tsiky_balls_fromage'];
    $tubz_pizza = $_POST['tubz_pizza'];
    $tubz_fromage = $_POST['tubz_fromage'];
    $total = $_POST['total_tonnage'];
    $ratio = $_POST['ratio_gaz'];
   
    $sql ="INSERT INTO `gaz`( `date`, `compteur_gaz`, `consommation_gaz`, `baremage`, `pellets`, `curl`, `essai`, `piwi`, `kidz_ballz_fromage`, `tsiky_balls_fromage`, `tubz_pizza`, `tubz_fromage`, `total_tonnage`, `ratio_gaz`) VALUES 
    (date(now()),$compteur_gaz,$consommation_gaz,$baremage,$pellets,$curl,$essai,$piwi,$kidz_ballz,$tsiky_ballz,$tubz_pizza,$tubz_fromage,$total,$ratio)";
   
   echo "$sql";
   $result = mysqli_query($connection, $sql);
   if($result){
  
     header ("location: affiche_gaz.php");
   }
    }


  
}else{
  header ("location: affiche_gaz.php?pop=ok");
}