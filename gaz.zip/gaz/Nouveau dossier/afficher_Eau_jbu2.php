<?php
  $host = 'localhost';
  $dbname = 'compteur_fm';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM eau_jbu2";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head>
<script>
    function AutoRefresh(t){
      setTimeout("location.reload(true);", t);
      }
</script>
</head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  

<?php
function formater($nombre, int $espacement = 3)
{
  $nombre = "$nombre";
  $retour = '';
   
  for($i = 0 ; $i < strlen($nombre) ; $i++) {
    if((strlen($nombre)-$i) % $espacement == 0) $retour .= ' ';
    $retour .= $nombre[$i];
  }
  return $retour;
}
echo formater("",) , '<br />';

?>

<body onload="javascript:AutoRefresh(120000);">
    <center>
 <h1>RELEVE COMPTEUR EAU JBU2</h1>
 <table class="table table-striped table-bordered border-primary">

   <thead class="bg-info sticky-top">

     <tr>          	   
       <th class="text-center">Date</th>
       <th class="text-center">Relevé JBU2</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       
       <td class="text-center"><?php echo htmlspecialchars($row['date']); ?></td>
       <td class="text-center"><?php echo formater($row['Eau_JBU2'],3,''); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>

 <div style="margin-bottom: 1%"; class="d-grid gap-2 col-2 mx-auto">
   <form>
   <input type=button class="btn btn-success" style="margin-bottom: 1%;" onclick=window.location.href='http://10.0.3.34:8080/consultation/accueil_usine.html'; value=Retour>
   </form>
 </div>

 </table>

 <script type="text/javascript">
		function tableToCSV() {

			// Variable to store the final csv data
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "eau.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
	</script>
    </center>
</body>
</html>