           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
           <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
$password = $_POST['password'];

if($password === "jbu2"){
    session_start();
    $_SESSION["test"]= "test";

    header ("location:gaz_jbu2.php");
}elseif($password === "mpr"){
    session_start();
    $_SESSION["mpr"]= "mpr";
    header ("location:gaz_jbu2.php");
}else{
    echo ".";
  ?>
     <script>
         Swal.fire(
         {
           icon: 'error',
           title: 'Erreur',
           text: 'Mot de passe incorrect',          
         });
                
         setTimeout(function() 
         {
           window.location.href = "gaz_jbu2.php";
         }, 3000); 
     </script>
               
   <?php
           }
   ?>