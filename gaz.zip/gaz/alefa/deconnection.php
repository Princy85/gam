<?php
session_start();
session_destroy();

header ("location:gaz_jbu2.php");
?>