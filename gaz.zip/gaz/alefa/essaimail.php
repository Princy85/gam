
 <?php
   $from = "MPR"; // sender
   $subject = " CONSO_GAZ_USINE";
 
$message .=
"Bonjour,

Veuillez voir ci-dessous le lien de consultation du consomation gaz aujourd'hui

lien de consultation : http://10.0.3.100:8080/gaz/gaz_jbu2.php

Cordialement\n";

   $to = "magasin.jbu@basan.mg";

   $array = explode(',', $to);

   $count = count($array);
   
   $res = array_slice($array, 0, 16);

print_r($res);

   mail( $to,$subject,$message,"From: $from\n");
?>