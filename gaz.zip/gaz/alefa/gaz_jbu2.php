<?php
session_start();

$connection=new mysqli("localhost","root","","consommation");
 $sql = "SELECT * FROM `gaz_jbu2` order by id ASC";
 $result = mysqli_query($connection,$sql);
 if($result){
     while($row=mysqli_fetch_assoc($result)){
         $compteur_gaz1 = $row['compteur_gaz'];
         $consommation_gaz1 = $row['consommation_gaz'];
         $baremage1 = $row['baremage'];
     }}
     
     $sql = "SELECT count(id) as nbr FROM `gaz_jbu2` where date = (SELECT CURDATE() - INTERVAL 1 DAY)";
                        $result = mysqli_query($connection,$sql);
                        if($result){
                            while($row=mysqli_fetch_assoc($result))
                              {
                                $date = (int)$row['nbr'];
                              }
                            }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
           <link rel="stylesheet" href="css/bootstrap.min.css"/>
           
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 
           <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

           <script src="../bootsrap/js/bootstrap.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>Relevée gaz JBU2</title>
</head>
<style>
    .fixed-column-width-table th,
.fixed-column-width-table td {
    width: 100px;
}
</style>
<body>
    <div class="fixed-top">
        <h1 style="text-align:center; margin-top:15px ;font-family:times new roman;  font-weight:bold">CONSOMMATIONS GAZ USINE</h1>
<div style="text-align:center" >
     <button class="btn btn-primary button  mb-3 mt-2"data-toggle="modal" data-target="#modalConnexion">Connexion</button> 

     <a href="deconnection.php" class="btn btn-danger ml-3 mb-3 mt-2" style="text-align:center">Déconnexion</a>
     
</div>
    </div>

    <table class="table table-striped table-bordered border-dark sticky-top text-center fixed-column-width-table" style="width: 200%; margin-top: 150px">
            <thead class=" text-light sticky-top align-middle  border-light">
                
                <tr>       
                    <td class="text-center align-middle">Date</td>
                    <td class="text-center" >Compteur gaz [m³]</td>
                    <td class="text-center" >Consommation gaz [m³]</td>
                    <td class="text-center" >Baremage [%]</td>
                    <td class="text-center" >Pellets</td>
                    <td class="text-center" >Curl</td>
                    <td class="text-center" >Essai</td>
                    <td class="text-center" >Piwi</td>
                    <td class="text-center" >Kidz Ballz Fromage</td>
                    <td class="text-center" >Tsiky Balls Fromage</td>
                    <td class="text-center" >Tubz Pizza</td>
                    <td class="text-center" >Tubz Fromage</td>
                    <td class="text-center" >Total Tonnage</td>
                    <td class="text-center" >Ratio Gaz</td>
                    <td class="text-center" >Laser1 [kg]</td>
                    <td class="text-center" >Laser2 [kg]</td>
                    <td class="text-center" >Laser3 [kg]</td>
                    <td class="text-center" >Fox [kg]</td>
                    <td class="text-center">Chaudière [kg]</td>
                    <td class="text-center">TPJ [kg]</td>
                    <td class="text-center">JBU2 [kg]</td>
                    <?php
                if(isset($_SESSION["mpr"])){
                ?>
                    <td class="text-center">Stock pr [Milliard Ar]</td>
<?php
}
?>

                    <td>action</td>
                </tr>
            </thead>
            <tbody>
                
                <?php
                // Créer un objet DateTime représentant la date d'aujourd'hui
$dateAujourdhui = new DateTime();

// Soustraire un intervalle d'un jour
$dateMoinsUnJour = $dateAujourdhui->sub(new DateInterval('P1D'));
?>
              <tr>
                    <?php 
                    if(isset($_SESSION["test"]) && $date == 0 ){
                    ?>
                                        <!--forme input jbu2-->
                    <form action="insert_gaz.php" method="POST">
                      
                      <th><?= $dateMoinsUnJour->format('Y-m-d') ?></th>
                      <th><div align="center"><input type="number" name="compteur_gaz" class="form-control" style="width: 100px; height:30px" required min="<?= $compteur_gaz1 ?>"></div></th>
                      <th> <div align="center"><input type="number"  class="form-control" name="consommation_gaz" style="width: 100px; height:30px;" required min="<?= $consommation_gaz1 ?>"></div></th>
                      <th><div align="center"><input type="number" name="baremage" class="form-control" style="width: 100px; height:30px" required min="<?= $baremage1 ?>"></div></th>
                      <th><div align="center"><input type="number" name="pellets" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="curl" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="essai" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="piwi" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="kidz_ballz_fromage" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="tsiky_balls_fromage" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="tubz_pizza" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="tubz_fromage" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="total_tonnage" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th><div align="center"><input type="number" name="ratio_gaz" class="form-control" style="width: 100px; height:30px"></div></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th class="bg-success"></th>
                      <th><div align="center"><input type="submit" class="btn btn-primary"  name="submit" value="Envoyer"></div></th>    
                  </form>
                    <?php
                    }
                    ?>
                    
      
                </tr>



                <tr>
                <?php 
                
                if(isset($_SESSION["mpr"]) && $date == 0){
                ?>

                   <form action="insert2_gaz.php" method="post">
                    <th><?= $dateMoinsUnJour->format('Y-m-d'); ?></th>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="bg-success"><input type="number" name="laser1" class="text-center" style="width: 100px; height:30px"></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="laser2" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="laser3" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="fox" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="chaudiere" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="tpj" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="number" name="jbu2" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td class="bg-success"> <div align="center"><input type="text" name="stockpr" class="form-control" style="width: 100px; height:30px"></div></td>
                    <td><input type="submit" value="Ajouter" class="btn btn-primary"></td>
                </form>

                <?php
                }
                ?>
            
                </tr>    
                    <?php
                    $connection=new mysqli("localhost","root","","consommation");
                    $sql = "SELECT * FROM `gaz_jbu2` order by id DESC";
                    $result = mysqli_query($connection,$sql);
                    if($result){
                        while($row=mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $date = $row['date'];
                            $compteur_gaz = $row['compteur_gaz'];
                            $consommation_gaz = $row['consommation_gaz'];
                            $baremage = $row['baremage'];
                            $pellets = $row['pellets'];
                            $curl = $row['curl'];
                            $essai = $row['essai'];
                            $piwi = $row['piwi'];
                            $kidz_ballz = $row['kidz_ballz_fromage'];
                            $tsiky_ballz = $row['tsiky_balls_fromage'];
                            $tubz_pizza = $row['tubz_pizza'];
                            $tubz_fromage = $row['tubz_fromage'];
                            $total = $row['total_tonnage'];
                            $ratio = $row['ratio_gaz'];
                            $laser1 = $row['laser1'];
                            $laser2 = $row['laser2'];
                            $laser3 = $row['laser3'];
                            $fox = $row['fox'];
                            $chaudiere = $row['chaudiere'];
                            $tpj = $row['tpj'];
                            $jbu2 = $row['jbu2'];
                            $stockpr = $row['stockpr'];

                            ?>
                <tr>
                            <form action="update2_gaz.php" method="post">
                                <td><?= $date?></td>
                                <td>
                                <?php
                                    if(empty($compteur_gaz) && empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="compteur_gaz" style="width: 100px" required min="<?= $compteur_gaz1 ?>">
                                    <?php
                                }else{
                                    echo "$compteur_gaz";
                                }
                                ?>
                                </td>
                                <td> 
                                    <input type="number" value="<?= $id ?>" name="id" class="collapse">
                                    <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="consommation_gaz" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$consommation_gaz";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="baremage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$baremage";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="pellets" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$pellets";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="curl" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$curl";
                                }
                                ?>
                                    </td>
                                <td>   
                                    <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="essai" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$essai";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="piwi" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$piwi";
                                }
                                ?>        
                            </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="kidz_ballz_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$kidz_ballz";
                                }
                                ?>    
                            </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tsiky_balls_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tsiky_ballz";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tubz_pizza" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tubz_pizza";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="tubz_fromage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$tubz_fromage";
                                }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="total_tonnage" style="width: 100px">
                                    <?php
                                }else{
                                    echo "$total";
                                }
                                ?>
                                </td>
                                <td>   <?php
                                    if(empty($consommation_gaz) && empty($baremage) && empty($curl) && empty($essai) && empty($piwi)
                                    && empty($kidz_ballz) && empty($tsiky_ballz) && empty($tubz_pizza) && empty($tubz_fromage) && empty($total) && empty($ratio) && isset($_SESSION["test"]))
                                {
                                    ?>
                                    <input type="number" name="ratio_gaz" style="width: 50px">
                                    <input type="submit" value="update" class="btn btn-warning">
                                    <?php
                                }else{
                                    echo "$ratio";
                                }
                                ?></td>
                        </form>

                        <form action="update_gaz.php" method="post">
                        <td class="bg-success">  <input type="number" value="<?= $id ?>" name="id" class="collapse"><?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="text-center"type="number" name="laser1" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser1";
                        }
                        ?></td>


                        <td class="bg-success" >
                            <?php
                            if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input class="text-center" type="number" name="laser2" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser2";
                        }
                        ?></td>


                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input  name="laser3" style="width: 100px">
                            <?php
                        }else {
                            echo "$laser3";
                        }
                        ?>
                    </td>
                        <td class="bg-success">
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="fox" style="width: 100px" required>
                            <?php
                        }else {
                            echo "$fox";
                        }
                        ?>
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="chaudiere" style="width: 100px" required>
                            <?php
                        }else {
                            echo "$chaudiere";
                        }
                        ?>    
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="number" name="tpj" style="width: 100px">
                            <?php
                        }else {
                            echo "$tpj";
                        }
                        ?>    
                        </td>
                        <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <div align="center">
                            <input class="text-center" type="number" name="jbu2" style="width: 100px"></div>
                            <?php
                        }else {
                            echo "$jbu2";
                        }
                        ?>    
                        </td>
                       






                    <?php
                if(isset($_SESSION["mpr"])){
                ?>
                    <td class="bg-success">
                        <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && empty($stockpr) && (isset($_SESSION["mpr"]))){
                            ?>
                            <div align="center">
                            <input class="text-center" type="number" name="stockpr" style="width: 100px"></div>
                            <?php
                        }else {
                            echo "$stockpr";
                        }
                        ?>    
                        </td>
                        <?php
                             }
                        ?>



                        
                        <td>
                            <?php
                        if(empty($tpj) && empty($chaudiere) && empty($laser1) && empty($laser2) && empty($laser3) && (isset($_SESSION["mpr"]))){
                            ?>
                            <input type="submit" value="update" class="btn btn-warning">
                            <?php
                        }
                        ?>        
                        </td>

                    </form>
                </tr>
                <?php
                            }
                        }


                        
                ?>
        </tbody>
    </table>
                
          <!-- POPUP MODAL-->
          
<div class="modal fade" id="modalConnexion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="text-align: center;">
        <h1 style="color:#000;">Connexion</h1>
     </div>
      <form action="connection.php" method="POST">
       
      <div class="modal-body">
      
          <div class="form-group">
            <label  style="font-weight:bold;margin-bottom:20px;color:#000"for="">Mot de Passe</label><br>
            <input type="password" name="password" placeholder="Veuillez entrer votre mot de passe" class="form-control">
              
         </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary" name="submit" ><img src="image/connection.png" alt="" width="30px">Connecter</button>
         </form>
      </div>
    </div>
  </div>
</div>      
</body>
</html>