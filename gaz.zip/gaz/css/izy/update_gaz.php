<?php
 $connection=new mysqli("localhost","root","","consommation");
 $id = $_POST['id'];
 $laser1 = $_POST['laser1'];
 $laser2 = $_POST['laser2'];
 $laser3 = $_POST['laser3'];
 $fox = $_POST['fox'];
 $chaudiere = $_POST['chaudiere'];
 $tpj = $_POST['tpj'];
 $jbu2 = $_POST['jbu2'];

 $sql ="UPDATE `gaz_jbu2` SET `laser1`='$laser1',`laser2`='$laser2',
 `laser3`='$laser3',`fox`='$fox',`chaudiere`='$chaudiere',`tpj`='$tpj',`jbu2`='$jbu2' WHERE id=$id";

$result = mysqli_query($connection, $sql);
if($result){
   
   //send mail
   $from = "MPR"; // sender
   $subject = " CONSO_GAZ_USINE";
 
$message .=
"Bonjour,

Veuillez voir ci-dessous le lien de consultation du consomation gaz aujourd'hui

lien de consultation : http://10.0.3.100:8080/gaz/gaz_jbu2.php

Cordialement\n";

   $to = "Patricia.Razafindrahova@basan.mg, Andry.Rakotofanomezantsoa@basan.mg, Davidson.Ramarozoky@basan.mg,Fitiavana.Rakotonirina@basan.mg, Hasimbola.Ramanatsandratana@basan.mg, Heriniaina.Rakotomanana@basan.mg, Mickael.Randriambolatiana@basan.mg, Jery.raobelina@basan.mg, Miora.Razafindratsita@basan.mg, Niry.Raveloarisoa@basan.mg,  Patrick.Rafalimanana@basan.mg, Onjanirina.Randriamanantsoa@basan.mg, Seheno.Ravololonirina@basan.mg, Sitrakiniaina.Raharimanana@basan.mg, Theodore.Rasolofomanana@basan.mg, elisaha.rakotoarisoa@basan.mg, Tantely.Rahaingoson@basan.mg, Ismael.Razafiarijaona@basan.mg, FreginahFaniry.Rakotonirina@basan.mg, Rijaniaina.Rafanoharana@basan.mg, Enintsoa.Rasolofomandimby@basan.mg";


   $array = explode(',', $to);

   $count = count($array);
   
   $res = array_slice($array, 0, 16);

print_r($res);

   mail( $to,$subject,$message,"From: $from\n");


    header ("location: gaz_jbu2.php");
}else{
    echo "$sql";
}