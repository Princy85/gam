﻿<?php
	session_start();
	try{
		$bdd = new PDO('mysql:host=localhost; port=3306; charset=utf8; dbname=inventaire_nancy', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
      	}
      	catch(Exception $e){
          		// En cas d'erreur, on affiche un message et on arrête tout
        	die('Erreur : '.$e->getMessage());
      	}
	$numero_du_jour_de_la_semaine = date('W');
	foreach ($_POST['base'] as $id => $nombre){
		$req = $bdd->prepare('INSERT INTO comptage1 (id, emplacement, code, designation, lot, x3, gisement, c1, unite, statut, pmp, date_inv, inventoriste, sem) SELECT id, emplacement, code, designation, lot, x3 , gisement, ?, unite, statut, pmp, NOW(), ?, ? FROM zinventaire1 WHERE id=?');
		$req->execute(array($nombre, $_SESSION['inventoriste'], $numero_du_jour_de_la_semaine, $id));
		$bdd->exec('UPDATE comptage1 SET prix_x3 = pmp * x3');
		$bdd->exec('UPDATE comptage1 SET prix_phys = pmp * c1');
		$bdd->exec('UPDATE comptage1 SET ecart = c1 - x3');
		$bdd->exec('UPDATE comptage1 SET ecart_valeur = prix_phys - prix_x3');
		$reponse = $bdd->prepare('SELECT * FROM comptage1 WHERE c1=? AND inventoriste=? AND sem=? AND  id=?');
		$reponse->execute(array($nombre, $_SESSION['inventoriste'], $numero_du_jour_de_la_semaine, $id));
		while ($donnees = $reponse->fetch()){

		}
		$req = $bdd->prepare('DELETE FROM zinventaire1 WHERE id=?');
		$req->execute(array($id));
		$req->closeCursor();
	}

	header('Location: Comptage1.php');	
?>