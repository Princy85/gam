 <?php
  $host = 'localhost';
  $dbname = 'inventaire_nancy';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "DELETE FROM  zinventaire1";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Error");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }

        $success_message = urlencode("Suppression  avec succès.");
        header("Location: http://10.0.3.19:8080/INDEX - Copie/connexion_inventaire.php?success=$success_message");
?> 