<?php
	function base_url(){
		return "http://10.0.3.19:8080/inventaire_nancy";
	}
?>
