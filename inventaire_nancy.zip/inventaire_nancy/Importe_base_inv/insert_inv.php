<?php
include('function.php');
$con = mysqli_connect("localhost", "root", "", "inventaire_nancy");

if ($con) {
    $file = $_FILES['csvfile']['tmp_name'];
    $handle = fopen($file, "r");
    $i = 0;
    $message = 'Erreur sur : <br> <ul>';
    $ligne = 0;

    mysqli_begin_transaction($con);

    if ($handle !== false) {
        $zinventaire1 = preg_replace('/[^a-zA-Z0-9_]/', '_', rtrim($_FILES['csvfile']['name'], ".csv"));

        while (($cont = fgetcsv($handle, 2000, ";")) !== false) {
            $row_errors = '';

            if ($i == 0) {
                // Création de la table
                $columns = [];
                foreach ($cont as $column) {
                    $columns[] = "`" . preg_replace('/[^a-zA-Z0-9_]/', '_', $column) . "` VARCHAR(255)";
                }
                $query = "CREATE TABLE IF NOT EXISTS `$zinventaire1` (" . implode(", ", $columns) . ");";
                if (!mysqli_query($con, $query)) {
                    $error_message = urlencode("Erreur de création de la table : " . mysqli_error($con));
                    header("Location:" . base_url() . "/Importe_base_inv/Uploadanddelete.php?error=$error_message");
                    exit();
                }
            } else {
                $ligne++; 
                // Validation des données
                $id = mysqli_real_escape_string($con, $cont[0]);
                $emplacement = mysqli_real_escape_string($con, $cont[1]);
                $code = mysqli_real_escape_string($con, $cont[2]);
                $designation = mysqli_real_escape_string($con, $cont[3]);
                $lot = mysqli_real_escape_string($con, $cont[4]);
                $x3 = mysqli_real_escape_string($con, $cont[5]);
                $unite = mysqli_real_escape_string($con, $cont[6]);
                $gisement = mysqli_real_escape_string($con, $cont[7]);
                $statut = mysqli_real_escape_string($con, $cont[8]);
                $pmp = mysqli_real_escape_string($con, $cont[9]);
                $inventoriste = mysqli_real_escape_string($con, $cont[10]);

                if ($id === '' || $emplacement === '' || $code === '' || $designation === '' || $lot === '' || $x3 === '' || $unite === '' || $gisement === '' || $statut === '' || $pmp === '' || $inventoriste === '') {
                    $row_errors .= '<li> Il y a une ou plusieurs colonnes vides.</li>';
                }
                if (!is_numeric($emplacement) || strlen($emplacement) != 3) {
                    $row_errors .= '<li> L\'emplacement est invalide, il doit être un nombre de 3 chiffres : ' . $emplacement . '</li>';
                }
                if (!is_numeric($code) || strlen($code) != 9) {
                    $row_errors .= '<li> Le code est invalide, il doit être un nombre de 9 chiffres : ' . $code . '</li>';
                }
                if (!is_numeric($x3) || $x3 <= 0) {
                    $row_errors .= '<li> La valeur de x3 est invalide, elle doit être un nombre positif : ' . $x3 . '</li>';
                }
                if (!is_numeric($pmp) || $pmp <= 0) {
                    $row_errors .= '<li> La valeur de pmp est invalide, elle doit être un nombre positif : ' . $pmp . '</li>';
                }

                // Si aucune erreur n'est détectée, on insère les données
                if (empty($row_errors)) {
                    $values = [
                        "'$id'",
                        "'$emplacement'",
                        "'$code'",
                        "'$designation'",
                        "'$lot'",
                        "'$x3'",
                        "'$unite'",
                        "'$gisement'",
                        "'$statut'",
                        "'$pmp'",
                        "'$inventoriste'"
                    ];

                    $query = "INSERT INTO `$zinventaire1` VALUES (" . implode(", ", $values) . ")";

                    if (!mysqli_query($con, $query)) {
                        $row_errors .= '<li>Erreur d\'insertion des données : ' . mysqli_error($con) . '</li>';
                    }
                }

                if (!empty($row_errors)) {
                    $message .= 'Ligne ' . $ligne . " : " . $row_errors . "<br/>";
                }
            }
            $i++; 
        }
        fclose($handle);

        if ($message != 'Erreur sur : <br> <ul>') {
            mysqli_rollback($con);
            $message .= '</ul>';
            $error_message = urlencode($message);
            header("Location:" . base_url() . "/Importe_base_inv/Uploadanddelete.php?error=$error_message");
            exit();
        } else {
            mysqli_commit($con);
            $success_message = urlencode("Les données ont été importées avec succès.");
            header("Location:" . base_url() . "/Importe_base_inv/Uploadanddelete.php?success=$success_message");
            exit();
        }
    } else {
        $error_message = urlencode("Erreur lors de l'ouverture du fichier. Veuillez réessayer.");
        header("Location:" . base_url() . "/Importe_base_inv/Uploadanddelete.php?error=$error_message");
        exit();
    }
} else {
    $error_message = urlencode("Connexion à la base de données échouée : " . mysqli_connect_error() . " Veuillez réessayer.");
    header("Location:" . base_url() . "/Importe_base_inv/Uploadanddelete.php?error=$error_message");
    exit();
}
?>
