<html>

    <head>
        <title>csv insert</title>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/style_upload.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
        <link rel="stylesheet" href="css/styl.css"/>
        <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
        <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>
<style type="text/css">
.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    padding: 15px;
    border-radius: 5px; 
    font-family: Arial, sans-serif; 
    margin: auto;
    margin-top:50px ;
    width: 600px;
    margin-left: 650px;
}

/* Styles pour les messages de succès */
.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    padding: 15px;
    border-radius: 5px; 
    font-family: Arial, sans-serif; 
    margin: auto;
    margin-top:50px ;
    width: 600px;
    margin-left: 650px;
}

</style>
    </head>
<body style="background-color: rgb(230, 230, 230, 1.0);">
    <?php
        if (isset($_GET['error'])) {
            $error_message = $_GET['error']; // Échapper les caractères spéciaux
            echo '<div class="error">' . $error_message . '</div>';
        }elseif (isset($_GET['success'])) {
            echo '<div class="success">' .$_GET['success'] . '</div>';
        }
?>
<div class="upload-inventaire">
    <fieldset class="inputTextWrap">
         <h1>Mise à jour des inventaires de stock </h1>
            <form action="insert_inv.php" method="post" enctype="multipart/form-data">
                        
                <div class="inputTextWrap">
                    <input class="form-control" type="file" name="csvfile" required="required"/>
                </div>

                <div class="btn">
                    <input class="btn btn-primary" type="submit" value="Télécharger" style="margin-top:30px;" />
                </div>     

            </form>
                <form action="deletetable.php" method="post" enctype="multipart/form-data">
                    <div class="btn">
                <input class="btn btn-danger" type="submit" value="Supprimer" />
                  </div> 
            </form>
        </fieldset>
</div>
</body>
</html>