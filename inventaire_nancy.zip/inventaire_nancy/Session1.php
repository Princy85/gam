﻿<?php
	session_start();
	$_SESSION['inventoriste'] = $_POST['inventoriste'];
	header('Location: Comptage1.php');	
?>