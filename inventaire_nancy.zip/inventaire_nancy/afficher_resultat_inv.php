<?php
  $host = 'localhost';
  $dbname = 'inventaire_nancy';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM comptage1 ";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>resultat inventaire mpr</title>
</head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  
<body>
    <center>
 <h1>RESULTAT INVENTAIRE MPR</h1>
 <table class="table table-striped table-bordered" id="tableau" style="margin-top: 30px;">
   <thead>
     <tr>
       <th class="text-center">N°id</th>
       <th class="text-center">Emplacement</th>
       <th class="text-center">Code</th>
       <th class="text-center">Désignation</th>
       <th class="text-center">Lot</th>
       <th class="text-center">x3</th>
       <th class="text-center">Gisement</th>
       <th class="text-center">c1</th>
       <th class="text-center">Ecart</th>
       <th class="text-center">Unite</th>
       <th class="text-center">pmp</th>
       <th class="text-center">Ecart valeur</th>
       <th class="text-center">Date inventaire</th>
       
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td class="text-center" ><?php echo htmlspecialchars($row['id']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['emplacement']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['code']); ?></td>
       <td class="text-center" ><?php echo htmlspecialchars($row['designation']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['lot']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['x3']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['gisement']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['c1']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['ecart']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['unite']); ?></td> 
       <td class="text-center"><?php echo htmlspecialchars($row['pmp']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['ecart_valeur']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['date_inv']); ?></td>
      
    </tr>
     <?php endwhile; ?>
   </tbody>
   <input class="zonesaisie" type="text" placeholder="Recherche..." id="maRecherche" onkeyup="filtrer()">

   <button type="button" onclick="tableToCSV()">
			Download CSV
		</button>
 </table>

<script type="text/javascript">
    function tableToCSV() {

      // Variable to store the final csv data
      var csv_data = [];

      // Get each row data
      var rows = document.getElementsByTagName('tr');
      for (var i = 0; i < rows.length; i++) {

        // Get each column data
        var cols = rows[i].querySelectorAll('td,th');

        // Stores each csv row data
        var csvrow = [];
        for (var j = 0; j < cols.length; j++) {

          // Get the text data of each cell
          // of a row and push it to csvrow
          csvrow.push(cols[j].innerHTML);
        }

        // Combine each column value with comma
        csv_data.push(csvrow.join(","));
      }

      // Combine each row data with new line character
      csv_data = csv_data.join('\n');

      // Call this function to download csv file
      downloadCSVFile(csv_data);

    }

    function downloadCSVFile(csv_data) {

      // Create CSV file object and feed
      // our csv_data into it
      CSVFile = new Blob([csv_data], {
        type: "text/csv"
      });

      // Create to temporary link to initiate
      // download process
      var temp_link = document.createElement('a');

      // Download csv file
      temp_link.download = "GfG.csv";
      var url = window.URL.createObjectURL(CSVFile);
      temp_link.href = url;

      // This link should not be displayed
      temp_link.style.display = "none";
      document.body.appendChild(temp_link);

      // Automatically click the link to
      // trigger download
      temp_link.click();
      document.body.removeChild(temp_link);
    }
  </script>
  <script>
function filtrer()
{
var filtre, tableau, ligne, cellule, i, texte;

filtre = document.getElementById("maRecherche") .value.toUpperCase();
tableau = document.getElementById("tableau");
ligne = tableau.getElementsByTagName("tr");

for (i = 0; i < ligne.length; i++)
{
cellule = ligne[i].getElementsByTagName("td")[0];
if(cellule)
{
texte = cellule.innerText;
if (texte.toUpperCase().indexOf(filtre) > -1)
{
ligne[i].style.display = "";
}
else
{
ligne[i].style.display = "none";
}
}
}
}
</script>

 </center>
</body>
</html>