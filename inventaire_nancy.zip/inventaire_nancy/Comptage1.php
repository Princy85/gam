﻿<?php
// On démarre la session AVANT d'écrire du code HTML
session_start();

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<title>Inventaire</title>
		<link rel="icon" type="image/png" href="Magasin PR.png">
                <link rel="stylesheet" href="Accueil.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		
		    body {
		    	background: linear-gradient(rgba( 43, 83, 222 .5), rgba( 43, 83, 222 .5)), url("Inventaire.jpg") no-repeat fixed;
		    	background-position: center;
		    	background-size: cover; 
		       }
            .container {
            	width: 1200px;
            	margin:0 auto;
            }
			#inventaire {
			    width: 1000px;
				height: 700px;
			}
			h1{
			 color: white;
			 font-size: 20px;
			 text-align: center;
			 font-weight: bold;
			
			}
			h3{
				color: black;
				text-align: center;
			}

			h6{
				color: white;	
			}
			span {
				color: green;
			}
			
			.card {
				height: auto;
			}
			.table-borderless tr { border: 0; 
			}
			td {
			color: white;
			}
                       
			
			[type="date"]{
  				background: red
			}

			@media only screen and (min-width: 992px) {
				body {
		    	background color: blue;
		    	background-position: center center;
		    	background-size: cover; 
                        max-width: 80%; 
		       }
				.container {
            	max-width: 100%;
            	
            }
				#inventaire {
					max-width: 100%;
					height: auto;
				}
				img {
					max-width: 100%;
					height: auto;
				}
				.btn, .btn-dark {
					margin:0 auto;
					display: block;
				}
			}
			
			@media only screen and (max-width: 992px) {
				body {
		    	background color: black;
		    	background-position: center center;
		    	background-size: cover; 
                        max-width: 100%; 
		       }
				.container {
            	max-width: 100%;
            	margin:0 auto;
            	
                }
				#inventaire {
					max-width: 100%;
					height: auto;
				}
				img {
					max-width: 100%;
					height: auto;
				}
				
				td {
					font-size: 14px;
				}
				h3 {
					font-size: 19px;
					font-weight: bold;
					text-align: center;
				}
				.card {
					
					height: auto;
					font-size: 13px;
				}
				.form-group {
					margin:0 auto;
					
				}
				.btn, .btn-dark {
					margin:0 auto;
					display: block;
				}
				

			}
			@media only screen and (max-width: 640px) {	
                                 body {
		    	         background color: black; 
		    	         background-position: center bottom;
		    	         background-size: cover;
                                 max-width: 100%; 
		                 }
				.container {
            	                max-width: 100%;
            	                margin:0 auto;
                                height: auto;
                                position: relative;
            	
                                }
				#inventaire {
					max-width: 100%;
					height: auto;
				}
				img {
					max-width: 100%;
					height: auto;
				}
				.card {
					
					height: auto;
					font-size: 10px;
					display: inline-grid;
					margin:0 auto;
                                        

				}
				#pro {
					height: 360px;
				}
				
				.table {
					border-spacing: 4px;
					height: 150px;
                                        margin-left: 2%;
                                        display: block;

					
				}
				td {
					font-size: 10px;
					
				}
				tr {
					height: 11px;
				}
				h3 {
					font-size: 17px;
				}
				
				.btn, .btn-dark {
					margin:0 auto;
					display: block;
					font-size: 13px;
				}
				.form-group {
					margin:0 auto;
                                        display: block;
					
				}
                               
				
			}
       	</style>
	</head>
	<body style="background-color: black;">
	<?php
		try{
        
			$bdd = new PDO('mysql:host=localhost; port=3306; charset=utf8; dbname=inventaire_nancy', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
          
				// En cas d'erreur, on affiche un message et on arrête tout
			die('Erreur : '.$e->getMessage());
		}
	?>
              <header>
		
 <nav class="card-body">
		<h1><b>OUTIL INVENTAIRE MPR</b></h1>


			
</nav>
     
   </head>
   <body onload=showDate();>
      <span id='horloge' style="background-color:black;color:black;font-size:30px;">
</span>
   </body>

						<?php
      
						try{
        
							$bdd = new PDO('mysql:host=localhost; port=3306; charset=utf8; dbname=inventaire_nancy', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
      
						}
      
						catch(Exception $e){
          
										// En cas d'erreur, on affiche un message et on arrête tout
        
							die('Erreur: '.$e->getMessage());
      
						}
       
						$reponse = $bdd->prepare('SELECT * FROM profil WHERE nom_prenom=?');

        			
					?>
							
					<?php
 
						$reponse->closeCursor();
					?> 
						
						</div>
					</div>
				</ul>
			</div>
		
	     </header>
              
		<div class="container">
        
         
			
               				<span class="navbar-toggler-icon"></span>
            			</button>
	
						<a class="nav-item active"><a class="nav-link" href="#" style="font-size: 18px; font-family: verdana;"></a>
			
					</ul>
					<ul class="navbar-nav ml-auto">
                 	<form method="post" action="Session1.php" class="form-group row">
      				<select id="name" type="text" name="inventoriste" class="form-control" required>

					<?php
						if (! isset($_SESSION['inventoriste'])) {
									}
	
						?>
					
                  				<option value="" selected>Choisir Equipe</option>
                  				<option value="equipe1">Equipe 1</option>
                  				<option value="equipe2">Equipe 2</option>
                  				<option value="equipe3">Equipe 3</option>
                  				<option value="equipe4">Equipe 4</option>
                  				<option value="equipe5">Equipe 5</option>
                  				<option value="equipe6">Equipe 6</option>
                  				<option value="equipe7">Equipe 7</option>
                  				<option value="equipe8">Equipe 8</option>
                  				<option value="equipe9">Equipe 9</option>
                  				<option value="equipe10">Equipe 10</option>
                  				<option value="equipe11">Equipe 11</option>
                  				<option value="equipe12">Equipe 12</option>
                  				<option value="equipe13">Equipe 13</option>
                  					</select>
                  					
					
						<button type="submit" class="btn-danger" style="background-color: green;">Liste Article</button>
					                 	
					</form>
                   	</ul>
				</div> 
			</nav>
                
       </div>

	
	    			</div>
	    		</div> 



		<?php
            		$reponse = $bdd->prepare('SELECT MIN(id) AS mini_id, code, designation, x3, unite, gisement FROM zinventaire1 WHERE inventoriste =? GROUP BY (id)');

           		$reponse->execute(array($_SESSION['inventoriste']));


		?> 

                                           

			<div class="form-group row">
		 		<div id="pro" class="card-body">  
					<div class="card-body p-0 card-block">
		     				<div class="p-5">  




		<?php
      			while ($donnees = $reponse->fetch()){
    		?>
    		


				<div style="text-align: center; color: burlywood;font-size: 30px;">
				   
				   <div style="text-align: center; color: black;font-weight: bold;">
                  <h2><strong><?php echo $donnees['mini_id']?></strong></h2>
               </div>                                       			   
    				
    				<div style="font-weight: bolder;color: blue; font-size: 38px;"> <?php echo $donnees['code']?>
    		   	</div>
    		
    				<div style="font-weight: 120; font-size: 25px; color: #f7380d;font-weight: bold;"><?php echo $donnees['designation']?>
    				</div>

    				<div style="font-weight: 120; font-size: 25px; color: white;font-weight: bold;"><?php echo $donnees['gisement']?>
    				</div>
		
    				<div style="text-align: center; margin-top: 10px;color:#177935 ;font-size: 26px;font-weight: bold;">
                X3: <?php echo $donnees['x3']?> <?php echo $donnees['unite']?> 													
    		   	<form action="Comptage1_post.php" method="post" style="background-color: black;">
 	    				<h1 style="margin-top: 10px; margin-bottom: 20px; color: ;">Quantité physique :</h1>

 		    			<div class="form-group"> 
     						<input type="number" step="any" class="form-control" id="name" name="base[<?= $donnees['mini_id']; ?>]" required>
     						
				
     					<div class="col-xs-4 col-sm-8 col-md-4" style="margin:0"><?php echo $donnees['unite']?>
     					</div>

     				
						<button type="Submit" class="btn btn-primary" value="Envoyer">OK Evoyer</button>
	    			</form>	
	    		</div> 
	 


 
<hr>
<hr>
<hr>
<hr>
	    						
</span> 

	<?php 	} $reponse->closeCursor(); ?>
      		
	  					</div>
	  				</div>
	  			</div>
	  		</div>
	  	</div>
	</div>
</body>
</html>
