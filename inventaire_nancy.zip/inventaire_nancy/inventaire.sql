SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `comptage1` (
  `id` int(11) NOT NULL,
  `emplacement` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `lot` varchar(255) NOT NULL,
  `x3` double NOT NULL,
  `gisement` varchar(255) NOT NULL,
  `c1` double NOT NULL,
  `ecart` double NOT NULL,
  `unite` varchar(255) NOT NULL,
  `statut` varchar(255) NOT NULL,
  `pmp` double NOT NULL,
  `prix_x3` double NOT NULL,
  `prix_phys` double NOT NULL,
  `ecart_valeur` double NOT NULL,
  `observation` varchar(255) NOT NULL,
  `date_inv` date NOT NULL,
  `inventoriste` varchar(255) NOT NULL,
  `sem` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `profil` (
  `nom_prenom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `matricule` double NOT NULL,
  `service` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `profil` (`nom_prenom`, `prenom`, `matricule`, `service`) VALUES
('raharimanana', 'sitraka', 3083, 'sm');


CREATE TABLE `zinventaire1` (
  `id` int(255) DEFAULT NULL,
  `emplacement` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `lot` varchar(255) DEFAULT NULL,
  `x3` varchar(255) DEFAULT NULL,
  `unite` varchar(255) DEFAULT NULL,
  `gisement` varchar(255) DEFAULT NULL,
  `statut` varchar(255) DEFAULT NULL,
  `pmp` varchar(255) DEFAULT NULL,
  `inventoriste` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `comptage1`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `comptage1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2527;
COMMIT;
