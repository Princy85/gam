<?php
$con=mysqli_connect("localhost","root","","stock_pr");
if($con)
{
$file=$_FILES['csvfile']['tmp_name'];
$handle=fopen($file,"r");
$i=0;
while(($cont=fgetcsv($handle,2000,","))!==false)
    {
        $stock_date=rtrim($_FILES['csvfile']['name'],".csv");
        if($i==0)
        {            
        $id=$cont[0];
        $emplacement=$cont[1];
        $article=$cont[2];
        $designation=$cont[3];
        $quantite=$cont[4];
        $unite=$cont[5];
        $prix=$cont[6];
        $gisement=$cont[7];
        
        $query="CREATE TABLE $stock_date($id INT(255), $emplacement VARCHAR(255), $article VARCHAR(255), $designation VARCHAR(255), $quantite VARCHAR(255), $unite VARCHAR(255), $prix VARCHAR(255), $gisement VARCHAR(255));";
        mysqli_query($con,$query);
        }
        else{
            $query="INSERT INTO $stock_date($id,$emplacement,$article,$designation,$quantite,$unite,$prix,$gisement) VALUES ('$cont[0]','$cont[1]','$cont[2]','$cont[3]','$cont[4]','$cont[5]','$cont[6]','$cont[7]')";
            mysqli_query($con,$query);
            }
        $i++;
    }
}else{
    echo"conncetion failed";
}

header('location:http://10.0.3.19:8080/stocks/afficher_stock.php');
?>