<html>
    <head>
        <title>csv insert</title>
    </head>
<body>
    <div style="margin-top: 5px; margin-bottom: 30px">
    <a href="http://10.0.3.19:8080/index/interface_stock.html" >Retour</a>
</div>

    <form action="insert3.php" method="post" enctype="multipart/form-data">
        <input type="file" name="csvfile" required="required"/>
        <input type="submit" value="upload" />
    </form>
        <form action="deletetable.php" method="post" enctype="multipart/form-data">
        <input type="submit" value="Delete" />
    </form>
</body>
</html>