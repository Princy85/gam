 <?php
  $host = 'localhost';
  $dbname = 'stock_pr';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "DELETE FROM  gam";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Error");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }

  header('location:http://10.0.3.19:8080/Stocks/Uploadanddelete.php');
?> 