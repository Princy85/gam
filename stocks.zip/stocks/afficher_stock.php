<?php 
	include "connection.php"
?>

<!DOCTYPE html>
<html>
<head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/sytle_formulaire.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
      	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
        <link rel="stylesheet" href="css/styl.css"/>
        <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
        <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script> 


</head>
<div class="display-1 text-center" style="color: #fd7e14 ;font-weight: 600;margin-top: 0px;background: #fff;">
<h1>STOCK A DATE</h1>
 		 
</div>

 		 <div class="container-fluid" style="margin-bottom: 20px;">
		<input class="form-control" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search">
	</div>




	
<body >
	<div>

		  <table class="table" id="myTable">

		   <thead style="background: -webkit-linear-gradient(left, #adb5bd, #dee2e6);">
		     <tr>     	 
		       <th class="text-center">Section</th>
		       <th class="text-center">Articles</th>   
		     </tr>
		   </thead>

		   <tbody >

				<?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)):?>

				     <tr>     	 
				       <td><?php echo htmlspecialchars($row['emplacement']);?></td>
				       <td>
				       	<div style="color: #fd7e14 ;font-size: 20px;font-weight: 600"><?php echo htmlspecialchars($row['article']);?></div>
				       	<div><?php echo htmlspecialchars($row['designation']);?></div>
				       	<div><?php echo htmlspecialchars($row['gisement']);?></div>
				       	<div style="font-weight: 600"><?php echo htmlspecialchars("Qté:");?><?php echo htmlspecialchars($row['quantite']);?>
				       	<?php echo htmlspecialchars($row['unite']);?></div>   												 
				       	<div style="color: #198754  ;font-weight: 600;font-stretch:semi-expanded "><?php echo htmlspecialchars("PMP:");?> <?php echo number_format($row['prix'])," MGA";?></div>
				       </td>
				      </tr>

				<?php endwhile; ?>

			</tbody>
		</table>
	</div>




	<script> 
		function myFunction() {
		  // script filtre
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("myInput");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");

		  // Loop through all table rows, and hide those who don't match the search query
		  for (i = 0; i < tr.length; i++) {
		    td = tr[i].getElementsByTagName("td")[1];
		    if (td) {
		      txtValue = td.textContent || td.innerText;
		      if (txtValue.toUpperCase().indexOf(filter) > -1) {
		        tr[i].style.display = "";
		      } else {
		        tr[i].style.display = "none";
		      }
		    }
		  }
		}
			</script>

			<script type="text/javascript">
		function tableToCSV() {

			// script csv
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "eau.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
			</script>
</body>
</html>