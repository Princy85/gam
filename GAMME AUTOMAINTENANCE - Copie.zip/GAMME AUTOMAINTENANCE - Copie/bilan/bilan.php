<?php
    session_start();
    $code = $_SESSION['code'];
    if(!isset($_SESSION['code'])){
        header("location:../home/home.php");
    }
    

     include('../connection.php'); 
    if(isset($_GET['search']))
    {
      $search = utf8_decode($_GET['search']);
      $sql="SELECT*FROM bilan WHERE composant like '%$search%' 
      or etat like '%$search%' or nom_machine like '%$search%'
      or bilan like '%$search%' or observation like '%$search%'
      ORDER BY date DESC";
      
      //select nombre de bilan
      $sql2="SELECT COUNT(id_bilan) as nbr FROM bilan WHERE composant like '%$search%' 
      or etat like '%$search%' or nom_machine like '%$search%'
      or bilan like '%$search%' or observation like '%$search%'
      ORDER BY date DESC";

      //select nombre de ok
       $sql3="SELECT COUNT(id_bilan) as nbr FROM bilan WHERE bilan like 'OK' and (composant like '%$search%' 
       or etat like '%$search%' or nom_machine like '%$search%'
       or observation like '%$search%' or bilan like '%$search%')
       ORDER BY date DESC";

      //select nombre de ko
        $sql4="SELECT COUNT(id_bilan) as nbr FROM bilan WHERE bilan like 'KO' and (composant like '%$search%' 
        or etat like '%$search%' or nom_machine like '%$search%'
        or observation like '%$search%' or bilan like '%$search%')
        ORDER BY date DESC";
         
        
    }elseif(isset($_POST['date_debut']) ){
        $date1 = $_POST['date_debut'];
        $date2 = $_POST['date_fin'];
        $sql= "SELECT*FROM bilan WHERE date between '$date1' and '$date2'";
        $sql2= "SELECT COUNT(id_bilan) as nbr FROM bilan WHERE date between '$date1' and '$date2'";
        $sql3= "SELECT COUNT(id_bilan) as nbr FROM bilan WHERE bilan like 'OK' and date between '$date1' and '$date2'";
        $sql4= "SELECT COUNT(id_bilan) as nbr FROM bilan WHERE bilan like 'KO' and date between '$date1' and '$date2'";
    }
    else{
    $sql="SELECT*FROM bilan ORDER BY date DESC";
    $sql2="SELECT COUNT(id_bilan) as nbr FROM bilan";
    $sql3="SELECT COUNT(id_bilan) as nbr FROM bilan where bilan like 'OK'";
    $sql4="SELECT COUNT(id_bilan) as nbr FROM bilan where bilan like 'KO'";
    }

        //nombre de bilan (OK/KO)
        $result2 =mysqli_query($connection,$sql2);
        if($result2){
        $row2=mysqli_fetch_assoc($result2);
        $nbr_bilan = $row2['nbr'];
       }
        
       //nombre de OK
       $result3 =mysqli_query($connection,$sql3);
       if($result3){
        $row3 = mysqli_fetch_assoc($result3);
        $nbr_OK = $row3['nbr'];
        $nbr_OK2 = $nbr_OK/$nbr_bilan;
        $nbr_OK2 *= 100;
        $nbr_OK2 = round($nbr_OK2, 2);
        }
        
        //nombre de KO
        $result4 =mysqli_query($connection,$sql4);
        if($result2){
        $row4=mysqli_fetch_assoc($result4);
        $nbr_KO = $row4['nbr'];
        $nbr_KO2 = $nbr_KO/$nbr_bilan;
        $nbr_KO2 *= 100; 
        $nbr_KO2 = round($nbr_KO2, 2);
        }

    ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilan</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../style.css">
    <script src="../bootstrap/js/bootstrap.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #03224c">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">GAMME AUTOMAINTENANCE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 mt-2">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="../home/home.php?user=ok">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../ligne/ligne.php?user=ok">Ligne</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../machine/machine.php?user=ok">Machine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../action/action.php?user=ok">Action</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../bilan/bilan.php?user=ok">Bilan des actions finies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../planification/planification.php?user=ok">Planification des actions</a>
          </li>
        </ul>
        <form class="d-flex mt-3" action="bilan.php" method="GET">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search">
          <a href="bilan.php" class="btn btn-success"> Actualiser</a>
        </form>
      </div>
    </div>
  </div>
</nav>
    <div class="container" style="margin-top: 100px">
            <h1 class="display-4" style="align-items: center;">Bilan des actions finies</h1>
        </div>
    <div class="container pt-3">
        <form action="bilan.php" method="post">
                <label for="date_debut">Date debut</label>
                <input type="date" name="date_debut" id="date_debut">
                <label for="date_fin">Date fin</label>
                <input type="date" name="date_fin" id="date_fin">
                <input class="ml-3 btn btn-success" type="submit" value="Rechercher">
        </form>
        <div class="float-right mt-3">
                    <form action="bilan_excel.php" method="post">
                      <input type="text" name="nomf" value="bilan">
                      <input class="collapse" type="text" value="<?= $sql ?>" name="sql">
                      <button type="submit" style="border: none; background-color: #96414100;"><img src="../image/excel (1).png" width="30px" ></button>
                    </form>
        </div>
            <!-- liste des nombre d'action -->
    <!-- card -->
          
<div class="container pt-3">
    <div class="row justify-content-center">
        <div class="col-md-4">
          <a href="bilan.php">
            <div class="card" style="background-color: rgba(247, 223, 10, 0.473);">
                <div class="card-body">
                  <div class="float-start">
                    <h4 class="card-title">Bilan total</h4>
                    <p class="card-text">recolter : <span class="h5"> <?= $nbr_bilan ?> </span></p>
                  </div>
                  <div class="float-end">
                    <img src="../image/bilan.webp" width="80px" height="80px">
                  </div>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-4">
          <a href="bilan.php?search=OK">
            <div class="card border border-success" style="background-color: rgba(1, 247, 34, 0.473);">
                <div class="card-body">
                  <div class="float-start">
                    <h4 class="card-title">Bilan des OK</h4>
                    <p class="card-text">recolter :<span class="h5"> <?= $nbr_OK ?> </span> // taux : <span class="h5"><?=$nbr_OK2 ?> %</span></p>
                    </div>
                    <div class="float-end bg-white">
                    <img src="../image/ok.webp" width="80px" height="80px">
                  </div>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-4" >
          <a href="bilan.php?search=KO">
            <div class="card" style=" background-color: rgba(247, 1, 1, 0.473);">
                <div class="card-body">
                  <div class="float-start">
                    <h4 class="card-title">Bilan des KO</h4>
                    <p class="card-text">Recolter :<span class="h5"> <?= $nbr_KO ?> </span> //  taux : <span class="h5"> <?= $nbr_KO2 ?> % </span> </p>
                  </div>
                  <div class="float-end bg-white">
                    <img src="../image/ko.jpg" width="80px" height="80px">
                  </div>
                  </div>
            </div>
            </a>
        </div>
    </div>
</div>

        
    <div class="mt-5">
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Composant</th>
      <th scope="col">Etat</th>
      <th scope="col">Machine</th>
      <th scope="col">Bilan</th>
      <th scope="col">Observation</th>
      <th scope="col">Date</th>
      <th scope="col">date_nouveau_action</th>
      <th scope="col">Exécuteur</th>

    </tr>
  </thead>
  <tbody>


    <?php
    //tableau 
    $resultat=mysqli_query($connection,$sql);
    if($resultat){
        $i = 0;
    while($row = mysqli_fetch_assoc($resultat)){
        $obs = "";
        $id_action=utf8_encode($row['id_bilan']);
        $composant= utf8_encode($row['composant']);
        $etat= utf8_encode($row['etat']);
        $machine= utf8_encode($row['nom_machine']);
        $bilan=utf8_encode($row['bilan']);
        $date=$row['date'];
        $date2=$row['date_nouveau_action'];
        $obs ="";
        $executeur=utf8_encode($row['executeur']);
        if(isset($row['observation'])){
        $obs=utf8_encode($row['observation']);
        }
        ?>
        <tr   style = " background-color: #red;">
            <td scope="row"><?= $id_action?></td>
            <td> <?=$composant;?> </td>
            <td> <?=$etat;?> </td>
            <td> <?=$machine;?> </td>
            <td class="<?php
        if($bilan == "OK"){
          echo "bg-success";
        }else{
            echo "bg-danger";
          }?>
        "> <?=$bilan;?> </td>
            <td><?= $obs ?></td>
            <td> <?= $date; ?> </td>
            <td> <?= $date2; ?> </td>
            <td><?=$executeur?></td>
        </tr>
        <?php
        }
    }
?>
    
  </tbody>
</table>
    </div>
</body>
</html>