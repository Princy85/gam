<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des tâches finies</title>
    <link rel="stylesheet" href="../bootstrap.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div>
        <nav style="background-color: #03224c" class="navbar navbar-expand-lg navbar-dark ">
            <div class="container">
                <a class="navbar-brand p-3" href="#">Gamme d'Auto Maintenance</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                     data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                      aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../home/home.php">Accueil <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../machine/machine.php">Ligne</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../machine/machine.php">Machine</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../action/action.php">Action</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="bilan.php">Bilan des taches finies</a>
                        </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
    </div>
    <div class="container">
            <h1 class="display-4" style="align-items: center;">Bilan des actions finies</h1>
        </div>
    <div class="container pt-3">
        <form action="bilan.php" method="post">
            <div>
                <label for="date_debut">Date debut</label>
                <input type="date" name="date_debut" id="date_debut">
                <label for="date_fin">Date fin</label>
                <input type="date" name="date_fin" id="date_fin">
                <input class="ml-3" type="submit" value="Rechercher">
                <div class="float-right">
                    <input type="button" value="Generer un pdf">
                    <input type="button" value="Generer un excel">
                </div>
        </form>
        <form action="bilan.php" method="post">
            <div class="mt-3">
                <input class="mr-2" type="search" name="search" placeholder="Recherche">
                <a class="ml-2" href="bilan.php"><img src="../image/annuler.png" width="30px"></a>
            </div>
        </form>
    </div>
    <div class="mt-5">
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Composant</th>
      <th scope="col">Etat</th>
      <th scope="col">Machine</th>
      <th scope="col">Bilan</th>
      <th scope="col">Observation</th>
      <th scope="col">Date</th>

    </tr>
  </thead>
  <tbody>
    <?php if(isset($_POST['search']))
    {

    }
    else{
    include('../connection.php');
    $sql="SELECT*FROM bilan ORDER BY date DESC";
    $resultat=mysqli_query($connection,$sql);
    if($resultat){
        $i = 0;
    while($row = mysqli_fetch_assoc($resultat)){
        $obs = "";
        $id_action=utf8_encode($row['id_bilan']);
        $composant= utf8_encode($row['composant']);
        $etat= utf8_encode($row['etat']);
        $machine= utf8_encode($row['nom_machine']);
        $bilan=utf8_encode($row['bilan']);
        $date=$row['date'];
        if(isset($row['obs'])){
        $obs=utf8_encode($row['obs']);
        }
        ?>
        <tr>
            <td scope="row"><?= $id_action?></td>
            <td> <?=$composant;?> </td>
            <td> <?=$etat;?> </td>
            <td> <?=$machine;?> </td>
            <td> <?=$bilan;?> </td>
            <td><?= $obs ?></td>
            <td> <?= $date; ?> </td>
        </tr>
        <?php
        }
    }
}?>
    
  </tbody>
</table>
    </div>
</body>
</html>