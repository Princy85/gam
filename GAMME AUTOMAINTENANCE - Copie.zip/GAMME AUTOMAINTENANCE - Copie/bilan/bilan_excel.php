<?php
include ("../connection.php");
$nom = $_POST['nomf'];
$sql = $_POST['sql'];
$result = mysqli_query($connection, $sql);

$data = array(array("id_bilan", "id_action","composant", "etat", "nom_machine", "ligne", "bilan" , "date", "date_nouveau_action" ,"observation" ));

while ($row = $result->fetch_assoc()) {
    $data[] = array_values($row);
}

require_once('xlsxwriter.class.php');

$xlsx = new XLSXWriter();
$xlsx->writeSheet($data);

$xlsx->writeToFile('historique/'.$nom.'.xlsx');


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$nom.'.xlsx"');
header('Cache-Control: max-age=0');

$xlsx->writeToStdOut();
header ('location:bilan.php');
?>