<?php
  session_start();
  $code = $_SESSION['code'];
  if(!isset($_SESSION['code'])){
      header("location:../home/home.php");
  }

  ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Action</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../style.css">
    <script src="../bootstrap/js/bootstrap.js"></script>
   

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body  class="padding" ng-controller="PopupCtrl">
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #03224c">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">GAMME AUTOMAINTENANCE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 mt-2">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="../home/home.php?user=ok">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../ligne/ligne.php?user=ok">Ligne</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../machine/machine.php?user=ok">Machine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../action/action.php?user=ok">Action</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../bilan/bilan.php?user=ok">Bilan des actions finies</a>
          </li>
        </ul>
        <form class="d-flex mt-3" action="action.php?user=ok" method="GET">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search">
          <button class="btn btn-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </div>
</nav>
<div class="container" style="margin-top: 100px">
            <h1 class="display-4">Gestion des actions du GAM</h1>
        </div>
    <div class="container">
        <fieldset class="inputTextWrap">
         <legend>Importer fichier Excel</legend>
            <form action="action_Excel.php" method="post" enctype="multipart/form-data">
                <div class="inputTextWrap">
                    <input class="form-control" type="file" name="csvfile" required="required"/>
                </div>
                <div style="margin-top: 10px;">
                    <input class="btn btn-secondary" type="submit" value="upload" />
                </div>     
        </fieldset>
          </form>
    </div>
    <div class="container mt-5">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModaladd">
                Ajouter
        </button>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Composant</th>
                    <th scope="col">Etat</th>
                    <th scope="col">Machine</th>
                    <th scope="col">Ligne</th>
                    <th scope="col">frequence</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                 <?php 
                include('../connection.php');
                if(isset($_GET['search'])){
                    include('action_search.php');
                }else{
                $sql="SELECT* FROM action";
                $resultat=mysqli_query($connection,$sql);
                $i=1;
                if($resultat){
                while($row = mysqli_fetch_assoc($resultat)){
                    $id_action=$row['id_action'];
                    $fre = $row['duree'];
                    $composant=utf8_encode($row['composant']);
                    $etat=utf8_encode($row['etat']);
                    $machine=utf8_encode($row['nom_machine']);
                    $ligne=utf8_encode($row['ligne']);
                ?>
                <tr>
                    <td ><?=$id_action?></td>  
                    <td > <?= $composant?></td>
                    <td> <?= $etat?></td>
                    <td> <?= $machine?></td>
                    <td> <?= $ligne?></td>
                    <td> <?= $fre?></td>
                    <td><a href="#" data-toggle="modal" data-target="#updateuserdata" class="confirm_update_btn" data-id="<?=$id_action?>" data-composant="<?=$composant?>" data-etat="<?=$etat?>" data-machine="<?=$machine?>" data-ligne="<?=$ligne?>" data-duree="<?=$fre?>"><img src="../image/edit.png" width="30px"></a></td>  
                    <td><a href="#"  data-toggle="modal" data-target="#deleteusermodal" class="confirm_delete_btn"data-id="<?=$id_action?>" ><img src="../image/retirer.png" width="30px"></a></td>
                      </tr>
                            </tbody>
   
                    <?php 
              }
                }};
              ?>
    </div>
    <?php 
    include('action_crud.php');
    ?>
</body>

</html>