<?php
	function isPositif($nombre){
		if($nombre < 0) return false ; 
		return true ;
	}
?>