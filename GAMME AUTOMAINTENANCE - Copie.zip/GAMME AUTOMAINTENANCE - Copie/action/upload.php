<html>

    <head>
        <title>csv insert</title>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/style_upload.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
        <link rel="stylesheet" href="css/styl.css"/>
        <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
        <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>
<style>
    .error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    padding: 15px;
    border-radius: 5px; 
    font-family: Arial, sans-serif; 
    margin: auto;
    margin-top:50px ;
    width: 600px;
}
</style>
    </head>
<body style="background-color: rgb(230, 230, 230, 1.0);">
    <div class="container mt-4">
        <div id="messages">
            <?php
                if (isset($_GET['message'])) {
                    $message = htmlspecialchars(urldecode($_GET['message']));
                    echo '<div class="error">' . $message . '</div>';
                }
            ?>
        </div>
    </div>
<div class="upload-inventaire">
    
    <fieldset class="inputTextWrap">
         <h1>Ajout des actions</h1>
            <form action="action_Excel.php" method="post" enctype="multipart/form-data">
                        
                <div class="inputTextWrap">
                    <input class="form-control" type="file" name="csvfile" required="required"/>
                </div>

                <div class="btn">
                    <input class="btn btn-primary" type="submit" value="Télécharger" style="margin-top:30px;" />
                </div>     

            </form>
        </fieldset>
</div>
</body>
</html>