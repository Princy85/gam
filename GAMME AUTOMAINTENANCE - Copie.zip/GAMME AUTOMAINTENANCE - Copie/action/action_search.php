
<?php
include ('../connection.php');
if(isset($_GET['search'])){
  $action=$_GET['search'];
  $sql1="SELECT*FROM action where nom_machine like '%$action%' or composant like '%$action%' or etat like '%$action%' or ligne like '%$action%'";
  $resultat1=mysqli_query($connection,$sql1);
  if($resultat1){
    while($row = mysqli_fetch_assoc($resultat1)){
     $id_action=$row['id_action'];
     $composant=utf8_encode($row['composant']);
     $etat=utf8_encode($row['etat']);
     $machine=utf8_encode($row['nom_machine']);
     $ligne=utf8_encode($row['ligne']);?>
       <tr>
       <td> <?=$id_action?></td>
       <td><?=$composant?> </td>
       <td> <?=$etat?></td>
       <td> <?=$machine?></td>
       <td> <?=$ligne?></td>
       <td><a href="#"data-toggle="modal" data-target="#updateuserdata" class="confirm_update_btn" data-id="<?=$id_action?>" data-composant="<?=$composant?>" data-etat="<?=$etat?>" data-machine="<?=$machine?>" data-ligne="<?=$ligne?>" margin="50px"><img src="../image/edit.png" width="30px"></a></td>
        <td><a href="#"  data-toggle="modal" data-target="#deleteusermodal" class="confirm_delete_btn"data-id="<?=$id_action?>" ><img src="../image/retirer.png" width="30px"></a></td>
         </tr>
       
<?php }

  }
}

?>

