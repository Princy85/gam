 
  <?php include('../connection.php');?>
  <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="../bootsrap/js/bootstrap.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <title>Document</title>
    </head>
    <body>
  <style>                                                                   
      .red-circle{
      width: 76px;
      height: 76px;
      border-radius: 50%;
      text-align: center;
      line-height: 60px;
      vertical-align: middle;
      padding: 5px;
      font-size: 60px;
      color:red;
      transition:0.2s;
      background-color: white;
      border: 3px solid red;
    }
    .modal-header, .modal-footer {
      margin: 0 auto;
    }
    .blue-circle{
      width: 76px;
      height: 76px;
      border-radius: 80%;
      text-align: center;
      line-height: 60px;
      vertical-align: middle;
      padding: 5px;
      font-size: 60px;
      color: red;
      transition:0.2s;
      background-color:#03224c ;
      border: 3px solid #03224c ;
    }
    legend{
      text-align: center;
      color:#03224c;
    }
    #add{
      background:#03224c;
    }
  
  



     
 </style>

        
<!-- MODAL UPDATE-->
<div class="modal fade" id="updateuserdata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <img src="../image/update4.png" alt="" class="blue-circle">
      
      </div>
      <div class="modal-body">
      <form method="POST" action="">
      <legend><h2>Modification</h2></legend>
                <div class="form-group">
                      <input type="hidden" class="form-control" id="id_action" name="id_action" >
                </div>
               <div class="form-group">
                    <label for="exampleInputEmail1">Composant</label>
                    <input type="text" class="form-control" id="composant" name="composant" >
                </div>
                <div class="form-group">
                     <label for="exampleInputEmail1">Etat</label>
                    <input type="text" class="form-control" id="etat" name="etat">
                 </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Machine</label>
                    <input type="text" class="form-control" id="machine" name="machine">
                 </div>
                 <div class="form-group">
                    <label for="exampleInputEmail1">Ligne</label>
                    <input type="text" class="form-control" id="ligne"name="ligne" >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Frequence</label>
                    <input type="text" class="form-control"  aria-describedby="emailHelp" name="duree" id="duree">
                </div>
                
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="../image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary"  name="update_data" id="add"><img src="../image/update3.png" alt="" width="30px" >Editer</button>
    </form>
      </div>
    </div>
  </div>
</div> 
        <?php
        if(isset($_POST['update_data'])){
            $id_action=utf8_decode($_POST['id_action']);
            $composant2=utf8_decode($_POST['composant']);
            $etat2=utf8_decode($_POST['etat']);
            $nom_machine2=utf8_decode($_POST['machine']);
            $ligne2=utf8_decode($_POST['ligne']);

            $sql2="UPDATE `action` SET `composant`='$composant2',`etat`='$etat2', `nom_machine`='$nom_machine2',`ligne`='$ligne2' WHERE `id_action` like '$id_action' ";
            $resultat2=mysqli_query($connection,$sql2);
            if($resultat2){?>
              <script>
              swal({
                  title: "Modifier avec succès!",
                  icon: "success",
                  timer:2000,
                }); 
                setTimeout(function() {
                   window.location.href = "action.php";
                }, 2000); 
            </script><?php
          
          }else{
                die(mysqli_error($connection));
            }
        }
        ?>
                <script>
                $('.confirm_update_btn').click(function() {
                  var id_action = $(this).data('id'); 
                  var composant = $(this).data('composant');      
                  var etat = $(this).data('etat');  
                  var machine = $(this).data('machine');     
                  var ligne = $(this).data('ligne');  
                  var duree = $(this).data('duree');    
                  $('#id_action').val(id_action);  
                  $('#composant').val(composant);  
                  $('#etat').val(etat); 
                  $('#machine').val(machine);  
                  $('#ligne').val(ligne);
                  $('#duree').val(duree); 
                } );
               
              </script>


<!-- MODAL DELETE-->
<div class="modal fade" id="deleteusermodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <img src="../image/supprimer.png" alt="" class="red-circle">
     </div>
      <form action="" method="POST">
        <legend><h2>Suppression</h2></legend>
      <div class="modal-body">
      
          <div class="form-group">
                    <input type="hidden" class="form-control"  aria-describedby="emailHelp" name="id_action"  id="id_action1">
                </div>
      <h4 style="text-align:center">Vous voulez vraiment supprimer?. </h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="../image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-danger" name="delete_data" ><img src="../image/supprimer2.png" alt="" width="30px">Supprimer</button>
         </form>
      </div>
    </div>
  </div>
</div>
      <?php
        if(isset($_POST['delete_data'])){
        $id_action=$_POST['id_action'];
        $sql="DELETE FROM `action` WHERE id_action= '$id_action'";
        $resultat=mysqli_query($connection,$sql);
        if($resultat){?>
          <script>
              swal({
                  title: "Supprimer avec succès!",
                  icon: "success",
                timer:2000,
                }); 
                setTimeout(function() {
                   window.location.href = "action.php";
                 }, 2000); 
            </script>
        <?php   
        }else{
            die(mysqli_error($connection)); 
        }
        }
        ?>
            <script>
              $('.confirm_delete_btn').click(function() {
                var id_action = $(this).data('id'); 
                $('#id_action1').val(id_action); 
              } );
            </script>


<!--MODAL ADD -->
<div class="modal fade" id="exampleModaladd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
          <img src="../image/add2.png" alt="" class="blue-circle">
       </div>
      <div class="modal-body">
      <form method="POST" action="">
        <legend>  <h1>Ajout</h1></legend>
               <div class="form-group">
                    <label for="exampleInputEmail1">Composant</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="composant">
                </div>
                <div class="form-group">
                     <label for="exampleInputEmail1">Etat</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="etat">
                 </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Machine</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="machine">
                 </div>
                 <div class="form-group">
                    <label for="exampleInputEmail1">Ligne</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="ligne" >
                </div>
                <div class="form-group">
                      <label for="exampleInputEmail1">UAP</label>
                      <select class="form-control" name="uap">
                      <?php
                              include('../connection.php');
                              $sql="SELECT DISTINCT uap from action";
                              $resultat=mysqli_query($connection,$sql);
                              if($resultat){
                                  while($row=mysqli_fetch_assoc($resultat)){
                                      $uap=$row['uap'];
                                      echo'<option value='.$uap.'>'.$uap.'</option>';
                                  }
                              }
                              ?>
                          </select>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">N°ligne</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="ordre_ligne" >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">N°machine</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="ordre_machine" >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Frequence</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="duree" >
                </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="../image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary"  name="add_data" value="Ajouter" id="add"  data-target="#success_confirmation"><img src="../image/plus.png" alt="" width="30px"> Ajouter</button>
    </form>
      </div>
    </div>
  </div>
      </div> 
              <?php
              include('../connection.php');
              if(isset($_POST['add_data'])){
                  $composant= $_POST['composant'];
                  $etat= $_POST['etat'];
                  $machine= $_POST['machine'];
                  $ligne= $_POST['ligne'];
                  $uap= $_POST['uap'];
                  $duree=$_POST['duree'];
                  $ordre_ligne=$_POST['ordre_ligne'];
                  $ordre_machine=$_POST['ordre_machine'];
                $sql=" INSERT INTO `action` (composant,etat,nom_machine,ligne,uap,duree,ordre_machine,ordre_ligne) VALUES  ('$composant','$etat','$machine', '$ligne','$uap','$duree','$ordre_machine','$ordre_ligne')";
                $resultat1=mysqli_multi_query($connection,$sql);
                  if($resultat1){?>
                  <script>
                    swal({
                        title: "Ajouter avec succès!",
                        icon: "success",
                      timer:2000,
                      
                      });
                        setTimeout(function() {
                          window.location.href = "action.php";
                        }, 2000); 
                  </script>
                  
              <?php
              }
                }
              ?>
              
</body>
</html>