<?php
$con = mysqli_connect("localhost", "root", "", "gam_nancy");

if ($con) {
    $file = $_FILES['csvfile']['tmp_name'];
    $handle = fopen($file, "r");
    $i = 0;
    $message = '';  // Variable pour les messages de succès et d'erreur

    if ($handle !== false) {
        // Nom de la table sécurisé dérivé du nom du fichier CSV
        $table_name = preg_replace('/[^a-zA-Z0-9_]/', '_', rtrim($_FILES['csvfile']['name'], ".csv"));

        $columns = [];
        $column_names = [];
        while (($cont = fgetcsv($handle, 2000, ";")) !== false) {
            if ($i == 0) {
                // Noms de colonnes sécurisés et formatés
                foreach ($cont as $column) {
                    $safe_column = preg_replace('/[^a-zA-Z0-9_]/', '_', $column);
                    $columns[] = "`$safe_column` VARCHAR(255)";
                    $column_names[] = $safe_column;
                }
                
                // Création de la table
                $query = "CREATE TABLE IF NOT EXISTS `$table_name` (" . implode(", ", $columns) . ");";
                
                if (!mysqli_query($con, $query)) {
                    $message = "Erreur de création de la table : " . mysqli_error($con);
                    break;  // Sortir de la boucle en cas d'erreur
                }
            } else {
                // Préparer les valeurs pour l'insertion
                $values = array_map(function ($value) use ($con) {
                    return "'" . mysqli_real_escape_string($con, $value) . "'";
                }, $cont);

                // Requête d'insertion avec noms de colonnes
                $query = "INSERT INTO `$table_name` (" . implode(", ", $column_names) . ") VALUES (" . implode(", ", $values) . ")";
                
                if (!mysqli_query($con, $query)) {
                    $message = "Erreur d'insertion des données : " . mysqli_error($con);
                    echo $message;
                    break;  // Sortir de la boucle en cas d'erreur
                }
            }
            $i++;
        }
        fclose($handle);

        // Message de succès
        if (empty($message)) {
            $message = "Données importées avec succès!";
        }
    } else {
        $message = "Erreur lors de l'ouverture du fichier.";
    }

} else {
    $message = "Connexion à la base de données échouée : " . mysqli_connect_error();
}
header("location:upload.php?message=$message");
?>
