<?php
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    if(empty($email) || empty($password)){
        ?>
                <script>
                    alert("Veuillez remplir tout les champs");
                </script>
                <?php
    }else{
        if($email === 'ismael.razafiarijaona@basan.mg'){
            if($password === '000'){
                session_start();
                $_SESSION["email"]=$email;
                $_SESSION['code']= $password;
                header('location:home/home.php?user=ok');
            }else{
                ?>
                <script>
                    alert("Mots de passe incorrect");
                </script>
                <?php
                
            }
        }elseif($email === 'ismael.razafiarijaona@basan.mg'){
            if($password === '000'){
                session_start();
                $_SESSION["email"]=$email;
                $_SESSION['code']= $password;

                header('location:home/home.php');
            }else{
                ?>
                <script>
                    alert("Mots de passe incorrect");
                </script>
                <?php
                
            }


        }elseif($email === 'uap4@basan.mg'){
            if($password === 'uap4'){
                session_start();
                $_SESSION["email"]=$email;
                $_SESSION['password']= $password;
                header('location:home/home.php?employer=uap4');
            }
        }
        else
        {
            ?>
                <script>
                    alert("Email non identifié");
                </script>
                <?php
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="login.css">

   
    <script src="../bootsrap/js/bootstrap.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
</head>
<style>
    .button{
    border: 1px solid white;
    background-color: transparent;
    color:white;
}
.rr{
    
}

</style>
<body>
    <div>
        <a href="http://10.0.3.100:8080/INDEX/gmao.html" class="btn btn-primary ml-1 mt-1 button"><img src="image/retour.png" alt="" width="50px"></a>
    </div>
    <div class="pt-5">
        <h2 style="margin-left:40px">Bienvenu dans la page d'accueil et d'authentification</h2>
    </div>
    <div class="rr pt-5 pb-5 pl-5">
        <a href="home/home.php" class="btn btn-primary button p-3 m-5"><img src="image/person.png" alt="" width="40px">Utilisateur</a>
        <button class="btn btn-primary button p-3 m-5"data-toggle="modal" data-target="#modalConnexion"><img src="image/connection.png" alt=" " width="40px">Connection</button>
    </div>
    
<!-- POPUP MODAL-->
<div class="modal fade" id="modalConnexion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="text-align: center;">
        <h1 style="color:#000;">Connexion</h1>
     </div>
      <form action="index.php" method="POST">
       
      <div class="modal-body">
      
          <div class="form-group">
            <label  style="font-weight:bold;margin-bottom:20px;color:#000"for="">Email</label><br>
            <input type="email" name="email" placeholder="Veuillez entrer votre email" class="form-control"><br>
            <label  style="font-weight:bold;margin-bottom:20px;color:#000"for="">Mot de Passe</label><br>
            <input type="password" name="password" placeholder="Veuillez entrer votre mot de passe" class="form-control">
              
         </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary" name="submit" ><img src="image/connection.png" alt="" width="30px">Connecter</button>
         </form>
      </div>
    </div>
  </div>
</div>
   <!-- <div class="align-items-center justify-content-center d-flex">
        <div  class=" card rounded-bottom-lg float-right pt-3 mt-5 ">
            <div class="pr-5 pl-5">
                <form  action="index.php" method="POST" class="card-body">
                    <h1 class="card-title">Connection</h1>
                    <div class="form-group mt-5">
                        <label for="exampleInputEmail1">Utilisateur</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" name="email">
                    </div>
                    <div class="form-group mt-5">
                        <label for="exampleInputPassword1">Mot de passe</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Mot de passe" name="password">
                    </div>
                    <div class="form-group form-check mt-5">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" class="btn btn-primary mt-5 mb-5" name="submit">Submit</button>
                    <a href="home/home.php" class="btn btn-info mt-5 mb-5">Entrer sans connection</a>
                </form>
            </div>
        </div>
    </div>-->

</body>
</html>
