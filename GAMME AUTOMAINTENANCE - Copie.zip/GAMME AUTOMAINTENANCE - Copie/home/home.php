<?php
/*
if(isset($_POST['data_login'])){
  $password=$_POST['password'];
  echo "okk";
    if($password ==='uap4'){
      header("location:home.php?uap=uap4");
    }elseif($password === 'uap1'){
      header("location:home.php?uap=uap1");
    }elseif($password === 'uap2'){
      header("location:home.php?uap=uap2");
    }elseif($password === 'uap3'){
      header("location:home.php?uap=3");
    }elseif ($password === 'support') {
      header("location:home.php?uap=support_technique");
    }elseif($password === 'hors'){
      header("location:home.php?uap=hors_site");
    }
    else{
      echo "uap4";
     // header("location:home.php");
    }
}
*/
?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../style.css">
    <script src="../bootstrap/js/bootstrap.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      
    

</head>
<body>
<nav class="navbar navbar-dark navbar-expand-lg fixed-top" style="background-color: #03224c">
  <div class="container-fluid">
  <a href="../logout.php"><img src="../image/logout.png" width="20px"></a>
    <a class="navbar-brand" href="#">GAMME AUTOMAINTENANCE</a>
    <a class="navbar-brand" href="#">Support Technique</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="../home/home.php">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../ligne/ligne.php">Ligne</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../machine/machine.php">Machine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../action/action.php">Action</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../bilan/bilan.php"> Bilan des actions finies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../planification/planification.php">Planification des actions</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>

  <div class="container" style="margin-top: 100px">
      <h1 class="display-4">Outils Système Maintenance</h1>
  </div>
  <div class="pb-5">  </div>
  <div class="container">
    <h2 style="text-align: center">Veuillez entrer le mot de passe correspondant de votre département</h2>
      <ul class="list-unstyled" style="text-align: center">
        <li class="btn btn-secondary m-3">
          <h2>
            <a class="badge badge-secondary" style="text-decoration: none;" data-toggle="modal" data-target="#modalConnexion" 
              href="home.php?uap=UAP1">Direction industrielle
            </a>
            </h2>
          </li>
      </ul>
</div>
  <?php
    if(isset($_POST['password'])){
      include('../connection.php');
      $uap = $_POST['password'];
      $sql="SELECT distinct ligne , uap FROM action where uap like '%$uap%' order by ordre_ligne ASC";
      $resultat = mysqli_query($connection,$sql);?>
        <h3 style="text-align: center">Lignes de production <?= $uap ?> </h3>
        <div class="  justify-content-center h2 container ">
            <?php
              if($resultat){
                while($row=mysqli_fetch_assoc($resultat)){
                    $ligne = $row["ligne"];
            ?>    
            <div class="btn">
                <h3><a  class="badge badge-secondary p-3" style="background-color: #314664 ;text-decoration: none;"
                <?php
                  if(isset($_GET['user'])){
                ?>
                  href="../machine/machine_action.php?uap=<?= $uap ?>&ligne=<?= $ligne?>&user=ok"
                <?php
                  }else{
                ?>
                  href="../machine/machine_action.php?uap=<?= $uap ?>&ligne=<?= $ligne?>"
                <?php
                  }
                ?>
                  href="../machine/machine_action.php?uap=<?= $uap ?>&ligne=<?= $ligne?>">
                <?= $ligne ?></a></h3>
            </div>
              <?php }}} ?>
        </div>

              <!-- signature -->
            <div class="row bg-dark pt-2 pb-5" style="margin-top: 400px;bottom: 0;  color: white; width: 100%;">
              <div class="col-lg-1"></div>
              <div class="col-lg-5 pb-3">
                <p style= "line-height: 40px;">
                <img src="../image/person.png" width="30px"> RAMBELOSON Fitahiana Jessie <br>
                <img src="../image/phone.png" width="25px"> 0346335209 <br>
                <img src="../image/email.png" width="30px">  fitahianajessie@gmail.com
                </p>
              </div>
              <div class="col-lg-3" ></div>
              <div class="col-lg-3 pb-3">
                <p class="" style= "line-height: 40px;">
                <img src="../image/person.png" width="30px"> TSILIHY Fihobiana Princy<br>
                <img src="../image/phone.png" width="25px"> 0324004163<br>
                <img src="../image/email.png" width="30px"> fihobianaprincys@gmail.com
                </p>
            </div>
          </div>



<!-- POPUP MODAL-->
<div class="modal fade" id="modalConnexion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1>Connexion</h1>
     </div>
      <form action="home.php" method="POST">
       
      <div class="modal-body">
      
          <div class="form-group">
            <label  style="font-weight:bold;margin-bottom:20px"for="">Mot de Passe</label><br>
            <input type="password" name="password" placeholder="Veuillez entrer le mot de passe" class="form-control">
              
         </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><img src="../image/cancel1.png" alt="" width="30px">Annuler</button>
        <button type="submit" class="btn btn-primary" name="data_login" ><img src="../image/connection.png" alt="" width="30px">Connecter</button>
         </form>
      </div>
    </div>
  </div>
</div>


</body>
</html>