<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../bootstrap.css">
</head>
    <body>
        <nav style="background-color: #03224c" class="navbar navbar-expand-lg navbar-dark ">
            <div class="container">
                <a class="navbar-brand p-3" href="#">Gamme d'Auto Maintenance</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="home.php">Accueil <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../ligne/ligne.php">Ligne</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../machine/machine.php">Machine</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../action/action.php">Action</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../bilan/bilan.php">Bilan des taches finies</a>
                        </li>
                        <li class="nav-item">
            <a class="nav-link" href="../planification/planification.php">Planification des actions</a>
          </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
        <div class="container mt-5">
            <h1 class="display-4">Bienvenue dans l'appication GAM</h1>
        </div>
        <div class="pb-5">

        </div>
        <div class="container">
            <h2 class="">Voici la liste des Unites Autonomme de Production : </h2>
            <ul class="list-unstyled d-flex justify-content-center h2 ">
                <li class="list-group-item border-white "><a class="badge badge-secondary p-3" href="home.php?uap=UAP1">UAP1</a></li>
                <li class="list-group-item border-white"><a class="badge badge-secondary p-3" href="home.php?uap=UAP2">UAP2</a></li>
                <li class="list-group-item border-white"><a class="badge badge-secondary p-3" href="home.php?uap=UAP3">UAP3</a></li>
                <li class="list-group-item border-white"><a class="badge badge-secondary p-3" href="home.php?uap=UAP4">UAP4</a></li>
            </ul>
        </div>
        <?php
        if(isset($_GET['uap'])){
            include('../connection.php');
            $uap = $_GET['uap'];
            $sql="SELECT distinct ligne , uap FROM action where uap like '%$uap%' order by ordre_ligne ASC";
            $resultat = mysqli_query($connection,$sql);?>
            <h3 style="text-align: center" class="col-8">Voici la liste des lignes dans <?= $uap ?> </h3>
            <ul class="list-unstyled d-flex justify-content-center h2 ">
            <?php
            if($resultat){
                while($row=mysqli_fetch_assoc($resultat)){
                    $ligne = $row["ligne"];
                     ?>    
                    <li class="list-group-item border-white ">
                        <a  class="badge badge-secondary p-3" style="background-color: #314664" href="../machine/machine_action.php?uap=<?= $uap ?>&ligne=<?= $ligne?>"><?= $ligne ?></a>
                    </li>
            </div>
        <?php }}} ?>
    </body>
</html>