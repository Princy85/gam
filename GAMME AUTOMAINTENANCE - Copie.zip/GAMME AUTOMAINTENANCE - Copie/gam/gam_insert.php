<?php
include ('../connection.php');

$i = $_POST['i'];
$i--;
$a = 0;
$machine = $_POST['machine'];
$ligne = $_POST['ligne'];
$uap = $_POST['uap'];
$executeur=utf8_decode($_POST['executeur']);
$empty = FALSE;
$sql= "";
if(empty($executeur)){
    $message="ok";
    header("location:gam.php?message=$message&ligne=$ligne&machine=$machine&uap=$uap");
}else{


while($a <= $i){
    $id_action =$_POST['id_action'.$a];
    $etat =utf8_decode($_POST['etat'.$a]);
    $composant = utf8_decode($_POST['composant'.$a]);

    //frequence 
    $frequence = (int)$_POST['frequence'.$a];
    $sql1 = "SELECT DATE_ADD(DATE(NOW()), INTERVAL $frequence DAY) AS frequence";
    $res = mysqli_query($connection,$sql1);
    $row1 = mysqli_fetch_assoc($res);
    $frequence = $row1['frequence'];
    echo  "$frequence    ";
    //observation
    $obs = "";
    if(isset($_POST['obs'.$a]))
    {
        $obs = $_POST['obs'.$a];
    } 
    if(isset($_POST['bilan'.$a])){
        $bilan = $_POST['bilan'.$a];
        $empty = TRUE;
 $sql .= " 
 INSERT INTO `bilan`(`id_action`, `composant`, `etat`, `nom_machine`, `ligne`, `bilan`, `date`, date_nouveau_action ,`observation`,`executeur`) VALUES
  ($id_action,'$composant','$etat','$machine','$ligne','$bilan', date(NOW()) , '$frequence' ,'$obs','$executeur');";
    }else{
        header('location:gam.php?machine='.$machine.'&ligne='.$ligne.'&uap='.$uap);
    }
    $a++ ;
  }
     $resultat1= mysqli_multi_query($connection,$sql);
     if($resultat1){
         header('location:../machine/machine_action.php?uap='.$uap.'&ligne='.$ligne);
     }else{
         die(mysqli_error($connection));
     }

    }
 ?>
 