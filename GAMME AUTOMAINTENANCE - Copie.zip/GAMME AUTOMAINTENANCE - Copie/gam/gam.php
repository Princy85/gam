<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GAM</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../style.css">
    <script src="../bootstrap/js/bootstrap.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #03224c">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">GAMME AUTOMAINTENANCE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="../home/home.php">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" <?php 
            if(isset($_GET['user'])){
              
              echo "ok";
              ?>
                  href="../ligne/ligne.php?user=ok"
              <?php
            }else{
              ?>
              href="../ligne/ligne.php"
              <?php
            }
            ?> 
            >Ligne</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" <?php if(isset($_GET['user'])){
              ?>
                    href="../machine/machine.php?user=ok"
              <?php
            }else{
              ?>
              href="../machine/machine.php"
              <?php
            }
            ?> 
             >Machine</a>
          </li>
          <li class="nav-item">
            <a class="nav-link"
            
            <?php if(isset($_GET['user'])){
              ?>
                   href="../action/action.php?user=ok"
              <?php
            }
            ?>

             >Action</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" 
            <?php if(isset($_GET['user'])){
              ?>
                    href="../bilan/bilan.php?user=ok"
              <?php
            }
            ?>
            
            >Bilan des actions finies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" 
            <?php if(isset($_GET['user'])){
              ?>
                    href="../planification/planification.php?user=ok"
              <?php
            }
            ?>
            >Planification des actions</a>
          </li>
        </ul>
        <form class="d-flex mt-3" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </div>
</nav>
<div class="container" style="margin-top: 100px">
        <h1 class="display-4">GAM de <?= $_GET['machine'] ?></h1>
        <h2>Ligne: <?= $_GET['ligne']?></h2>
        <div class="row mt-4">
          <div class="col-lg-2">
           <h3 >Executeur:</h3>
           </div>
           <form action="gam_insert.php" method="POST">
           <div class="col-lg-4"><input type="text" name="executeur" class="form-control" placeholder="Veuillez entrer votre nom"></div>
        </div>
      <?php
      if(isset($_GET['message'])){
       ?>
       <p style="color:red;font-family:Comic Sans MS;font-size:20px">Veuillez ajouter votre nom! </p>
     <?php 
     }
      ?>
    </div>
    <div class="container mt-5">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Composant</th>
                    <th scope="col">Etat</th>
                    <th scope="col">Bilan</th>
                    <th scope="col">Observation</th>
                </tr>
            </thead>
            
              <input type="text" name="uap" value="<?= $_GET['uap'] ?>" class="collapse">
            <tbody>
                
                    <?php
                        include('../connection.php');
                       // $id_action = $_GET['id_action'];
                        $machine = utf8_decode($_GET['machine']);
                        $ligne = $_GET['ligne'];
                        $uap = $_GET['uap'];
              
                        $i = 0;
                            $sql="SELECT*FROM action where nom_machine like '$machine' and ligne like '$ligne' and (id_action  NOT IN (SELECT id_action FROM bilan where date_nouveau_action > date(now()))) ";
                            $resultat=mysqli_query($connection,$sql);
                                if($resultat){
                                    while($row = mysqli_fetch_assoc($resultat)){
                                        $composant = utf8_encode($row['composant']);
                                        $etat=utf8_encode($row['etat']);
                                        $id_action = $row['id_action'];
                                        $action[] = $id_action;
                                        $frequence = 0 ;
                                        if(isset($row['duree'])){
                                          $frequence = $row['duree'];
                                        }
                                       
                                        ?>
                                         <tr>
                                            <th scope="row">
                                                <?= $id_action ?> <input class="collapse" type="text" name="id_action<?=$i?>" value="<?= $id_action ?>">
                                                <input class="collapse" type="text" value="<?= $frequence ?>" name="frequence<?=$i?>">
                                            </th>
                                            <td><?= $composant ?><input class="collapse" type="text" name="composant<?=$i?>" value="<?= $composant ?>"></td>
                                            <td><?= $etat ?><input class="collapse" type="text" name="etat<?=$i?>" value="<?= $etat ?>"></td>
                                            <td>
                                                <section required="required">
                                                    <input type="radio" name="bilan<?= $i ?>" value="OK" id="ok">
                                                    <label for="ok" class="mr-3">OK</label>
                                                    <input type="radio" name="bilan<?= $i ?>" value="KO" id="ko">
                                                    <label for="ko">KO</label>
                                                </section>
                                            </td>
                                            <td><input type="text" name="obs<?= $i ?>" id="obs"></td>
                                        </tr>
                                    <?php 
                                    $i++;
                                }
                                } ?>
            </tbody>
            <input type="text" name="i" value="<?= $i ?>" class="collapse">
            <input type="text" name="machine" value="<?= $machine ?>" class="collapse">
            <input type="text" name="ligne" value="<?= $ligne ?>" class="collapse" >
            <input type="submit" value="Envoyer" class="btn btn-primary" name="submit">
            </form>
    </div>
</body>
</html>