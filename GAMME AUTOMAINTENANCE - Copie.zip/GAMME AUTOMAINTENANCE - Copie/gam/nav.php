<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap.css">
    <script src="../bootstrap/js/bootstrap.js"></script>
</head>
<body>
<div class="collapse nav-collapse" id="navbarToggleExternalContent">
  <div class="bg-dark p-4">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../home/home.php">Accueil <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../ligne/ligne.php">Ligne</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../machine/machine.php">Machine</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../action/action.php">Action</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../bilan/bilan.php">Bilan des taches finies</a>
                    </li>
                </ul>
      </div>
</div>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
  </div>
</nav>
</body>
</html>