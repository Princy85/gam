﻿<?php
	session_start();
	$_SESSION['uap'] = $_POST['uap'];
	header('Location: liste_action_rida.php');	
?>