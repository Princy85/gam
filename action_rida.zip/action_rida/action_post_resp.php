﻿
		
<?php
       $servname = "localhost"; $dbname = "synthese"; $user = "root"; $pass = "";
            
            try{
                $dbco = new PDO("mysql:host=$servname;dbname=$dbname", $user, $pass);
                $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
             
                $numid = $_POST['zid'];
                $heure_panne = $_POST['heure_panne'];
                $realise = $_POST['realise'];
                $situation = $_POST['situation'];
                $qte = $_POST['qte'];
                $responsable = $_POST['responsable'];
                $ref = $_POST['ref'];
            
                $req = $dbco->prepare("UPDATE rida1 SET situation = :situation, realise = :realise, qte = :qte, responsable= :responsable, heure_panne= :heure_panne, ref= :ref WHERE Nid =$numid");
                $req->bindParam(':situation', $situation, PDO::PARAM_INT);
               $req->bindParam(':heure_panne', $heure_panne, PDO::PARAM_INT);
               $req->bindParam(':realise', $realise, PDO::PARAM_STR);
                $req->bindParam(':qte', $qte, PDO::PARAM_INT);
                $req->bindParam(':responsable', $responsable, PDO::PARAM_STR);
               $req->bindParam(':ref', $ref, PDO::PARAM_STR);

                $req->execute();
                echo 'Action Terminée';

            }
                  
            catch(PDOException $e){
                echo "Erreur : " . $e->getMessage();

            }

	header('Location: liste_action_resp.php');	
?>
 


