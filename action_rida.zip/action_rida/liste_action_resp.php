<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>rida</title>


</head>


  <style>




td {
  border:1px solid black;
  column-width: auto;

}


th {
  border:1px solid black;
  column-width: 100%;

}


tr:nth-child(even) {
    background-color: #e4fbf9;

}


h2{
      border: 0;
    line-height: 2.3;
    padding: 0 20px;
    font-size: 1.3rem;
margin-left: 0.2px;
    text-align: center;
    color: garbagey;
    text-shadow: 1px 1px 1px #000;
    border-radius: 10px;
    background-color:  #a3e4d7;

}



table {
  table-layout: fixed;
  width: 90%;
  border-collapse: collapse;
  border: 2px solid black;


}



textarea {
 border:1px solid black;
 background-color: #dce0f7;

  form-layout: fixed;
width: 98%;
  border-collapse: collapse;

color: red;
}
p {
  color: black;
  font-family: Arial;
}
   

img {
   margin-left: 310px;
    max-width: 8%;
 max-height: 8%;
}

   b {
  color: #bd0515;
font: 0.6rem 'MutatorSans', sans-serif;
  margin-left: 330px;

}



thead th:nth-child(2) {
  width: 20%;
}

th {
 border:2px solid black;
 background-color: #f2442c;
  height: 15px;
  width: 25px;
color: WHITE;
font-family: Arial;

}

input[type=button], input[type=submit], input[type=reset] {
  background-color: #04AA6D;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
}

form {
background-color : #f0f3ea;
 border: 2px solid  #212f3d ;
   border-radius: 3px;
    form-layout: fixed;
width: 100%;
  border-collapse: collapse;



}

form:nth-child(even) {
    background-color: #e4fbf9;

}

input[type=text], input[type=number] {
  border: 1.2px solid darkred;
  border-radius: 0px;
}


button[type=submit] {

  border-radius: 10px;
  background-color:   springgreen ;
}


</style>


<body>

          <?php     
            try{       
              $bdd = new PDO('mysql:host=localhost; port=3306; charset=utf8; dbname=synthese', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            }  
            catch(Exception $e){
              die('Erreur: '.$e->getMessage());
            }
      
          ?>

     <a href="../gmao.html">Go to home!</a>
      <a class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <h2>LISTE DES ACTIONS PAR RESPONSABLE</h2>
            </a>
            
      <i class="bi bi-list toggle-sidebar-btn"></i>
  
 



<div style="margin-left: 40px;" class="search-bar">
      <form class="search-form d-flex align-items-center" method="post" action="liste_action_resp.php">
        <input type="title" class="input-group-text" name="search" placeholder=" Choisir Prenom" title="Saisir theme de l'action">

        <button type="search" style="width: auto" class="btn btn-secondary"></svg>  Recherche</button>

      </form>
</div>   <br>           






    <?php
    $reponse = $bdd->prepare('SELECT * FROM rida1 WHERE responsable like? AND situation < 1');
    $reponse->execute(array('%'.$_POST['search'].'%')); 


    while ($donnees = $reponse->fetch()){         
 ?> 
  <form action="action_post_resp.php" method="post" name="search">
 
     <input id="Aujourdhui" style="width: 70px" type="title" name="dateT" value="<?php echo date("d/m/Y");?>" placeholder="<?php echo date("d/m/Y");?>" readonly>
   n°<input type="title" style="width: 32px" name="Nid" value="<?=$donnees['Nid']?>"readonly>

   <tr>
   

    <td><input type="title" style="width: 150px" value="<?=$donnees['machine']?>[<?=$donnees['ligne']?>]" readonly></td>
     
         
      <td><textarea type="text"  placeholder="<?=$donnees['action_action_prev']?>[<?=$donnees['responsable']?>]" readonly></textarea></td></tr>
    





  <br><br><td> <input style="width: 32px" class="input-group-text" placeholder="Qté" type="number" name="qte" required></td>

   &nbsp&nbsp<input style="width: 100px" class="input-group-text" type="text" placeholder="Intervenant" name="responsable" required>   
  &nbsp&nbsp &nbsp<input style="width: 70px" class="input-group-text" type="number" placeholder="Durée" name="heure_panne" required>&nbsp
 
       <td><select name="situation" style="width: 70px; border-radius: 1px; border: 1.2px solid darkred" class="input-group-text"><option value=""> ........ </option>
                                                                  <option value="1">T</option></select></td><br><br>
     Réf:<input style="width: 250px" class="input-group-text" type="text" value="<?=$donnees['ref']?>" name="ref" required>&nbsp
     
<br><td>  &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button type="Submit" value="Envoyer">Ok terminé</button></td></tr>


        </form> <hr>
        <?php   
        }
        $reponse->closeCursor();
      ?>    


  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <script src="assets/js/1main.js"></script>

</body>

</html>