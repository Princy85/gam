<?php
  $host = 'localhost';
  $dbname = 'synthese';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM rida1";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head></head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  
<body>
    <center>
      <a class="nav-link active " href="http://10.0.3.100:8080/index/gmao.html" >Retour menu</a></div>
 <h1>RIDA</h1>
 <table class="table table-striped table-bordered" id="tableau">
   <thead>
     <tr>
       <th class="text-center">id</th>
       <th class="text-center">Date</th>
       <th class="text-center">UAP</th>
       <th class="text-center">Ligne</th>
       <th class="text-center">Machine</th>
       <th class="text-center">Organe</th>
       <th class="text-center">Theme</th>
       <th class="text-center">Faits</th>
       <th class="text-center">Nature_de_panne</th>
       <th class="text-center">Cause</th>
       <th class="text-center">Actions Preventives</th>
       <th class="text-center">Délai</th>
       <th class="text-center">Reference pieces</th>
       <th class="text-center">Code article</th>
       <th class="text-center">Quantite</th>
       <th class="text-center">Responsable</th>
       <th class="text-center">TDM</th>
       <th class="text-center">Heure de panne</th>
       <th class="text-center">Solution technique</th>
       <th class="text-center">Situation</th>
       <th class="text-center">Date de cloture</th>
       
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td class="text-center" ><?php echo htmlspecialchars($row['zid']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['dates']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['uap']); ?></td>
       <td class="text-center" ><?php echo htmlspecialchars($row['ligne']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['machine']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['organe']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['theme_origine']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['anomalie_fait_panne']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['nature']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['cause']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['action_action_prev']); ?></td> 
       <td class="text-center"><?php echo htmlspecialchars($row['delai']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['ref']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['code_x3']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['qte']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['responsable']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['tdm']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['heure_panne']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['solution_tech']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['situation']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['realise']); ?></td>
    </tr>
     <?php endwhile; ?>
   </tbody>
   <input class="zonesaisie" type="text" placeholder="Recherche..." id="maRecherche" onkeyup="filtrer()">

   <button type="button" onclick="tableToCSV()">
			Download CSV
		</button>
 </table>

 <script type="text/javascript">
		function tableToCSV() {

			// Variable to store the final csv data
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "GfG.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
	</script>
  <script>
function filtrer()
{
var filtre, tableau, ligne, cellule, i, texte;

filtre = document.getElementById("maRecherche") .value.toUpperCase();
tableau = document.getElementById("tableau");
ligne = tableau.getElementsByTagName("tr");

for (i = 0; i < ligne.length; i++)
{
cellule = ligne[i].getElementsByTagName("td")[0];
if(cellule)
{
texte = cellule.innerText;
if (texte.toUpperCase().indexOf(filtre) > -1)
{
ligne[i].style.display = "";
}
else
{
ligne[i].style.display = "none";
}
}
}
}
</script>
    </center>
</body>
</html>