<?php
try{
	$db = new PDO('mysql:host=localhost;dbname=synthese','root','');
	$db->exec('SET NAMES "UTF8"');
} catch (PDOException $e){
	echo 'erreur :'. $e->getMessage();
	die();
}