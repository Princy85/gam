<label for="filterName">Name:</label>
<input type="text" id="filterName">

<label for="filterAge">Age:</label>
<input type="text" id="filterAge">

<label for="filterCountry">Country:</label>
<input type="text" id="filterCountry">
<table id="myTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Country</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>John</td>
            <td>25</td>
            <td>USA</td>
        </tr>
        <tr>
            <td>Jane</td>
            <td>30</td>
            <td>Canada</td>
        </tr>

         <tr>
            <td>Jenny</td>
            <td>27</td>
            <td>Tana</td>
        </tr>

                <tr>
            <td>Joary</td>
            <td>30</td>8
            <td>Paris</td>
        </tr>

                        <tr>
            <td>Joary</td>
            <td>28</td>
            <td>Tamatavy</td>
        </tr>

                        <tr>
            <td>Joary</td>
            <td>28</td>
            <td>Tamatavy</td>
        </tr>

                        <tr>
            <td>Joary</td>
            <td>21</td>
            <td>Tamatavy</td>
        </tr>
        <!-- More rows... -->
    </tbody>
</table>





<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#filterName, #filterAge, #filterCountry").on("keyup", function() {
            var nameValue = $("#filterName").val().toLowerCase();
            var ageValue = $("#filterAge").val().toLowerCase();
            var countryValue = $("#filterCountry").val().toLowerCase();

            $("#myTable tbody tr").filter(function() {
                var nameMatch = $(this).find("td:eq(0)").text().toLowerCase().indexOf(nameValue) > -1;
                var ageMatch = $(this).find("td:eq(1)").text().toLowerCase().indexOf(ageValue) > -1;
                var countryMatch = $(this).find("td:eq(2)").text().toLowerCase().indexOf(countryValue) > -1;

                $(this).toggle(nameMatch && ageMatch && countryMatch);
            });
        });
    });
</script>
