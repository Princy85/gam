<?php

 
include 'connectliste.php';
 
 ?>
 
 <!DOCTYPE html>
 <html>
 <head>
     <meta charset="utf-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   <meta name="viewport"
          content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src=
"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <script src=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
    </script>
    <title>SYNTHESE</title>
	<center><h1>SYNTHESE</h1></center>
       <?php
        $t_cumul=$db->query("SELECT COALESCE (a.uap,b.uap) uap, a.Nid,a.date,a.ligne,a.machine,a.organe,a.theme_origine,a.anomalie_fait_panne,a.cause,a.action_action_prev,a.ref,a.code_x3,a.qte,a.responsable,a.tdm,a.heure_panne,a.solution_tech,a.situation,a.dateT,b.resp_rida FROM rida a INNER JOIN uap_resp b ON a.uap = b.uap");
          while($parc=$t_cumul->fetch())
          {
                ?>
                <table class="table table-striped table-hover">
                	<thead class="thead-dark">
                    <tr>
                        <th>uap</th>
                        <th>date</th>
                        <th>ligne</th>
                        <th>machine</th>
                        <th>organe</th>
                        <th>theme_origine</th>
                        <th>anomalie_fait_panne</th>
                        <th>cause</th>
                        <th>action_action_prev</th>
                        <th>ref</th>
                        <th>code_x3</th>
                        <th>qte</th>
                        <th>resposable</th>
                        <th>tdm</th>
                        <th>heure_panne</th>
                        <th>solution_tech</th>
                        <th>situation</th>
                        <th>dateT</th>
                        <th>resp_rida</th>
                   
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $parc['uap']; ?></td>
                        <td><?php echo $parc['date'];?></td>
                        <td><?php echo $parc['ligne']; ?></td>
                        <td><?php echo $parc['machine']; ?></td>
                        <td><?php echo $parc['organe']; ?></td>
                        <td><?php echo $parc['theme_origine']; ?></td>
                        <td><?php echo $parc['anomalie_fait_panne']; ?></td>
                        <td><?php echo $parc['cause']; ?></td>
                        <td><?php echo $parc['action_action_prev']; ?></td>
                        <td><?php echo $parc['ref']; ?></td>
                        <td><?php echo $parc['code_x3']; ?></td>
                        <td><?php echo $parc['qte']; ?></td>
                        <td><?php echo $parc['responsable']; ?></td>
                        <td><?php echo $parc['tdm']; ?></td>
                        <td><?php echo $parc['heure_panne']; ?></td>
                        <td><?php echo $parc['solution_tech']; ?></td>
                        <td><?php echo $parc['situation']; ?></td>
                        <td><?php echo $parc['date_T']; ?></td>
                        <td><?php echo $parc['resp_rida']; ?></td>

                    </tr>
 				</tbody>
                </table>
                <?php
            }
 
         ?>
         
    </div>
  </center>
</form>

    </script>
 </body>
 </html>