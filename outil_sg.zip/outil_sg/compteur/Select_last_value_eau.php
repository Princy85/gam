<?php

 require 'Post.php';

     $query = "SELECT * FROM eau";
     $query_run = mysqli_query($bdd, $query);

         if(mysqli_num_rows($query_run) > 0)

         {
          foreach ($query_run as $fm) 
            {
             ?> 
            <?php
            }
         }
?>