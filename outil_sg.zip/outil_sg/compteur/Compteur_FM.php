<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVE COMPTEUR FORCE MOTRICE</title>
  </head>

  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%;color:#CD5C5C">RELEVE COMPTEUR FM</h3>                        
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body style="background-color:burlywood;">

                <form class="row" method="POST" action="Envoie_FM.php">  
                  <div id="actualiserfm" class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">3.8.0 (Reactif)</th>
                          <th scope="col">Cos φ</th>

                        </tr>
                      </thead>
                      <tbody>
                          <tr>  

                            <?php
                            require 'Select_last_value_fm.php';
                            ?>

                            <td> <input type="number" value="<?=$fm['3_8_0']?>" step="0.01" class="form-control" name="3_8_0" id="mee" required="required">  </td>
                            <td> <input type="number" value="<?=$fm['Cos']?>" step="0.01" class="form-control" name="Cos" required="required"> </td>
                          </tr>

                          <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">1.8.0 (Actif)</th>
                          <th scope="col">1.8.1 (Actif Jour)</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['1_8_0']?>" step="0.01" class="form-control" name="1_8_0" required="required"> </td>
                             <td> <input type="number" value="<?=$fm['1_8_1']?>"step="0.01" class="form-control" name="1_8_1" required="required"> </td>
                          </tr>

                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">

                          <th scope="col">1.8.2 (Actif Point)</th>
                          <th scope="col">1.8.3 (Actif Nuit)</th>
                        </tr>
                      </thead>
                      <tbody>

                          <tr>                           
                            <td> <input type="number" value="<?=$fm['1_8_2']?>" step="0.01" class="form-control" name="1_8_2" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['1_8_3']?>" step="0.01" class="form-control" name="1_8_3" required="required"> </td>                                                  
                          </tr>
                      </tbody>
                      
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success" type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>

                     <form>
                      <input type="button" class="btn btn-primary" value="< Retour" onclick="history.back()">
                     </form>


                  </div>
                 </form> 
                  <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>

  </body>

  </html>