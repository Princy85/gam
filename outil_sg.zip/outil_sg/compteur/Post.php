<?php

$bdd = mysqli_connect("localhost","root","","compteur_fm");

if (!$bdd){
  die('Connection Failed'. mysqli_connect_error());
}
 ?>