<?php
  $host = 'localhost';
  $dbname = 'compteur_fm';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM fm_jbu2";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head> 
  <script>
    function AutoRefresh(t){
      setTimeout("location.reload(true);", t);
      }
  </script>
</head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  

<body onload="javascript:AutoRefresh(5000);">
    <center>
 <h1>RELEVE COMPTEUR FORCE MOTRICE JBU2</h1>
 <table class="table table-striped table-bordered">
   <thead>
     <tr>
       
       <th class="text-center">date</th>
       <th class="text-center">1_8_1</th>
       <th class="text-center">1_8_2</th>
       <th class="text-center">1_8_3</th>
       <th class="text-center">1_8_0</th>
       <th class="text-center">3_8_0</th>
       <th class="text-center">D_7_0</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       
       <td class="text-center"><?php echo htmlspecialchars($row['date']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['1_8_1']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['1_8_2']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['1_8_3']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['1_8_0']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['3_8_0']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['D_7_0']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>

	 <button type="button" class="btn btn-primary" style="margin-bottom: 2%;" onclick="tableToCSV()">
			Téleharger Compteur Force Motrice
	 </button>

		<div>
			 <form>
		   <input type=button class="btn btn-success" style="margin-bottom: 3%;"onclick=window.location.href='http://10.0.3.19:8080/outil_sg/compteur/accueil_jbu2.html'; value=Retour>
		  </form>
		</div>

	 </table>

 <script type="text/javascript">
		function tableToCSV() {

			// Variable to store the final csv data
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "fm.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
	</script>
    </center>
</body>
</html>