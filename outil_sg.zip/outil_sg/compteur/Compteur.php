<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVEE COMPTEUR FM</title>
  </head>

  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%;color:#CD5C5C">RELEVEE COMPTEUR FM</h3>                        
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
                <form class="row" method="POST" action="Envoie_FM.php">  
                  <div id="actualiserfm" class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">3_8_0 (Reactif)</th>
                          <th scope="col">13_4_0</th>
                          <th scope="col">1_8_0 (Actif)</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" class="form-control" name="3_8_0" required="required"> </td>
                            <td> <input type="number" class="form-control" name="13_4_0" required="required"> </td>
                            <td> <input type="number" class="form-control" name="1_8_0" required="required"> </td>
                            
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">1_8_1 (Actif Jour)</th>
                          <th scope="col">1_8_2 (Actif Point)</th>
                          <th scope="col">1_8_3 (Actif Nuit)</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" class="form-control" name="1_8_1" required="required"> </td>
                            <td> <input type="number" class="form-control" name="1_8_2" required="required"> </td>
                            <td> <input type="number" class="form-control" name="1_8_3" required="required"> </td>                                                      
                          </tr>
                      </tbody>
                           
                  </div> 
                        </tr>
                      
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Compteur FM"onclick="return myconfirm()"/>
                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 
  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%;color:#CD5C5C">RELEVEE COMPTEUR LIGNES</h3> 
                <form class="row" method="POST" action="Envoie_Lignes.php">  
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Laser 1</th>
                          <th scope="col">Laser 2</th>
                          <th scope="col">Laser 3</th>
                        </tr>
                      </thead>
                      <tbody class="p-3 mb-2 bg-gradient-info text-white">
                          <tr>
                            <td> <input type="number" class="form-control" name="Laser_1" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Laser_2" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Laser_3" required="required"> </td>
                            
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Auxiliaire</th>
                          <th scope="col">Fox</th>
                          <th scope="col">Nutriset</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" class="form-control" name="Auxiliaire" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Fox" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Nutriset" required="required"> </td>                                                      
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                            <tr class="p-3 mb-2 bg-secondary text-white">
                              <th scope="col">Fourrage Aux</th>
                              <th scope="col">Enrobeuse Aux</th>
                              <th scope="col">Four Laser 2</th>
                            </tr>
                          </thead>
                          <tbody>
                              <tr>
                                <td> <input type="number" class="form-control" name="Fourrage_Aux" required="required"> </td>
                                <td> <input type="number" class="form-control" name="Enrobeuse_Aux" required="required"> </td>
                                <td> <input type="number" class="form-control" name="Four_Laser_2" required="required"> </td>                                                      
                              </tr>
                        </tbody>
                        <thead class="thead-dark">
                          <tr class="p-3 mb-2 bg-secondary text-white">
                            <th scope="col">Choco</th>
                            <th scope="col">Gum</th>
                            <th scope="col">TPJ</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td> <input type="number" class="form-control" name="Choco" required="required"> </td>
                              <td> <input type="number" class="form-control" name="Gum" required="required"> </td>
                              <td> <input type="number" class="form-control" name="TPJ" required="required"> </td>                                                      
                            </tr>
                        </tbody>           
                     </div> 
                            </tr>
                      
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Compteur Ligne"onclick="return myconfirm()"/>
                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 

  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%;color:#CD5C5C">RELEVEE COMPTEUR EAU</h3>
              <form class="row" method="POST" action="Envoie_Eau.php">  
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Eau_Confiserie</th>
                          <th scope="col">Eau_Biscuit</th>
                          <th scope="col">Ria_1</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" class="form-control" name="Eau_Confiserie" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Eau_Biscuit" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Ria_1" required="required"> </td>
                            
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Ria_2</th>
                          <th scope="col">Ria_3</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" class="form-control" name="Ria_2" required="required"> </td>
                            <td> <input type="number" class="form-control" name="Ria_3" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                           
                  </div> 
                        </tr>
                      
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Compteur Eau"onclick="return myconfirm()"/>
                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 
  </body>

  </html>