<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVE COMPTEUR FM JBU2</title>
  </head>

<body style="background-color:lightsteelblue;">
  <h3 style="display:flex;justify-content:center;margin-top:1%;margin-bottom:2%;color:#CD5C5C">RELEVE COMPTEUR LIGNES JBU2</h3> 
                <form class="row" method="POST" action="Envoie_Lignes_JBU2.php">  
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Auxiliaire Généraux</th>
                          <th scope="col">Chambre Froide</th>
                          <th scope="col">Pellets</th>                          
                        </tr>
                      </thead>
                      <tbody class="p-3 mb-2 bg-gradient-info text-white">
                          <tr>

                             <?php
                            require 'Select_last_value_lignes_JBU2.php';
                            ?>

                            <td> <input type="number" placeholder="<?=$fm['Auxiliaire_Generaux']?>" step="0.01" class="form-control" name="Auxiliaire_Generaux" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Chambre_Froid']?>" step="0.01" class="form-control" name="Chambre_Froid" required="required"> </td> 
                            <td> <input type="number" placeholder="<?=$fm['Machines_Productions']?>" step="0.01" class="form-control" name="Machines_Productions" required="required"> </td>                                                       
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Friture GM</th>
                          <th scope="col">Friture PM</th>
                          <th scope="col">Faconnage Tubz</th>
                                                   
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" placeholder="<?=$fm['Friture_gm']?>" step="0.01" class="form-control" name="Friture_gm" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Friture_pm']?>" step="0.01" class="form-control" name="Friture_pm" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Tubz']?>" step="0.01" class="form-control" name="Tubz" required="required"> </td>
                                                                                                         
                          </tr>
                      </tbody>
                          <thead class="thead-dark">
                            <tr class="p-3 mb-2 bg-secondary text-white">
                              <th scope="col">Sécheur Tubz + ATLAS + Bosch</th>
                              <th scope="col">Curl + Ensacheuse ZZ</th> 
                              <th scope="col">Coex + Ensacheuses Baopack PIWI</th>
                              
                            </tr>
                          </thead>
                      <tbody>
                            <tr>
                              <td> <input type="number" placeholder="<?=$fm['Secheur_lt']?>" step="0.01" class="form-control" name="Secheur_lt" required="required"> </td>
                              <td> <input type="number" placeholder="<?=$fm['Curl']?>" step="0.01" class="form-control" name="Curl" required="required"> </td>
                              <td> <input type="number" placeholder="<?=$fm['Coex']?>" step="0.01" class="form-control" name="Coex" required="required"> </td>                                                          
                            </tr>
                          </tbody>

                          <thead class="thead-dark">
                            <tr class="p-3 mb-2 bg-secondary text-white">
                              <th scope="col">Ensacheuses Salto</th>
                              <th scope="col">Broyeur Maïs</th>

                            </tr>
                          </thead>
                      <tbody>
                            <tr>
                              <td> <input type="number" placeholder="<?=$fm['Ensacheuse']?>" step="0.01" class="form-control" name="Ensacheuse" required="required"> </td>
                              <td> <input type="number" placeholder="<?=$fm['Broyeur']?>" step="0.01" class="form-control" name="Broyeur" required="required"> </td>
                                                          
                            </tr>
                          </tbody>
                                              
                     </div> 
                    
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>

                     <form>
                      <input type=button class="btn btn-primary" onclick=window.location.href='http://10.0.3.19:8080/outil_sg/compteur/accueil_JBU2.html'; value=Retour>
                     </form>
                    
                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 

                 <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>

  </body>

  </html>