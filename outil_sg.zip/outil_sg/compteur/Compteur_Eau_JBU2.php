<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVE COMPTEUR FM JBU2</title>
  </head>

 <body style="background-color:powderblue;">
                
  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%;color:#CD5C5C">RELEVE COMPTEUR EAU JBU2</h3>
              <form class="row" method="POST" action="Envoie_Eau_JBU2.php">  
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Eau JBU2</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>

                             <?php
                            require 'Select_last_value_eau_jbu2.php';
                            ?>

                            <td> <input type="number" placeholder="<?=$fm['Eau_JBU2']?>" step="0.01" class="form-control" name="Eau_JBU2" required="required"> </td>
                          </tr>                         
                      </tbody>                 
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>

                    <form>
                      <input type=button class="btn btn-primary" onclick=window.location.href='http://10.0.3.100:8080/outil_sg/compteur/accueil_JBU2.html'; value=Retour>
                    </form>

                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 
                   <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>

  </body>

  </html>