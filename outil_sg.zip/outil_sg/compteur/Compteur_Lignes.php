<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVE COMPTEUR FM</title>
  </head>

<body style="background-color:lightsteelblue;">
  <h3 style="display:flex;justify-content:center;margin-top:1%;margin-bottom:2%;color:#CD5C5C">RELEVE COMPTEUR LIGNES</h3> 
                <form class="row" method="POST" action="Envoie_Lignes.php">  
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Laser 1</th>
                          <th scope="col">Laser 2</th>
                          <th scope="col">Laser 3</th>
                        </tr>
                      </thead>
                      <tbody class="p-3 mb-2 bg-gradient-info text-white">
                          <tr>
                            <?php
                            require 'Select_last_value_lignes.php';
                            ?>

                            <td> <input type="number" value="<?=$fm['Laser_1']?>" step="0.01" class="form-control" name="Laser_1" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Laser_2']?>" step="0.01" class="form-control" name="Laser_2" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Laser_3']?>" step="0.01" class="form-control" name="Laser_3" required="required"> </td>
                            
                          </tr>
                      </tbody>
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Auxiliaire Généraux</th>
                          <th scope="col">Fox</th>
                          <th scope="col">Plumpy</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['Auxiliaire_Generaux']?>" step="0.01" class="form-control" name="Auxiliaire_Generaux" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Fox']?>" step="0.01" class="form-control" name="Fox" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Plumpy']?>" step="0.01" class="form-control" name="Plumpy" required="required"> </td>                                                  
                          </tr>
                      </tbody>
                          <thead class="thead-dark">
                            <tr class="p-3 mb-2 bg-secondary text-white">
                              <th scope="col">Principale Aux TGBT</th>
                              <th scope="col">Lignes Aux</th>
                              <th scope="col">Four Laser 2</th>
                            </tr>
                          </thead>
                      <tbody>
                            <tr>
                              <td> <input type="number" value="<?=$fm['Fourrage_Aux']?>" step="0.01" class="form-control" name="Fourrage_Aux" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Enrobeuse_Aux']?>" step="0.01" class="form-control" name="Enrobeuse_Aux" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Four_Laser_2']?>" step="0.01" class="form-control" name="Four_Laser_2" required="required"> </td>                                                      
                            </tr>
                          </tbody>
                        <thead class="thead-dark">
                          <tr class="p-3 mb-2 bg-secondary text-white">
                            <th scope="col">Choco</th>
                            <th scope="col">Gum 1</th>
                            <th scope="col">Gum 2</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td> <input type="number" value="<?=$fm['Choco']?>" step="0.01" class="form-control" name="Choco" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Gum_1']?>" step="0.01" class="form-control" name="Gum_1" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Gum_2']?>" step="0.01" class="form-control" name="Gum_2" required="required"> </td>                                                      
                            </tr>
                        </tbody>   

                         <thead class="thead-dark">
                          <tr class="p-3 mb-2 bg-secondary text-white">
                            <th scope="col">Confiserie</th>
                            <th scope="col">Richeng</th>
                            <th scope="col">Lumière GS</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td> <input type="number" value="<?=$fm['Confiserie']?>" step="0.01" class="form-control" name="Confiserie" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Richeng']?>" step="0.01" class="form-control" name="Richeng" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Lumiere_GS']?>" step="0.01" class="form-control" name="Lumiere_GS" required="required"> </td>                                                      
                            </tr>
                        </tbody> 

                        <thead class="thead-dark">
                          <tr class="p-3 mb-2 bg-secondary text-white">
                            <th scope="col">Betapack</th>
                            <th scope="col">Baopack</th>
                            <th scope="col">Sucre Inverti</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td> <input type="number" value="<?=$fm['Betapack']?>" step="0.01" class="form-control" name="Betapack" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Baopack']?>" step="0.01" class="form-control" name="Baopack" required="required"> </td>
                              <td> <input type="number" value="<?=$fm['Sucre_Inverti']?>" step="0.01" class="form-control" name="Sucre_Inverti" required="required"> </td>                                                      
                            </tr>
                        </tbody> 


                     </div> 
                    
                    </table>  
                  </div> 
                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    <input class="btn btn-success"type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>

                     <form>
                      <input type=button class="btn btn-primary" onclick=window.location.href='http://10.0.3.19:8080/outil_sg/compteur/acceuil.html'; value="< Retour">
                     </form>
                    
                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Veuillez confirmer...'))
                      return true;
                      return false;
                      }
                    </script>
                  </div>
                 </form> 

                 <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>

  </body>

  </html>