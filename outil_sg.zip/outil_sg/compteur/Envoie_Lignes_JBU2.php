<?php
session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=compteur_fm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
          $req = $bdd->prepare('INSERT INTO lignes_jbu2 (date,Auxiliaire_Generaux,
                                                        Chambre_Froid,
                                                        Machines_Productions,                                                     
                                                        Friture_gm,
                                                        Friture_pm,
                                                        Tubz,
                                                        Secheur_lt,
                                                        Curl,
                                                        Coex,
                                                        Ensacheuse,
                                                        Broyeur)
                                                        
                                                         
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,                                 
                                        ?)');
         $req->execute(array(
                             
                             $_POST['Auxiliaire_Generaux'],
                             $_POST['Chambre_Froid'],
                             $_POST['Machines_Productions'],                             
                             $_POST['Friture_gm'],
                             $_POST['Friture_pm'],
                             $_POST['Tubz'],
                             $_POST['Secheur_lt'],
                             $_POST['Curl'],
                             $_POST['Coex'],
                             $_POST['Ensacheuse'],
                             $_POST['Broyeur']));
   

header('location:http://10.0.3.19:8080/outil_sg/compteur/compteur_Lignes_JBU2.php');
 ?>

 