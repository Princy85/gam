<?php
session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=compteur_fm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
          $req = $bdd->prepare('INSERT INTO fm_jbu2 (date,1_8_1,
                                                        1_8_2,
                                                        1_8_3,
                                                        1_8_0,
                                                        3_8_0,
                                                        D_7_0) 
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?)');
         $req->execute(array(
                             
                             $_POST['1_8_1'],
                             $_POST['1_8_2'],
                             $_POST['1_8_3'],
                             $_POST['1_8_0'],
                             $_POST['3_8_0'],
                             $_POST['D_7_0']));
   

header('location:http://10.0.3.19:8080/outil_sg/compteur/compteur_FM_JBU2.php');
 ?>

 