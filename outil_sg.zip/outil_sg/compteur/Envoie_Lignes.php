<?php
session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=compteur_fm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
          $req = $bdd->prepare('INSERT INTO lignes (date,Laser_1,
                                                        Laser_2,
                                                        Laser_3,
                                                        Auxiliaire_Generaux,
                                                        Fox,
                                                        Plumpy,
                                                        Fourrage_Aux,
                                                        Enrobeuse_Aux,
                                                        Four_Laser_2,
                                                        Choco,
                                                        Gum_2,
                                                        Gum_1,
                                                        Confiserie,
                                                        Richeng,
                                                        Lumiere_GS,
                                                        Betapack,
                                                        Baopack,
                                                        Sucre_Inverti) 
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?)');
         $req->execute(array(
                             
                             $_POST['Laser_1'],
                             $_POST['Laser_2'],
                             $_POST['Laser_3'],
                             $_POST['Auxiliaire_Generaux'],
                             $_POST['Fox'],
                             $_POST['Plumpy'],
                             $_POST['Fourrage_Aux'],
                             $_POST['Enrobeuse_Aux'],
                             $_POST['Four_Laser_2'],
                             $_POST['Choco'],
                             $_POST['Gum_2'],
                             $_POST['Gum_1'],
                             $_POST['Confiserie'],
                             $_POST['Richeng'],
                             $_POST['Lumiere_GS'],
                             $_POST['Betapack'],
                             $_POST['Baopack'],
                             $_POST['Sucre_Inverti']));
   

header('location:http://10.0.3.19:8080/outil_sg/compteur/compteur_Lignes.php');
 ?>

 