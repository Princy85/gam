<?php
session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=compteur_fm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
          $req = $bdd->prepare('INSERT INTO eau_jbu2 (date,Eau_JBU2)
                                                         
                                  VALUES(now(),                                        
                                        ?)');
         $req->execute(array(
                             
                            $_POST['Eau_JBU2']));
   

header('location:http://10.0.3.19:8080/outil_sg/compteur/compteur_Eau_JBU2.php');
 ?>