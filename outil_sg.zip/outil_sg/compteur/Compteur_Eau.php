<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVE COMPTEUR EAU</title>
  </head>

 <body style="background-color:powderblue;">
                
  <h3 style="display:flex;justify-content:center;margin-top:0%;margin-bottom:2%;color:#CD5C5C">RELEVE COMPTEUR EAU</h3>
<form class="row" method="POST" action="Envoie_Eau.php" onsubmit="document.getElementById('button').disabled='diabled'; document.getElementById('button').addEventListener('click',function (){return false;},true)">
                        

                
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Relevé Confiserie</th>
                          <th scope="col">Relevé Biscuit</th>
                          <th scope="col">Ria 1</th>
                        </tr>
                      </thead>
                      <tbody>                      

                          <tr>

                            <?php
                            require 'Select_last_value_eau.php';
                            ?>


                            <td> <input type="text" placeholder="<?=$fm['Eau_Confiserie']?>" step="0.01" class="form-control" name="Eau_Confiserie" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Eau_Biscuit']?>" step="0.01" class="form-control" name="Eau_Biscuit" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Ria_1']?>" step="0.01" class="form-control" name="Ria_1" required="required"> </td>
                            
                          </tr>
                         
                      </tbody>

                      <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-secondary text-white">
                          <th scope="col">Ria 2</th>
                          <th scope="col">Ria 3</th>
                          <th scope="col">Relevé Plumpy</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" placeholder="<?=$fm['Ria_2']?>" step="0.01" class="form-control" name="Ria_2" required="required"> </td>
                            <td> <input type="number" placeholder="<?=$fm['Ria_3']?>" step="0.01" class="form-control" name="Ria_3" required="required"> </td>
                             <td> <input type="number" placeholder="<?=$fm['Eau_Plumpy']?>" step="0.01" class="form-control" name="Eau_Plumpy" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                    </div>

                  </div> 
                        </tr>
                      
                    </table>  
                  </div> 

                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    
                    <input class="btn btn-success"type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>


                    <form>
                      <input style="display:flex;justify-content:center" type=button class="btn btn-primary" onclick=window.location.href='http://10.0.3.19:8080/outil_sg/compteur/acceuil.html'; value="< Retour">
                    </form>

                    <script> 
                      function myalert() 
                      {
                        alert('Veuillez confirmer...');   
                      return true;
                      return false;                      
                      }
                    </script>

                  </div>

                 </form> 

                   <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>


  </body>

  </html>