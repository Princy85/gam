<?php

session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=compteur_fm', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
         $req = $bdd->prepare('INSERT INTO eau (date,Eau_Confiserie,
                                                        Eau_Biscuit,
                                                        Ria_1,
                                                        Ria_2,
                                                        Ria_3,
                                                        Eau_Plumpy) 
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?)');
         $req->execute(array(
                             
                             $_POST['Eau_Confiserie'],
                             $_POST['Eau_Biscuit'],
                             $_POST['Ria_1'],
                             $_POST['Ria_2'],
                             $_POST['Ria_3'],
                             $_POST['Eau_Plumpy']));
   

header('location:http://10.0.3.19:8080/outil_sg/compteur/compteur_Eau.php');
 ?>