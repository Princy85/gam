<?php
  $host = 'localhost';
  $dbname = 'gaz';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM releve_gaz";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<head></head>
 
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"/>
           <script href="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.css"></script> 
           <script href="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.bootstrap.min.css"></script>  
<body>
    <center>
 <h1>Relevés Gaz</h1>
 <table class="table table-striped table-bordered">
   <thead>
     <tr>
       <th class="text-center">ID</th>
       <th class="text-center">Date</th>
       <th class="text-center">Heure</th>
       <th class="text-center">Ligne</th>
       <th class="text-center">OF</th>
       <th class="text-center">Evenement</th>
       <th class="text-center">Sous-evenement</th>
       <th class="text-center">Production en cours</th>
       <th class="text-center">Valeur releve gaz</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td class="text-center"><?php echo htmlspecialchars($row['id_gaz']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['date']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['heure']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['liste_ligne']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['of']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['liste_event']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['liste_sous_event']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['prod_encours']); ?></td>
       <td class="text-center"><?php echo htmlspecialchars($row['revele_gaz_par_jour_L1']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>
   <button type="button" onclick="tableToCSV()">
			Download CSV
		</button>
 </table>

 <script type="text/javascript">
		function tableToCSV() {

			// Variable to store the final csv data
			var csv_data = [];

			// Get each row data
			var rows = document.getElementsByTagName('tr');
			for (var i = 0; i < rows.length; i++) {

				// Get each column data
				var cols = rows[i].querySelectorAll('td,th');

				// Stores each csv row data
				var csvrow = [];
				for (var j = 0; j < cols.length; j++) {

					// Get the text data of each cell
					// of a row and push it to csvrow
					csvrow.push(cols[j].innerHTML);
				}

				// Combine each column value with comma
				csv_data.push(csvrow.join(","));
			}

			// Combine each row data with new line character
			csv_data = csv_data.join('\n');

			// Call this function to download csv file
			downloadCSVFile(csv_data);

		}

		function downloadCSVFile(csv_data) {

			// Create CSV file object and feed
			// our csv_data into it
			CSVFile = new Blob([csv_data], {
				type: "text/csv"
			});

			// Create to temporary link to initiate
			// download process
			var temp_link = document.createElement('a');

			// Download csv file
			temp_link.download = "GfG.csv";
			var url = window.URL.createObjectURL(CSVFile);
			temp_link.href = url;

			// This link should not be displayed
			temp_link.style.display = "none";
			document.body.appendChild(temp_link);

			// Automatically click the link to
			// trigger download
			temp_link.click();
			document.body.removeChild(temp_link);
		}
	</script>
    </center>
</body>
</html>