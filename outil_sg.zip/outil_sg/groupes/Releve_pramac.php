<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVEE PARAMETRE GE</title>
  </head>

 <body style="background-color: #198754;">
                
  <h3 style="display:flex;justify-content:center;margin-top:1%;margin-bottom:2%;color:#dc3545">RELEVE PARAMETRE PRAMAC</h3>
<form class="row" method="POST" action="Envoie_pramac.php">                       

                
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Heure début</th>
                          <th scope="col">Heure fin</th>                         
                        </tr>
                      </thead>
                      <tbody>                  
                          <tr>
                            <?php
                            require 'parametre_pramac.php';
                            ?>
                            <td> <input type="time" class="form-control" name="Debut_coupure"> </td>
                            <td> <input type="time" class="form-control" name="Retour_jirama"> </td>                            
                          </tr>                         
                      </tbody>
                      <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Marche GE</th>
                          <th scope="col">Nbre démarrage</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" step="0.01" class="form-control" name="Marche_GE" required="required"> </td>
                            <td> <input type="number" step="0.01" class="form-control" name="Nbre_demarrage" required="required"> </td>
                          </tr>
                      </tbody>
                    </div>  

                    <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Tension batt</th>
                          <th scope="col">Compteur puissance</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" step="0.01" class="form-control" name="Tension_batt" required="required"> </td>
                            <td> <input type="number" step="0.01" class="form-control" name="Compteur_puissance" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                    </div>                     
                      
                        <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Observation</th>
                          <th scope="col">TDM</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="text" step="0.01" class="form-control" name="Observation" required="required"> </td>
                            <td> <input type="text" step="0.01" class="form-control" name="TDM" required="required"> </td>
                                                                                                 
                          </tr>
                      </tbody>
                      </div>

                  </div> 
                        </tr>
                      
                    </table>  
                  </div> 

                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    
                    <input class="btn btn-secondary active" type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>


                    <script> 
                      function myalert() 
                      {
                        alert('Veuillez confirmer...');   
                      return true;
                      return false;                      
                      }
                    </script>

                  </div>

                 </form> 

                   <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>


  </body>

  </html>