<?php

session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=groupes', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
         $req = $bdd->prepare('INSERT INTO parametre_pramac (date,
                                                        Debut_coupure,
                                                        Retour_jirama,
                                                        Marche_GE,
                                                        Nbre_demarrage,
                                                        Tension_batt,
                                                        Compteur_puissance,
                                                        Observation,
                                                        TDM)
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,                                        
                                        ?)');
         $req->execute(array(
                             $_POST['Debut_coupure'],
                             $_POST['Retour_jirama'],
                             $_POST['Marche_GE'],
                             $_POST['Nbre_demarrage'],
                             $_POST['Tension_batt'],                             
                             $_POST['Compteur_puissance'],
                             $_POST['Observation'],
                             $_POST['TDM']));

header('location:http://10.0.3.19:8080/outil_sg/groupes/releve_pramac.php');
 ?>