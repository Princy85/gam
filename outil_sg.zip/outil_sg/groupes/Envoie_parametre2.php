<?php

session_start();
 try{
   $bdd = new PDO('mysql:host=localhost; dbname=groupes', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
         }
         catch (Exception $e){
               // En cas d'erreur, on affiche un message et on arrête tout
         die('Erreur : '.$e->getMessage());
        }
         $req = $bdd->prepare('INSERT INTO parametre_cat2 (date,
                                                        Debut_coupure,
                                                        Retour_jirama,
                                                        Marche_GE,
                                                        Tours_minutes,
                                                        Tension_batt,
                                                        Pression_huile,
                                                        Temp_moteur,
                                                        Frequence,
                                                        U1,
                                                        U2,
                                                        U3,
                                                        I1,
                                                        I2,
                                                        I3,
                                                        Cos,
                                                        Compteur_puissance,
                                                        Observation,
                                                        TDM)
                                  VALUES(now(),
                                        ?,                                        
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?)');
         $req->execute(array(
                             $_POST['Debut_coupure'],
                             $_POST['Retour_jirama'],
                             $_POST['Marche_GE'],
                             $_POST['Tours_minutes'],
                             $_POST['Tension_batt'],
                             $_POST['Pression_huile'],
                             $_POST['Temp_moteur'],
                             $_POST['Frequence'],
                             $_POST['U1'],
                             $_POST['U2'],
                             $_POST['U3'],
                             $_POST['I1'],
                             $_POST['I2'],
                             $_POST['I3'],
                             $_POST['Cos'],
                             $_POST['Compteur_puissance'],
                             $_POST['Observation'],
                             $_POST['TDM']));

header('location:http://10.0.3.19:8080/outil_sg/groupes/releve_parametre_cat2.php');
 ?>