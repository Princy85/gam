<?php
//On inclue se fichier car il contient la fonction bdd_connexion()
include 'Envoie.php';
//on se connecte à la base de donnée
bdd_connexion();
 
//requete effectué pour lister les différents sites dans la liste déroulante
$requete_site ="SELECT DISTINCT Type FROM moteurs ORDER BY Type";
 
//vérification de la requête
$result_site = mysql_query($requete_Type)
    or die ("Execution impossible de la requête");
 
//creéation d'une liste déroulante site
echo "<p id='lieu'>du site ";
echo "<select name='endroit'>
        <option value='0'>--Veuillez choisir--\n";
    while($ligne_site = mysql_fetch_assoc($result_site))
    {
        extract($ligne_site);
        echo "<option value='$site'>$site\n";
    }
 
//requete effectué pour lister les différents sites dans la liste déroulante
$requete_terrain ="SELECT Type FROM moteurs WHERE Type LIKE '$Type'";
 
//vérification de la requête
$result_terrain = mysql_query($requete_sous_reseau)
    or die ("Execution impossible de la requête");
 
//creéation d'une liste déroulante terrain
echo "<p id='parcelle'>et du terrain ";
echo "<select name='terrain'>
    <option value='0' selected>--Veuillez choisir--\n
    <option value='1'>Tous\n";
    while($ligne_terrain = mysql_fetch_assoc($result_terrain))
    {
        extract($ligne_sous_reseau);
        echo "<option value='$terrain'>$terrain\n";
    }
echo"</select></p>";
 
?>