<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>FICHES MOTEURS</title>
  </head>  

  <img src="jb2.jpg" style="width:70px; height:70px;" alt="jb" class="float-start">
                
  <h2 class="fw-bolder" style="display:flex; justify-content:center; margin-top:0%; color:#212529">Contrôle Systematique</h2>
  <h2 class="fw-bolder" style="display:flex; justify-content:center; margin-top:0%; color:#212529">Moteur Electrique</h2>

<body style="background-color:lightskyblue;">

  
<form class="row" method="POST" action="Envoie.php">

   
          <p class="bg-light border border-3 border-danger">
                           
          <div id="liste" >

                  <div class="input-group mb-3">                                                                  
                                <span class="input-group-text">UAP:</span>                                
                                <select id="uap" class="form-select" name="UAP" style="margin-top: 0%;" required>            
                                      <option value="1">Choisir</option> 
                                </select>      
                                <span style="margin-left: 2%;" class="input-group-text">Responsable: </span>                                      
                                <select name="Responsable" id="responsable" class="form-select" required>
                                      <option value="2">Choisir</option>
                                </select>                              
                  </div>

                  <div class="input-group mb-3">
                                <span class="input-group-text">Lignes:</span>                 
                                <select id="services" class="form-select" name="Lignes" required>
                                <option value="3">Choisir</option>
                                </select>
                  </div>
     
                          

                  <div class="input-group mb-3">
                          <span class="input-group-text">Machines: </span>                   
                          <select id="Linge_prod"class="form-select" name="Machines" required>
                            
                          </select>
                  </div>

                  <div class="input-group mb-3">
                                             
                          <input id="Linge_prod" class="form-control" name="Emplacement" placeholder="Emplacement">                           
                          
                  </div>
                 

                                  
                  <label style="margin-left: 2%;" for="basic-url" class="text-decoration-underline text-danger">Information sur le Moteur:</label> 

                  <div class="input-group mb-3">  

                        <span style="margin-top: 1%; margin-right: 0%;" class="input-group-text">Type:</span>
                        <input style="margin-top: 1%; margin-left: 0%;" type="text" placeholder="Type du moteur" class="form-control"  name="Type" required>
                        <span style="margin-top: 1%; margin-left: 2%;" class="input-group-text">Couplage:</span>
                          <select style="margin-top: 1%;" name="Couplage" class="form-select" required>
                              <option selected>Choisir...</option>
                              <option value="Etoile">Etoile</option>
                              <option value="Triangle">Triangle</option><!DOCTYPE html>
                              <option value="Direct">Direct</option>
                              <option value="Etoile/triangle">Etoile/Triangle</option>
                          </select>

                  </div>                         

                        <div class="input-group mb-3">
                            <span style="margin-top: 1%;" class="input-group-text">P:</span>
                            <input style="margin-top: 1%;" type="text" placeholder="Puissance" class="form-control" name="Puissance" required>
                            <span style="margin-top: 1%;" class="input-group-text">kW</span> 
                            <span style="margin-top: 1%;margin-left: 2%;" class="input-group-text">U:</span>
                            <input style="margin-top: 1%;" type="number" placeholder="Tension" class="form-control" name="Tension" required>
                            <span style="margin-top: 1%;" class="input-group-text">V</span>
                        </div>
                          
                        <div class="input-group mb-3">
                            <span style="margin-top: 0%;margin-left: 0%;" class="input-group-text">N:</span>
                            <input style="margin-top: 0%;" type="text" placeholder="Tour par minute" class="form-control" name="Tours_minutes" required>
                            <span style="margin-top: 0%;" placeholder="Machine" type="number" class="input-group-text">tr/min</span>
                            <span style="margin-left: 2%;" class="input-group-text">f:</span>
                        <select name="Frequence" class="form-select" required>
                            <option selected>Choisir...</option>
                            <option value="50">50</option>
                            <option value="60">60</option>
                        </select>
                            <span style="margin-top: 0%;" class="input-group-text">Hz</span>

                        </div>

                          <div class="input-group mb-3">
                              <span style="margin-top: 0%;" class="input-group-text">Inom:</span>
                              <input style="margin-top: 0%;" type="text" placeholder="Intensité" class="form-control" name="Intensite" required>
                              <span style="margin-top: 0%;" class="input-group-text">A:</span>
                              <span style="margin-top: 0%;margin-left: 2%;" class="input-group-text">Cos φ:</span>
                              <input style="margin-top: 0%;" type="text" placeholder="Cos φ" class="form-control" name="Cos" required>
                          </div>

                          <div class="input-group mb-3">                   
                              <span style="margin-top: 0%;" class="input-group-text">Roul.avant:</span>
                              <input style="margin-top: 0%;" type="text" placeholder="Réference" class="form-control" name="Roul_avant">
                              <span style="margin-top: 0%;margin-left: 2%;" class="input-group-text">Roul.arr:</span>
                              <input style="margin-top: 0%;" type="text" placeholder="Réference" class="form-control" name="Roul_arr">
                          </div>

                         
                          <div class="input-group mb-3">
                              <span style="margin-top: 0%;" class="input-group-text">IP:</span>
                              <input style="margin-top: 0%;" type="number" placeholder="Indice de Protection" class="form-control" name="Indice_protection">
                              <span style="margin-top: 0%;margin-left: 2%;" class="input-group-text" id="basic-addon1">Constructeur:</span>
                              <input type="text" placeholder="Fabriquant" class="form-control" name="Constructeur">                           
                          </div>

                  <p class="bg-light border border-3 border-danger">
                  <div class="input-group mb-3">                  
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 1%;" class="fw-bolder text-success" for="basic-url">MOTEUR A L'ARRET</label>                         
                      <br class="bg-light border border-primary"></thead>
                  </div>

                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 2%; margin-top: 0%;" class="text-danger" for="basic-url">Valeur ohmique idéal:</label>  
                      </thead>
                  </div> 
                  <div class="input-group mb-3">                                    
                                
                              <input type="text" class="form-control" placeholder="R1 Ω" name="R1_id">
                              <input type="text" class="form-control" placeholder="R2 Ω" name="R2_id">                             
                              <input type="text" class="form-control" placeholder="R3 Ω" name="R3_id">
                  </div>

                  <div class="input-group mb-3">                    
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Isolement Moteur:</label>  
                      </thead>
                  </div>

                  <div class="input-group mb-3">                    
                              <span class="input-group-text">R1-R2 [MΩ]</span>
                              <input type="text" class="form-control" placeholder="R1" name="R1" >
                  </div>

                  <div class="input-group mb-3">
                              <span style="margin-left: 0%;" class="input-group-text">R1-R3 [MΩ]</span>
                              <input type="text" class="form-control" placeholder="R2" name="R2" >
                  </div>

                  <div class="input-group mb-3">
                              <span style="margin-left: 0%;" class="input-group-text">R2-R3 [MΩ]</span>
                              <input type="text" class="form-control" placeholder="R3" name="R3" >
                  </div>

                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 0%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Isolement % masse:</label>  
                      </thead>
                  </div>

                  <div class="input-group mb-3">
                              <span class="input-group-text">R1 % masse</span>
                              <input type="text" name="R1_masse" class="form-control" placeholder="R1" >
                  </div>

                  <div class="input-group mb-3">
                              <span style="margin-left: 0%;" class="input-group-text">R2 % masse</span>
                              <input type="text" name="R2_masse" class="form-control" placeholder="R2" >
                  </div>

                  <div class="input-group mb-3"> 
                              <span style="margin-left: 0%;" class="input-group-text">R3 % masse</span>
                              <input type="text" name="R3_masse" class="form-control" placeholder="R3" >
                  </div>   

                 <p class="bg-light border border-3 border border-danger">

                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Armoir électrique:</label>  
                      </thead>
                  </div>

                  <div class="input-group mb-3">
                              <span class="input-group-text">Etat câble</span>
                                <select class="form-select" name="Etat_cable">
                                  <option selected>Choisir...</option>
                                  <option value="1">OK</option>
                                  <option value="2">KO</option>                                  
                                </select>

                              <span style="margin-left: 1%;" class="input-group-text">Serrage bornier</span>
                                <select class="form-select" name="Serrage_bornier">
                                  <option selected>Choisir...</option>
                                  <option value="1">OK</option>
                                  <option value="2">KO</option>                                  
                                </select>

                  </div>
                  <div class="input-group mb-3"> 
                              <span style="margin-left: 0%;" class="input-group-text">Rangement câble</span>
                                <select class="form-select" name="Rangement_cable">
                                  <option selected>Choisir...</option>
                                  <option value="1">OK</option>
                                  <option value="2">KO</option>                                  
                                </select>
                              <span style="margin-left: 1%;" class="input-group-text">Propreté</span>
                                <select class="form-select" name="Proprete">
                                  <option selected>Choisir...</option>
                                  <option value="1">OK</option>
                                  <option value="2">KO</option>                                  
                                </select>
                  </div>

                  <p class="bg-light border border-3 border-danger">

                  <div class="input-group mb-3">                  
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 1%;" class="fw-bolder text-success" for="basic-url">MOTEUR EN MARCHE</label>                         
                      <br class="bg-light border border-primary"></thead>
                  </div>

                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Intensité à vide:</label>  
                      </thead>
                  </div>
                     
                  <div class="input-group mb-3">                   
                              <input type="text" class="form-control" placeholder="Réf I1 à vide" name="I1_id_vide">
                              <input type="text" class="form-control" placeholder="Réf I2 à vide" name="I2_id_vide">                             
                              <input type="text" class="form-control" placeholder="Réf I3 à vide" name="I3_id_vide">
                  </div>

                  <div class="input-group mb-3">                   
                              <input type="text" class="form-control" placeholder="Valeur I1 réel" name="I1_vide" >
                              <input type="text" class="form-control" placeholder="Valeur I2 réel" name="I2_vide" >                             
                              <input type="text" class="form-control" placeholder="Valeur I3 réel" name="I3_vide" >
                  </div>

                  <p class="bg-light border border-3 border-danger">
                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Intensité en charge:</label>  
                      </thead>
                  </div>
                     
                  <div class="input-group mb-3">                   
                              <input type="text" class="form-control" placeholder="Réf I1 en charge" name="I1_id_charge">
                              <input type="text" class="form-control" placeholder="Réf I2 en charge" name="I2_id_charge">                             
                              <input type="text" class="form-control" placeholder="Réf I3 en charge" name="I3_id_charge">
                  </div>

                  <div class="input-group mb-3">                   
                              <input type="text" class="form-control" placeholder="Valeur I1 réel"  name="I1_charge" >
                              <input type="text" class="form-control" placeholder="Valeur I2 réel"  name="I2_charge" >                             
                              <input type="text" class="form-control" placeholder="Valeur I3 réel"  name="I3_charge" >
                  </div>

                  <div class="input-group mb-3">                  
                              <input type="text" class="form-control" placeholder="Température bâti moteur °C" name="Temperature">  
                              <input type="text" style="margin-left: 0%;" class="form-control" placeholder="Capacité charge Kg" name="Capacite">                          
                  </div>
                  <div class="input-group mb-3">                  
                              <input type="text" class="form-control" placeholder="Echauffement câble électrique" name="Echauffement">                        
                  </div>

                  <p class="bg-light border border-3 border-danger">
                  <div class="input-group mb-3">
                      <thead class="thead-dark">
                         <label style="margin-left: 1%; margin-top: 0%;" for="basic-url" class="text-decoration-underline">Calibrage protection:</label>  
                      </thead>
                  </div>                 
                  <div class="input-group mb-3">                   
                              <input type="text" class="form-control" placeholder="Valeur idéal" name="Calibration_id">
                  </div>
                  <div class="input-group mb-3">
                              <input type="text" class="form-control" placeholder="Calibrage relais ou disj moteur [A]" name="Calibration">                            
                  </div>      


                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    
                    <input class="btn btn-success"type="submit" name="button" value="Envoyer" onclick="return myconfirm()"/>

                    <script> 
                      function myconfirm() 
                      {
                        if (confirm('Confirmer...'))
                      return true;
                      return false;
                      }
                    </script>       

                  </div>
                </div>

                 </form>
<script>
        var tbl_uap = [
          
      {"uap_code": "UAP1", "uap_nom": "UAP1"}, 
      {"uap_code": "UAP2", "uap_nom": "UAP2"},  
      {"uap_code": "UAP3", "uap_nom": "UAP3"},  
      {"uap_code": "UAP4", "uap_nom": "UAP4"}, 
      {"uap_code": "SG-ELEC", "uap_nom": "SG-ELEC"},
      {"uap_code": "ATC-PR", "uap_nom": "ATC-PR"},
      {"uap_code": "HORS-SITE", "uap_nom": "HORS-SITE"},

          
          ];
              
              var tbl_region_2016 = [
          /*UAP1*/
      {"reg_2016_code": "LASER2", "reg_2016_nom": "LASER2","uap_code": "UAP1"}, 
      {"reg_2016_code": "TPJ", "reg_2016_nom": "TPJ","uap_code": "UAP1"},  
      {"reg_2016_code": "LASER1", "reg_2016_nom": "LASER1","uap_code": "UAP1"}, 
      {"reg_2016_code": "ENROBE", "reg_2016_nom": "ENROBE","uap_code": "UAP1"}, 
      {"reg_2016_code": "GAUFRETTE", "reg_2016_nom": "GAUFRETTE","uap_code": "UAP1"}, 
      {"reg_2016_code": "LASER3", "reg_2016_nom": "LASER3","uap_code": "UAP1"},

          /*UAP2*/
          
      {"reg_2016_code": "BBM", "reg_2016_nom": "BBM","uap_code": "UAP2"}, 
      {"reg_2016_code": "CHOCO", "reg_2016_nom": "CHOCO","uap_code": "UAP2"}, 
      {"reg_2016_code": "BBD", "reg_2016_nom": "BBD","uap_code": "UAP2"}, 
      {"reg_2016_code": "GUM", "reg_2016_nom": "GUM","uap_code": "UAP2"}, 

          /**UAP3*/
          {"reg_2016_code": "PELLETS", "reg_2016_nom": "PELLETS","uap_code": "UAP3"}, 
      {"reg_2016_code": "COEX", "reg_2016_nom": "COEX","uap_code": "UAP3"}, 
      {"reg_2016_code": "CURL", "reg_2016_nom": "CURL","uap_code": "UAP3"}, 
      {"reg_2016_code": "FRITURE", "reg_2016_nom": "FRITURE","uap_code": "UAP3"}, 
      {"reg_2016_code": "TUBZ", "reg_2016_nom": "TUBZ","uap_code": "UAP3"}, 

      {"reg_2016_code": "STEP", "reg_2016_nom": "STEP","uap_code": "UAP3"}, 
      {"reg_2016_code": "BROYEUR", "reg_2016_nom": "BROYEUR","uap_code": "UAP3"}, 
      {"reg_2016_code": "AUXGEN", "reg_2016_nom": "AUXGEN","uap_code": "UAP3"}, 

          /**UAP4*/
      {"reg_2016_code": "PLUMPY", "reg_2016_nom": "PLUMPY","uap_code": "UAP4"}, 

          /**SG ELEC*/
      {"reg_2016_code": "SG", "reg_2016_nom": "SG","uap_code": "SG-ELEC"}, 
      {"reg_2016_code": "ELEC", "reg_2016_nom": "ELEC","uap_code": "SG-ELEC"}, 

          /**ATC PR*/
      {"reg_2016_code": "ATC", "reg_2016_nom": "ATC","uap_code": "ATC-PR"},
      {"reg_2016_code": "PR", "reg_2016_nom": "PR","uap_code": "ATC-PR"},

          /**HS*/
      {"reg_2016_code": "HS", "reg_2016_nom": "HS","uap_code": "HORS-SITE"},

          ];
      var tbl_rm_uap = [
          /**UAP1*/
          {"rm_code": "Orima", "rm_nom": "Orima","uap_code": "UAP1"},
          {"rm_code": "Njaka", "rm_nom": "Njaka","uap_code": "UAP1"},
          {"rm_code": "Mickael", "rm_nom": "Mickael","uap_code": "UAP1"},
          {"rm_code": "Paco", "rm_nom": "Paco","uap_code": "UAP1"},
          {"rm_code": "Roger", "rm_nom": "Roger","uap_code": "UAP1"},
          {"rm_code": "Sitraka", "rm_nom": "Sitraka","uap_code": "UAP1"},


          /**UAP2*/
          {"rm_code": "Mahefa", "rm_nom": "Mahefa","uap_code": "UAP2"},
          {"rm_code": "Hary Feno", "rm_nom": "Hary Feno","uap_code": "UAP2"},   
          {"rm_code": "Rijavola", "rm_nom": "Rijavola","uap_code": "UAP2"},
          {"rm_code": "Tsiresy", "rm_nom": "Tsiresy","uap_code": "UAP2"},
          {"rm_code": "Tahina", "rm_nom": "Tahina","uap_code": "UAP2"},
          {"rm_code": "Juniors", "rm_nom": "Juniors","uap_code": "UAP2"},
          {"rm_code": "Tantely_conf", "rm_nom": "Tantely_conf","uap_code": "UAP2"},

          /**UAP3*/
          {"rm_code": "Voahaja", "rm_nom": "Voahaja","uap_code": "UAP3"},
          {"rm_code": "Tahiry", "rm_nom": "Tahiry","uap_code": "UAP3"},
          {"rm_code": "Ando", "rm_nom": "Ando","uap_code": "UAP3"},

          /**UAP4*/
          {"rm_code": "Toky", "rm_nom": "Toky","uap_code": "UAP4"},
          {"rm_code": "Toky", "rm_nom": "Aina","uap_code": "UAP4"},

          /**SG ELEC*/
          {"rm_code": "Tantely", "rm_nom": "Tantely","uap_code": "SG-ELEC"},
          {"rm_code": "Daulphin", "rm_nom": "Daulphin","uap_code": "SG-ELEC"},
          {"rm_code": "Faly", "rm_nom": "Faly","uap_code": "SG-ELEC"},

          /**ATC PR*/
          {"rm_code": "Tantely", "rm_nom": "Tantely","uap_code": "ATC-PR"},
          {"rm_code": "Daulphin", "rm_nom": "Daulphin","uap_code": "ATC-PR"},
          {"rm_code": "Faly", "rm_nom": "Faly","uap_code": "ATC-PR"},
          /**HS*/
          {"rm_code": "Ando", "rm_nom": "Ando","uap_code": "HORS-SITE"},


          ];
           
          var tbl_Linge_prod =[
            /**FOX*/
      {"reg_code": "TMN", "reg_nom": "TMN", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "TCM", "reg_nom": "TCM", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "FOUR FOX", "reg_nom": "FOUR FOX", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "SORTIE FOUR", "reg_nom": "SORTIE FOUR", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "ELEVATEUR FEUILLES", "reg_nom": "ELEVATEUR FEUILLES", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "TARTINEUSE", "reg_nom": "TARTINEUSE", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "TUNNEL DE REFROIDIS", "reg_nom": "TUNNEL DE REFROIDIS ","reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE FOX", "reg_nom": "ARMOIRE ELECTRIQUE FOX", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "DECOUPEUSE", "reg_nom": "DECOUPEUSE", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "TRANSPORTEUR GAUFRETTES", "reg_nom": "TRANSPORTEUR GAUFRETTES", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "EMF1", "reg_nom": "EMF1", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "EMF2", "reg_nom": "EMF2", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},
      {"reg_code": "EMF3", "reg_nom": "EMF3", "reg_2016_code": "GAUFRETTE","uap_code": "UAP1"},


      /**TPJ*/
      {"reg_code": "BATTEUSE MADELEINE1", "reg_nom": "BATTEUSE MADELEINE1", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "BATTEUSE MADELEINE2", "reg_nom": "BATTEUSE MADELEINE2", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "BATTEUSE COOKIES1", "reg_nom": "BATTEUSE COOKIES1", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "BATTEUSE COOKIES2", "reg_nom": "BATTEUSE COOKIES2", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "CAKE FORMING1", "reg_nom": "CAKE FORMING1", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "CAKE FORMING2", "reg_nom": "CAKE FORMING2", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "FACONNAGE COOKIES", "reg_nom": "FACONNAGE COOKIES", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "FOUR GM", "reg_nom": "FOUR GM", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "FOUR CAPLAIN", "reg_nom": "FOUR CAPLAIN", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "TUNNEL UV", "reg_nom": "TUNNEL UV", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "TRANSPORT BARQUETTE", "reg_nom": "TRANSPORT BARQUETTE", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "RETOUR BARQUETTE", "reg_nom": "RETOUR BARQUETTE", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "LT250", "reg_nom": "LT250", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "BAOPACK1 TPJ", "reg_nom": "BAOPACK1 TPJ", "reg_2016_code": "TPJ","uap_code": "UAP1"},
      {"reg_code": "BAOPACK2 TPJ", "reg_nom": "BAOPACK2 TPJ", "reg_2016_code": "TPJ","uap_code": "UAP1"},


            /**AUXILIAIRE*/
      {"reg_code": "FONDOIR1", "reg_nom": "FONDOIR1", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "FONDOIR2", "reg_nom": "FONDOIR2", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "BALL MILL1", "reg_nom": "BALL MILL1", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "BALL MILL2", "reg_nom": "BALL MILL2", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "BALL MILL3", "reg_nom": "BALL MILL3", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "BATTEUSE AUX1", "reg_nom": "BATTEUSE AUX1", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "BATTEUSE AUX2", "reg_nom": "BATTEUSE AUX2", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "TANK CHOCO1", "reg_nom": "TANK CHOCO1", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "TANK CHOCO2", "reg_nom": "TANK CHOCO2", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "FOURREUSE SJP600", "reg_nom": "FOURREUSE SJP600", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "FOURREUSE NEWS", "reg_nom": "FOURREUSE NEWS", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ENROBEUSE SJP900", "reg_nom": "ENROBEUSE SJP900", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ENROBEUSE SJP600", "reg_nom": "ENROBEUSE SJP600", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ENROBEUSE NEWS", "reg_nom": "ENROBEUSE NEWS", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "TUNNEL SJP900", "reg_nom": "TUNNEL SJP900", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "TUNNEL SJP600", "reg_nom": "TUNNEL SJP600", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "TUNNEL NEWS", "reg_nom": "TUNNEL NEWS", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ZP500E", "reg_nom": "ZP500E", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ZP500F", "reg_nom": "ZP500F", "reg_2016_code": "ENROBE","uap_code": "UAP1"},
      {"reg_code": "ZP500G", "reg_nom": "ZP500G", "reg_2016_code": "ENROBE","uap_code": "UAP1"},


            /**LASER3*/
      {"reg_code": "PETRIN L3", "reg_nom": "PETRIN L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE APINOX", "reg_nom": "ARMOIRE ELECTRIQUE APINOX", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "CUVE CHARIOT APINOX", "reg_nom": "CUVE CHARIOT APINOX", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "PRELAMINOIR L3", "reg_nom": "PRELAMINOIR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "CALIBREUR L3", "reg_nom": "CALIBREUR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE LAMINOIR L3", "reg_nom": "ARMOIRE ELECTRIQUE LAMINOIR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "DETENTE L3", "reg_nom": "DETENTE L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "DECOUPE L3", "reg_nom": "DECOUPE L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "DETACHE PRODUIT L3", "reg_nom": "DETACHE PRODUIT L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "PONT DE LIVRAISON L3", "reg_nom": "PONT DE LIVRAISON L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ENTREE FOUR L3", "reg_nom": "ENTREE FOUR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ALIMENTATION SABLE", "reg_nom": "ALIMENTATION SABLE", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "RETOUR DENTELLE TRANSVERSAL L3", "reg_nom": "RETOUR DENTELLE TRANSVERSAL L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "RETOUR DENTELLE SUPERIEUR L3", "reg_nom": "RETOUR DENTELLE SUPERIEUR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "PRELEVEMENT RETAILLE", "reg_nom": "PRELEVEMENT RETAILLE", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE FOUR L3", "reg_nom": "ARMOIRE ELECTRIQUE FOUR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "FOUR L3", "reg_nom": "FOUR L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "TAKE OFF", "reg_nom": "TAKE OFF", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ALTERNATIF", "reg_nom": "ALTERNATIF", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "DECANTEUR HUILE L3", "reg_nom": "DECANTEUR HUILE L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "STACKER L3", "reg_nom": "STACKER L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "BANC DE REFROID L3", "reg_nom": "BANC DE REFROID L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE L3", "reg_nom": "ARMOIRE ELECTRIQUE L3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "BETAPACK1", "reg_nom": "BETAPACK1", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "BETAPACK2", "reg_nom": "BETAPACK2", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "BAOPACK3", "reg_nom": "BAOPACK3", "reg_2016_code": "LASER3","uap_code": "UAP1"},
      {"reg_code": "BAOPACK4", "reg_nom": "BAOPACK4", "reg_2016_code": "LASER3","uap_code": "UAP1"},


      /**LASER2*/
      {"reg_code": "PETRIN L2", "reg_nom": "PETRIN L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECTRIQUE PETRIN L2", "reg_nom": "ARMOIRE ELECTRIQUE PETRIN L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "DETECTEUR DE METAUX PETRIN L2", "reg_nom": "DETECTEUR DE METAUX PETRIN L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "DETECTEUR DE METAUX L2", "reg_nom": "DETECTEUR DE METAUX L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "CUVE BASCULE L2", "reg_nom": "CUVE BASCULE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "CHARIOT HAUT L2", "reg_nom": "CHARIOT HAUT L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "CHARIOT BAS L2", "reg_nom": "CHARIOT BAS L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "LAMINOIR A TROIS CYLINDRE L2", "reg_nom": "LAMINOIR A TROIS CYLINDRE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "SORTIE TROIS CYLINDRES L2", "reg_nom": "SORTIE TROIS CYLINDRES L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      //{"reg_code": "PRELAMINOIR L2", "reg_nom": "PRELAMINOIR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "FEUILLETEUSE", "reg_nom": "FEUILLETEUSE", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "SORTIE FEUILLETEUSE", "reg_nom": "SORTIE FEUILLETEUSE", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "1ER LAMINOIR L2", "reg_nom": "1ER LAMINOIR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "2E LAMINOIR L2", "reg_nom": "2E LAMINOIR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "CALIBREUR L2", "reg_nom": "CALIBREUR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELECLAMINOIR L2", "reg_nom": "ARMOIRE ELECLAMINOIR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "BYPASS", "reg_nom": "BYPASS", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "DECOUPE L2", "reg_nom": "DECOUPE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "SUCREUSE L2", "reg_nom": "SUCREUSE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "PONT DE LIVRAISON L2", "reg_nom": "PONT DE LIVRAISON L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "RETOUR DENTELLE L2", "reg_nom": "RETOUR DENTELLE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "RETOUR DENTELLE TRANSVERSAL L2", "reg_nom": "RETOUR DENTELLE TRANSVERSAL L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "RETOUR ROGNURE L3", "reg_nom": "RETOUR ROGNURE L3", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "TRANSPORTEUR PATE SABLE", "reg_nom": "TRANSPORTEUR PATE SABLE", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "TRANSPORTEUR TRANSV SABLE", "reg_nom": "TRANSPORTEUR TRANSV SABLE", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "SORTIE DECOUPE", "reg_nom": "SORTIE DECOUPE", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELEC FOUR L2", "reg_nom": "ARMOIRE ELEC FOUR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "FOUR L2", "reg_nom": "FOUR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "SORTIE FOUR L2", "reg_nom": "SORTIE FOUR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "HUILE L2", "reg_nom": "HUILE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "DECANTEUR L2", "reg_nom": "DECANTEUR L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "BANC DE REFROID L2", "reg_nom": "BANC DE REFROID L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "HUILEUSE L2", "reg_nom": "HUILEUSE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE HUILEUSE L2", "reg_nom": "ARMOIRE HUILEUSE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "DECANTEUR HUILE L2", "reg_nom": "DECANTEUR HUILE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "STACKER L2", "reg_nom": "STACKER L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "RECOLTE L2", "reg_nom": "RECOLTE L2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "TRANSFERT DECHETS", "reg_nom": "TRANSFERT DECHETS", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA1", "reg_nom": "ULMA1", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA2", "reg_nom": "ULMA2", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA3", "reg_nom": "ULMA3", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA4", "reg_nom": "ULMA4", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA5", "reg_nom": "ULMA5", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA6", "reg_nom": "ULMA6", "reg_2016_code": "LASER2","uap_code": "UAP1"},
      {"reg_code": "ULMA7", "reg_nom": "ULMA7", "reg_2016_code": "LASER2","uap_code": "UAP1"},


      /**LASER1*/
      {"reg_code": "PETRIN L1", "reg_nom": "TRANSFERT PATE", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "TRANSFERT PATE", "reg_nom": "GUILLOTINE", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "GUILLOTINE", "reg_nom": "DETECTEUR DE METAUX L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DETECTEUR DE METAUX L1", "reg_nom": "TRANSPORTEUR PATE", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "TRANSPORTEUR PATE", "reg_nom": "RETRACTILE", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RETRACTILE", "reg_nom": "ARMOIRE ELEC PETRIN L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELEC PETRIN L1", "reg_nom": "ARMOIRE ELEC LAMINOIR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELEC LAMINOIR L1", "reg_nom": "PRELAMINOIR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "PRELAMINOIR L1", "reg_nom": "1ER LAMINOIR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "1ER LAMINOIR L1", "reg_nom": "2E LAMINOIR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "2E LAMINOIR L1", "reg_nom": "CALIBREUR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "CALIBREUR L1", "reg_nom": "DETENTE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DETENTE L1", "reg_nom": "DECOUPE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DECOUPE L1", "reg_nom": "DETACHE PRODUIT L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DETACHE PRODUIT L1", "reg_nom": "DETACHE PRODUIT L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "SUCREUSE L1", "reg_nom": "SUCREUSE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "PONT DE LIVRAISON L1", "reg_nom": "PONT DE LIVRAISON L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RETOUR DENTELLE L1", "reg_nom": "RETOUR DENTELLE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RETOUR ROGNURE L1", "reg_nom": "RETOUR ROGNURE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE ELEC FOUR L1", "reg_nom": "ARMOIRE ELEC FOUR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "FOUR L1", "reg_nom": "FOUR L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DECHARGEMENT L1", "reg_nom": "DECHARGEMENT L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ARMOIRE HUILEUSE L1", "reg_nom": "ARMOIRE HUILEUSE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "HUILEUSE L1", "reg_nom": "HUILEUSE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "DECANTEUR HUILE L1", "reg_nom": "DECANTEUR HUILE L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "BANC DE REFROIDISSEMENT L1", "reg_nom": "BANC DE REFROIDISSEMENT L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "STACKER L1", "reg_nom": "STACKER L1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RECOLTE1", "reg_nom": "RECOLTE1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RECOLTE2", "reg_nom": "RECOLTE2", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RECOLTE3", "reg_nom": "RECOLTE3", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA9", "reg_nom": "ULMA9", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA10", "reg_nom": "ULMA10", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA11", "reg_nom": "ULMA11", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA12", "reg_nom": "ULMA12", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA13", "reg_nom": "ULMA13", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA14", "reg_nom": "ULMA14", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "ULMA15", "reg_nom": "ULMA15", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG1", "reg_nom": "RICHENG1", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG2", "reg_nom": "RICHENG2", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG3", "reg_nom": "RICHENG3", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG4", "reg_nom": "RICHENG4", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG5", "reg_nom": "RICHENG5", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG6", "reg_nom": "RICHENG6", "reg_2016_code": "LASER1","uap_code": "UAP1"},
      {"reg_code": "RICHENG7", "reg_nom": "RICHENG7", "reg_2016_code": "LASER1","uap_code": "UAP1"},


      /**BBD*/
      {"reg_code":"CUVE CHAUFFAGE GLUCCOSE", "reg_nom": "CUVE CHAUFFAGE GLUCCOSE", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"SL2000", "reg_nom": "SL2000", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"CKU", "reg_nom": "CKU", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"ME70", "reg_nom": "ME70", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"IM70", "reg_nom": "IM70", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"EIM70", "reg_nom": "EIM70", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"LAM70", "reg_nom": "LAM70", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"ROULEUSE BBD", "reg_nom": "ROULEUSE BBD", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FILEUSE BBD", "reg_nom": "FILEUSE BBD", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"MOULEUSE", "reg_nom": "MOULEUSE", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TAPIS OSCILLANT", "reg_nom": "TAPIS OSCILLANT", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TUNNEL APPOLLO", "reg_nom": "TUNNEL APPOLLO", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TAPIS INCLINE", "reg_nom": "TAPIS INCLINE", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TAMISEUR", "reg_nom": "TAMISEUR", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"BFK2000 BBD", "reg_nom": "BFK2000 BBD", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"E77", "reg_nom": "E77", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB1", "reg_nom": "FNDB1", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB2", "reg_nom": "FNDB2", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB3", "reg_nom": "FNDB3", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB4", "reg_nom": "FNDB4", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB5", "reg_nom": "FNDB5", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB6", "reg_nom": "FNDB6", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB7", "reg_nom": "FNDB7", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB8", "reg_nom": "FNDB8", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDB10", "reg_nom": "FNDB10", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK1", "reg_nom": "FNDK1", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK2", "reg_nom": "FNDK2", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK3", "reg_nom": "FNDK3", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK4", "reg_nom": "FNDK4", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK5", "reg_nom": "FNDK5", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK6", "reg_nom": "FNDK6", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK7", "reg_nom": "FNDK7", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK8", "reg_nom": "FNDK8", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK9", "reg_nom": "FNDK9", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK10", "reg_nom": "FNDK10", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK11", "reg_nom": "FNDK11", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK12", "reg_nom": "FNDK12", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK13", "reg_nom": "FNDK13", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK14", "reg_nom": "FNDK14", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK15", "reg_nom": "FNDK15", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK16", "reg_nom": "FNDK16", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK17", "reg_nom": "FNDK17", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK18", "reg_nom": "FNDK18", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK19", "reg_nom": "FNDK19", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"FNDK20", "reg_nom": "FNDK20", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TNA1", "reg_nom": "TNA1", "reg_2016_code": "BBD","uap_code": "UAP2"},
      {"reg_code":"TNA2", "reg_nom": "TNA2", "reg_2016_code": "BBD","uap_code": "UAP2"},


      /**BBM*/
      {"reg_code":"CUISEUR", "reg_nom": "CUISEUR", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"TAMBOUR", "reg_nom": "TAMBOUR", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"ETIREUSE", "reg_nom": "ETIREUSE", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"TABLE", "reg_nom": "TABLE", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"ROULEUSE BBM", "reg_nom": "ROULEUSE BBM", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"FILEUSE BBM", "reg_nom": "FILEUSE BBM", "reg_2016_code": "BBM","uap_code": "UAP2"},
      {"reg_code":"BZ1000", "reg_nom": "BZ1000", "reg_2016_code": "BBM","uap_code": "UAP2"},


      /**GUM*/
      {"reg_code":"MALAXEUR PM", "reg_nom": "MALAXEUR PM", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"MALAXEUR GM", "reg_nom": "MALAXEUR GM", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"EXTRUDEUR", "reg_nom": "EXTRUDEUR", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"TUNNEL GUM", "reg_nom": "TUNNEL GUM", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"SK600-1", "reg_nom": "SK600-1", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"SK600-2", "reg_nom": "SK600-2", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"SK600-3", "reg_nom": "SK600-3", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"SK600-4", "reg_nom": "SK600-4", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"BOSCH", "reg_nom": "BOSCH", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"BFK2000 GUM", "reg_nom": "BFK2000 GUM", "reg_2016_code": "GUM","uap_code": "UAP2"},
      {"reg_code":"BAOPACK GUM", "reg_nom": "BAOPACK GUM", "reg_2016_code": "GUM","uap_code": "UAP2"},



      /**CHOCO*/
      {"reg_code":"FONDOIR1", "reg_nom": "FONDOIR1", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"FONDOIR2", "reg_nom": "FONDOIR2", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BALL MILL1", "reg_nom": "BALL MILL1", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BALL MILL2", "reg_nom": "BALL MILL2", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BALL MILL3", "reg_nom": "BALL MILL3", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BALL MILL4", "reg_nom": "BALL MILL4", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"TANK MCB", "reg_nom": "TANK MCB", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"TANK INOX", "reg_nom": "TANK INOX", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"TANK MCN", "reg_nom": "TANK MCN", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"CHAUFFE MOULE BETEC", "reg_nom": "CHAUFFE MOULE BETEC", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"ROUE BETEC", "reg_nom": "ROUE BETEC", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"TAPOTEUSE BETEC", "reg_nom": "TAPOTEUSE BETEC", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"DEPOSITEUR", "reg_nom": "DEPOSITEUR", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"TUNNEL ELECTRON", "reg_nom": "TUNNEL ELECTRON", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"RETOUR MOULE1", "reg_nom": "RETOUR MOULE1", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"RETOUR MOULE2", "reg_nom": "RETOUR MOULE2", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"RETOUR MOULE3", "reg_nom": "RETOUR MOULE3", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"JH1221", "reg_nom": "JH1221", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"JH1230", "reg_nom": "JH1230", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"CONV SORTIE PRODUIT", "reg_nom": "CONV SORTIE PRODUIT", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"SOUDEUSE CONTINUE", "reg_nom": "SOUDEUSE CONTINUE", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BAC CHAUFFANT1", "reg_nom": "BAC CHAUFFANT1", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BAC CHAUFFANT2", "reg_nom": "BAC CHAUFFANT2", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BOLO PUSH1", "reg_nom": "BOLO PUSH1", "reg_2016_code": "CHOCO","uap_code": "UAP2"},
      {"reg_code":"BOLO PUSH2", "reg_nom": "BOLO PUSH2", "reg_2016_code": "CHOCO","uap_code": "UAP2"},


      /*PELLETS*/
      {"reg_code":"MELANGEUR GM", "reg_nom": "MELANGEUR GM", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"ELEVATEUR VIS GM", "reg_nom": "ELEVATEUR VIS GM", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"EXTRUDEUR DAYI A 1 VIS", "reg_nom": "EXTRUDEUR DAYI A 1 VIS", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"EXTRUDEUR DAYI A 2 VIS", "reg_nom": "EXTRUDEUR DAYI A 2 VIS", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"ROULEAU TENDEUR ET REFROIDISSEMENT", "reg_nom": "ROULEAU TENDEUR ET REFROIDISSEMENT", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"DECOUPE GM", "reg_nom": "DECOUPE GM", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"SORTIE DECOUPE", "reg_nom": "SORTIE DECOUPE", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAPIS DE TRANSFERT", "reg_nom": "TAPIS DE TRANSFERT", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"CONVOYEUR ENTREE TAMBOUR CRIBLEUR", "reg_nom": "CONVOYEUR ENTREE TAMBOUR CRIBLEUR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAMBOUR CRIBLEUR", "reg_nom": "TAMBOUR CRIBLEUR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAPIS ELEVATEUR PRODUIT", "reg_nom": "TAPIS ELEVATEUR PRODUIT", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"VIBRATEUR ALIMENTATION PRE SECHOIR", "reg_nom": "VIBRATEUR ALIMENTATION PRE SECHOIR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"SORTIE PRE SECHOIR", "reg_nom": "SORTIE PRE SECHOIR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"ELEVATEUR PRODUIT", "reg_nom": "ELEVATEUR PRODUIT", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAPIS DE DISPERTION", "reg_nom": "TAPIS DE DISPERTION", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"SECHOIR", "reg_nom": "SECHOIR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAPIS CONVOYEUR ", "reg_nom": "TAPIS CONVOYEUR ", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"ENTREE TAMBOUR", "reg_nom": "ENTREE TAMBOUR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAMBOUR SEPARATEUR", "reg_nom": "TAMBOUR SEPARATEUR", "reg_2016_code": "PELLETS","uap_code": "UAP3"},
      {"reg_code":"TAPIS TRIAGE", "reg_nom": "TAPIS TRIAGE", "reg_2016_code": "PELLETS","uap_code": "UAP3"},



      /*COEX*/
      {"reg_code":"MELANGEUR PM", "reg_nom": "MELANGEUR PM", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"ELEVATEUR VIS PM", "reg_nom": "ELEVATEUR VIS PM", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"EXTRUDEUR", "reg_nom": "EXTRUDEUR", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"SOUFFLEUSE", "reg_nom": "SOUFFLEUSE", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"SECHOIR", "reg_nom": "SECHOIR", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"COATING PAN1", "reg_nom": "COATING PAN1", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"COATING PAN2", "reg_nom": "COATING PAN2", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"COATING PAN3", "reg_nom": "COATING PAN3", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"COATING PAN4", "reg_nom": "COATING PAN4", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"HUILEUSE", "reg_nom": "HUILEUSE", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"BAOPACK PM1", "reg_nom": "BAOPACK PM1", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"BAOPACK PM2", "reg_nom": "BAOPACK PM2", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"BAOPACK PM3", "reg_nom": "BAOPACK PM3", "reg_2016_code": "COEX","uap_code": "UAP3"},
      {"reg_code":"BAOPACK PM4", "reg_nom": "BAOPACK PM4", "reg_2016_code": "COEX","uap_code": "UAP3"},


      /*CURL*/
      {"reg_code":"MELANGEUR PM", "reg_nom": "MELANGEUR PM", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"ELEVATEUR VIS PM", "reg_nom": "ELEVATEUR VIS PM", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"EXTRUDEUR", "reg_nom": "EXTRUDEUR", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"DECOUPEUSE", "reg_nom": "DECOUPEUSE", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"SOUFLEUSE", "reg_nom": "SOUFLEUSE", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"SECHOIR1", "reg_nom": "SECHOIR1", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"SECHOIR2", "reg_nom": "SECHOIR2", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"HUILEUSE", "reg_nom": "HUILEUSE", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"TAPIS ENTREE TAMBOUR1", "reg_nom": "TAPIS ENTREE TAMBOUR1", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"TAPIS ENTREE TAMBOUR2", "reg_nom": "TAPIS ENTREE TAMBOUR2", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"TAPIS ENTREE TAMBOUR3", "reg_nom": "TAPIS ENTREE TAMBOUR3", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"TAPIS ENTREE TAMBOUR4", "reg_nom": "TAPIS ENTREE TAMBOUR4", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"TAMBOUR AROMATISEUR", "reg_nom": "TAMBOUR AROMATISEUR", "reg_2016_code": "CURL","uap_code": "UAP3"},
      {"reg_code":"BAOPACK ZZ", "reg_nom": "BAOPACK ZZ", "reg_2016_code": "CURL","uap_code": "UAP3"},


      /*FRITURE*/
      {"reg_code":"FOINDOIR", "reg_nom": "FOINDOIR", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"TANK HUILE APPOINT", "reg_nom": "TANK HUILE APPOINT", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"TANK HUILE FILTRE", "reg_nom": "TANK HUILE FILTRE", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"VIBRATEUR N°1", "reg_nom": "VIBRATEUR N°1", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"VIBRATEUR N°2", "reg_nom": "VIBRATEUR N°2", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"FRITEUSE GM", "reg_nom": "FRITEUSE GM", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"TAPIS ENTREE TAMBOUR", "reg_nom": "TAPIS ENTREE TAMBOUR", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"TAMBOUR AROMATISEUR", "reg_nom": "TAMBOUR AROMATISEUR", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"OIKOS PM1", "reg_nom": "OIKOS PM1", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"OIKOS PM2", "reg_nom": "OIKOS PM2", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"OIKOS GM", "reg_nom": "OIKOS GM", "reg_2016_code": "FRITURE","uap_code": "UAP3"},
      {"reg_code":"BAOPACK", "reg_nom": "BAOPACK", "reg_2016_code": "FRITURE","uap_code": "UAP3"},


      /*TUBZ*/
      {"reg_code":"MELANGEUR", "reg_nom": "MELANGEUR", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"PRE CONDITIONNEUR", "reg_nom": "PRE CONDITIONNEUR", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"EXTRUDEUR LT", "reg_nom": "EXTRUDEUR LT", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"SOUFFLEUSE1", "reg_nom": "SOUFFLEUSE1", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"SOUFFLEUSE2", "reg_nom": "SOUFFLEUSE2", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"SECHOIR", "reg_nom": "SECHOIR", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"COATING PAN1", "reg_nom": "COATING PAN1", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"COATING PAN2", "reg_nom": "COATING PAN2", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"COATING PAN3", "reg_nom": "COATING PAN3", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"COATING PAN4", "reg_nom": "COATING PAN4", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"ATLAS", "reg_nom": "ATLAS", "reg_2016_code": "TUBZ","uap_code": "UAP3"},
      {"reg_code":"BOSCH", "reg_nom": "BOSCH", "reg_2016_code": "TUBZ","uap_code": "UAP3"},


      /*AUXILIAIRE GENERAUX*/
      {"reg_code":"COMPRESSEUR ASD35", "reg_nom": "COMPRESSEUR ASD35", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"COMPRESSEUR SK 26", "reg_nom": "COMPRESSEUR SK 26", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"COMPRESSEUR PM", "reg_nom": "COMPRESSEUR PM", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"GENERATEUR AZOTE GM", "reg_nom": "GENERATEUR AZOTE GM", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"GENERATEUR AZOTE PARKER", "reg_nom": "GENERATEUR AZOTE PARKER", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"FILTRE SECHEUR", "reg_nom": "FILTRE SECHEUR", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"SURPRESSEUR1", "reg_nom": "SURPRESSEUR1", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},
      {"reg_code":"SURPRESSEUR2", "reg_nom": "SURPRESSEUR2", "reg_2016_code": "AUXGEN","uap_code": "UAP3"},


      /*STEP*/
      {"reg_code":"POMPE D'ALIMENTATION CITERNE EAU", "reg_nom": "POMPE D'ALIMENTATION CITERNE EAU", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"CUVE DE TRAITEMENT1", "reg_nom": "CUVE DE TRAITEMENT1", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"CUVE DE TRAITEMENT2", "reg_nom": "CUVE DE TRAITEMENT2", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"BAC A BOUES", "reg_nom": "BAC A BOUES", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"FILTRE A SABLE", "reg_nom": "FILTRE A SABLE", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"CUVE DE STOCKAGE1", "reg_nom": "CUVE DE STOCKAGE1", "reg_2016_code": "STEP","uap_code": "UAP3"},
      {"reg_code":"CUVE DE STOCKAGE2", "reg_nom": "CUVE DE STOCKAGE2", "reg_2016_code": "STEP","uap_code": "UAP3"},


      /*BROYEUR*/
      {"reg_code":"BROYEUR TSP", "reg_nom": "BROYEUR TSP", "reg_2016_code": "BROYEUR","uap_code": "UAP3"},
      {"reg_code":"BROYEUR DECHETS", "reg_nom": "BROYEUR DECHETS", "reg_2016_code": "BROYEUR","uap_code": "UAP3"},



      /**SG ELEC*/
      {"reg_code":"ASPIRATEUR CYCLONE", "reg_nom": "ASPIRATEUR CYCLONE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BASSIN CNERITE", "reg_nom": "BASSIN CNERITE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR ALPINE", "reg_nom": "BROYEUR ALPINE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR HAAS", "reg_nom": "BROYEUR HAAS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR INDIEN", "reg_nom": "BROYEUR INDIEN", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR PECK MIX BP N°657334", "reg_nom": "BROYEUR PECK MIX BP N°657334", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR PM", "reg_nom": "BROYEUR PM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"BROYEUR ROBOT CUTT P406", "reg_nom": "BROYEUR ROBOT CUTT P406", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI ARMOIRE ELECTRIQUE ", "reg_nom": "CEPI ARMOIRE ELECTRIQUE ", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI DEPART IMAF", "reg_nom": "CEPI DEPART IMAF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI DEPART LASER 2", "reg_nom": "CEPI DEPART LASER 2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI SILO SUCRE", "reg_nom": "CEPI SILO SUCRE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI SILO SUCRE B&B", "reg_nom": "CEPI SILO SUCRE B&B", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CEPI VIDE SAC ", "reg_nom": "CEPI VIDE SAC ", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CHAUDIERE WANSON N°2734", "reg_nom": "CHAUDIERE WANSON N°2734", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CITERNE EAU BISC 5M3", "reg_nom": "CITERNE EAU BISC 5M3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CITERNE EAU CENTRALE 10M3", "reg_nom": "CITERNE EAU CENTRALE 10M3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CITERNE EAU CONF 5M3", "reg_nom": "CITERNE EAU CONF 5M3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CITERNE EAU INOTHEC 30M3", "reg_nom": "CITERNE EAU INOTHEC 30M3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CITERNE GASOIL SOUS TERRAINE", "reg_nom": "CITERNE GASOIL SOUS TERRAINE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM ACMA 1", "reg_nom": "CLIM ACMA 1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM CONNEX", "reg_nom": "CLIM CONNEX", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM CRISTALISATION", "reg_nom": "CLIM CRISTALISATION", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM EMB CHOCO", "reg_nom": "CLIM EMB CHOCO", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM EX FOX 1", "reg_nom": "CLIM EX FOX 1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM EX MANEUR AUX ", "reg_nom": "CLIM EX MANEUR AUX ", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM Ex TNA", "reg_nom": "CLIM Ex TNA", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM FRIGABOHN 1", "reg_nom": "CLIM FRIGABOHN 1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM FRIGABOHN 2", "reg_nom": "CLIM FRIGABOHN 2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM FRIGABOHN 3", "reg_nom": "CLIM FRIGABOHN 3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM OLE POP", "reg_nom": "CLIM OLE POP", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM RIVACOLD", "reg_nom": "CLIM RIVACOLD", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SALLE ONDULEUR 80KVA LASER", "reg_nom": "CLIM SALLE ONDULEUR 80KVA LASER", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE ADM", "reg_nom": "CLIM SPLIT SALLE ADM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE LABO CQ", "reg_nom": "CLIM SPLIT SALLE LABO CQ", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE REUNION", "reg_nom": "CLIM SPLIT SALLE REUNION", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE SALTO", "reg_nom": "CLIM SPLIT SALLE SALTO", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE SERVEUR", "reg_nom": "CLIM SPLIT SALLE SERVEUR", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CLIM SPLIT SALLE TURBO", "reg_nom": "CLIM SPLIT SALLE TURBO", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"COMPACTEUR DECHET FILM", "reg_nom": "COMPACTEUR DECHET FILM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"COMPRESSEUR A PISTON", "reg_nom": "COMPRESSEUR A PISTON", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"CTA PLUMPY", "reg_nom": "CTA PLUMPY", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"DESHUMIDIFICATEUR BBD", "reg_nom": "DESHUMIDIFICATEUR BBD", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"DESHUMIDIFICATEUR CONNEXE", "reg_nom": "DESHUMIDIFICATEUR CONNEXE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"DESHUMIDIFICATEUR GUM", "reg_nom": "DESHUMIDIFICATEUR GUM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"DESHUMIDIFICATEUR ML420 FOX", "reg_nom": "DESHUMIDIFICATEUR ML420 FOX", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"DISTRIBUTION EN VAPEUR", "reg_nom": "DISTRIBUTION EN VAPEUR", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN NITROG CONNEX", "reg_nom": "GEN NITROG CONNEX", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN NITROG N°0100540+BAL SNACK", "reg_nom": "GEN NITROG N°0100540+BAL SNACK", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN NITROG NEWS R+3", "reg_nom": "GEN NITROG NEWS R+3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN NITROG OIKOS", "reg_nom": "GEN NITROG OIKOS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN D'AZOTE PLUMPY", "reg_nom": "GEN D'AZOTE PLUMPY", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"GEN HUFLUXX PLUMPY", "reg_nom": "GEN HUFLUXX PLUMPY", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR BSD62 BISC", "reg_nom": "KAESER COMPR BSD62 BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR BSD65 BISC", "reg_nom": "KAESER COMPR BSD65 BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR BSD65 NEW BISC", "reg_nom": "KAESER COMPR BSD65 NEW BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR BSD65 PLUMPY", "reg_nom": "KAESER COMPR BSD65 PLUMPY", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SK19 CONF", "reg_nom": "KAESER COMPR SK19 CONF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SK24 NACKS", "reg_nom": "KAESER COMPR SK24 NACKS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SK26 CONF", "reg_nom": "KAESER COMPR SK26 CONF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SK26 Ex BISCUIT", "reg_nom": "KAESER COMPR SK26 Ex BISCUIT", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SK26 NACKS", "reg_nom": "KAESER COMPR SK26 NACKS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER COMPR SM12 NACKS", "reg_nom": "KAESER COMPR SM12 NACKS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TC31  SK19 CONF", "reg_nom": "KAESER SECH TC31  SK19 CONF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TC31  SK24 NACKS", "reg_nom": "KAESER SECH TC31  SK24 NACKS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TC31  SK26 CONF", "reg_nom": "KAESER SECH TC31  SK26 CONF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TC31  SK26 NACKS", "reg_nom": "KAESER SECH TC31  SK26 NACKS", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TC61  SK26 EX BISC", "reg_nom": "KAESER SECH TC61  SK26 EX BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TD61 BSD62 BISC", "reg_nom": "KAESER SECH TD61 BSD62 BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TD76 BSD65 BISC", "reg_nom": "KAESER SECH TD76 BSD65 BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"KAESER SECH TD76 BSD65 PLUMPY", "reg_nom": "KAESER SECH TD76 BSD65 PLUMPY", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"ORDYVITE", "reg_nom": "ORDYVITE", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"POMPE CHAUDIERE N°1", "reg_nom": "POMPE CHAUDIERE N°1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"POMPE CHAUDIERE N°2", "reg_nom": "POMPE CHAUDIERE N°2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"POMPE PEDROLLO N°1", "reg_nom": "POMPE PEDROLLO N°1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"POMPE PEDROLLO N°2", "reg_nom": "POMPE PEDROLLO N°2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"POMPE SANITATION ", "reg_nom": "POMPE SANITATION ", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SECHE LINGE N°01", "reg_nom": "SECHE LINGE N°01", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SECHE LINGE N°02", "reg_nom": "SECHE LINGE N°02", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SURPRESSEUR A EAU AUX BISC", "reg_nom": "SURPRESSEUR A EAU AUX BISC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SURPRESSEUR A EAU BISC IMAF", "reg_nom": "SURPRESSEUR A EAU BISC IMAF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SURPRESSEUR A EAU BISC LASER", "reg_nom": "SURPRESSEUR A EAU BISC LASER", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"SURPRESSEUR A EAU CONF", "reg_nom": "SURPRESSEUR A EAU CONF", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL ELECTRON", "reg_nom": "TUNNEL ELECTRON", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL Ex COEX", "reg_nom": "TUNNEL Ex COEX", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL KKV-FOX182", "reg_nom": "TUNNEL KKV-FOX182", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL NEW GUM", "reg_nom": "TUNNEL NEW GUM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL NEW SPJ900", "reg_nom": "TUNNEL NEW SPJ900", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL NUOVA EUROMEC", "reg_nom": "TUNNEL NUOVA EUROMEC", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL OLE POP", "reg_nom": "TUNNEL OLE POP", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL SHANDONG", "reg_nom": "TUNNEL SHANDONG", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"TUNNEL WLS GUM", "reg_nom": "TUNNEL WLS GUM", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"VIDE SAC B&B", "reg_nom": "VIDE SAC B&B", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER CONF N°1", "reg_nom": "WATER CHILLER CONF N°1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER CONF N°2", "reg_nom": "WATER CHILLER CONF N°2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER LASER 1", "reg_nom": "WATER CHILLER LASER 1", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER LASER 2", "reg_nom": "WATER CHILLER LASER 2", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER LASER 3", "reg_nom": "WATER CHILLER LASER 3", "reg_2016_code": "SG","uap_code": "SG-ELEC"},
      {"reg_code":"WATER CHILLER TM FOX", "reg_nom": "WATER CHILLER TM FOX", "reg_2016_code": "SG","uap_code": "SG-ELEC"},

      {"reg_code":"DISTRIBUTION ELECTRIQUE ELEC", "reg_nom": "DISTRIBUTION ELECTRIQUE ELEC", "reg_2016_code": "ELEC","uap_code": "SG-ELEC"},
      {"reg_code":"EXTRACTEUR GM", "reg_nom": "EXTRACTEUR GM", "reg_2016_code": "ELEC","uap_code": "SG-ELEC"},
      {"reg_code":"GE CAT 1 1000", "reg_nom": "GE CAT 1 1000", "reg_2016_code": "ELEC","uap_code": "SG-ELEC"},
      {"reg_code":"GE CAT 2 1000", "reg_nom": "GE CAT 2 1000", "reg_2016_code": "ELEC","uap_code": "SG-ELEC"},
      {"reg_code":"RIDEAU D'AIR", "reg_nom": "RIDEAU D'AIR", "reg_2016_code": "ELEC","uap_code": "SG-ELEC"},


      /*atc pr*/
      {"reg_code":"FRAISEUSE", "reg_nom": "FRAISEUSE", "reg_2016_code": "ATC","uap_code": "ATC-PR"},
      {"reg_code":"PERCEUSE A COLONNE", "reg_nom": "PERCEUSE A COLONNE", "reg_2016_code": "ATC","uap_code": "ATC-PR"},
      {"reg_code":"SCIE MECANIQUE", "reg_nom": "SCIE MECANIQUE", "reg_2016_code": "ATC","uap_code": "ATC-PR"},
      {"reg_code":"TOUR GM", "reg_nom": "TOUR GM", "reg_2016_code": "ATC","uap_code": "ATC-PR"},
      {"reg_code":"TOUR PM 1", "reg_nom": "TOUR PM 1", "reg_2016_code": "ATC","uap_code": "ATC-PR"},
      {"reg_code":"TOUR PM 2", "reg_nom": "TOUR PM 2", "reg_2016_code": "ATC","uap_code": "ATC-PR"},

      {"reg_code":"GERB JUNGHEINRICH N°1", "reg_nom": "GERB JUNGHEINRICH N°1", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"GERB JUNGHEINRICH N°2", "reg_nom": "GERB JUNGHEINRICH N°2", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"GERB LIFTER L16", "reg_nom": "GERB LIFTER L16", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"GERB SEMI ELEC VALALA N°02", "reg_nom": "GERB SEMI ELEC VALALA N°02", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"GERB SEMI ELEC VALALA N°1", "reg_nom": "GERB SEMI ELEC VALALA N°1", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"MONTE CHARGE M22", "reg_nom": "MONTE CHARGE M22", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"MONTE CHARGE SUD", "reg_nom": "MONTE CHARGE SUD", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"MONTE CHARGE ZPL", "reg_nom": "MONTE CHARGE ZPL", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"PALAN GLUCOSE", "reg_nom": "PALAN GLUCOSE", "reg_2016_code": "PR","uap_code": "ATC-PR"},
      {"reg_code":"PALAN MOULE IMAF", "reg_nom": "PALAN MOULE IMAF", "reg_2016_code": "PR","uap_code": "ATC-PR"},


      /*hs*/
      {"reg_code":"GERB ELEC HANGCHA 1", "reg_nom": "GERB ELEC HANGCHA 1", "reg_2016_code": "HS","uap_code": "HORS-SITE"},
      {"reg_code":"GERB ELEC HANGCHA 2", "reg_nom": "GERB ELEC HANGCHA 2", "reg_2016_code": "HS","uap_code": "HORS-SITE"},
      {"reg_code":"KAESER COMPR ASD35 JBU02", "reg_nom": "KAESER COMPR ASD35 JBU02", "reg_2016_code": "HS","uap_code": "HORS-SITE"},
      {"reg_code":"SURPRESSEUR A EAU", "reg_nom": "SURPRESSEUR A EAU", "reg_2016_code": "HS","uap_code": "HORS-SITE"},



      /**PLUMPY*/
      {"reg_code":"VIDE SAC", "reg_nom": "VIDE SAC", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"COUPE PAINS", "reg_nom": "COUPE PAINS", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"10C01 FONDOIR 500L", "reg_nom": "10C01 FONDOIR 500L", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"10C02 CUVE NEP", "reg_nom": "10C02 CUVE NEP", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20M01 CUVE PRE-MELANGEUR ", "reg_nom": "20M01 CUVE PRE-MELANGEUR ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20M02 PRE-MELANGEUR ", "reg_nom": "20M02 PRE-MELANGEUR ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20B01 BROYEUR1", "reg_nom": "20B01 BROYEUR1", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20C01 CUVE SORTIE PREMIX", "reg_nom": "20C01 CUVE SORTIE PREMIX", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20B02 BROYEUR2", "reg_nom": "20B02 BROYEUR2", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20C02 CUVE POST-THERMISATION ", "reg_nom": "20C02 CUVE POST-THERMISATION ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20P01 POMPE SPX", "reg_nom": "20P01 POMPE SPX", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"20E04 ECHANGEUR A PLAQUES ", "reg_nom": "20E04 ECHANGEUR A PLAQUES ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30C01 CUVE DE PESAGE ", "reg_nom": "30C01 CUVE DE PESAGE ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30M01 MELANGEUR", "reg_nom": "30M01 MELANGEUR", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30B01 BROYEUR", "reg_nom": "30B01 BROYEUR", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30C02 CUVE SORTIE MELANG", "reg_nom": "30C02 CUVE SORTIE MELANG", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30C03 CUVE TAMPON ", "reg_nom": "30C03 CUVE TAMPON ", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30P01 POMPE SPX", "reg_nom": "30P01 POMPE SPX", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30P02 POMPE SPX", "reg_nom": "30P02 POMPE SPX", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"30F01 FILTRE", "reg_nom": "30F01 FILTRE", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"ARMOIRE IHM", "reg_nom": "ARMOIRE IHM", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"DOSEUSE A", "reg_nom": "DOSEUSE A", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"IMANPACKA", "reg_nom": "IMANPACKA", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"DOSEUSE B", "reg_nom": "DOSEUSE B", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"IMANPACK B", "reg_nom": "IMANPACK B", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"DOSEUSE C", "reg_nom": "DOSEUSE C", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"IMANPACK C", "reg_nom": "IMANPACK C", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"DOSEUSE D", "reg_nom": "DOSEUSE D", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"IMANPACK D", "reg_nom": "IMANPACK D", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"EMBALLEUSE LNS E", "reg_nom": "EMBALLEUSE LNS E", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"EMBALLEUSE LNS F", "reg_nom": "EMBALLEUSE LNS F", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE A", "reg_nom": "CONV MOTORISE A", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE B", "reg_nom": "CONV MOTORISE B", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE C", "reg_nom": "CONV MOTORISE C", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE D", "reg_nom": "CONV MOTORISE D", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE E", "reg_nom": "CONV MOTORISE E", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE F", "reg_nom": "CONV MOTORISE F", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV MOTORISE REPARTITEUR", "reg_nom": "CONV MOTORISE REPARTITEUR", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV INTERMEDIAIRE", "reg_nom": "CONV INTERMEDIAIRE", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV DDM", "reg_nom": "CONV DDM", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV COMPTEUR PRODUIT", "reg_nom": "CONV COMPTEUR PRODUIT", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV CARTON VIDE", "reg_nom": "CONV CARTON VIDE", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV TRANSF CARTON 6600", "reg_nom": "CONV TRANSF CARTON 6600", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CONV TRANSF CARTON 2050", "reg_nom": "CONV TRANSF CARTON 2050", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"DETECTEUR DE METAUX", "reg_nom": "DETECTEUR DE METAUX", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"GENERATEUR AZOTE PLUMPY", "reg_nom": "GENERATEUR AZOTE PLUMPY", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"CHAUDIERE", "reg_nom": "CHAUDIERE", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},
      {"reg_code":"GROUPE CTA", "reg_nom": "GROUPE CTA", "reg_2016_code": "PLUMPY","uap_code": "UAP4"},

    
    ];
    
    // tri dans l'ordre alpha pour new r�gion
    tbl_region_2016.sort(function(a, b){
      if( a.reg_2016_nom < b.reg_2016_nom)
       return( -1);
      if( a.reg_2016_nom > b.reg_2016_nom)
       return( 1);
      return( 0);    
    });
      
        
        
        </script>      
      
       <script>
        
        /**
    * Fonction de r�cup�ration des données correspondant au crit�re de recherche
    * @param   {String} condition - Chaine indiquant la condition �  remplir
    * @param   {Array}  table - Tableau contenant les donn�es �  extraire
    * @returns {Array}  result - Tableau contenant les donn�es extraites
    */
    function getDataFromTable( condition, table) {
      // r�cupération de la clé et de la valeur
      var cde = condition.replace(/\s/g, '').split('='),
        key = cde[0],
        value = cde[1],
        result = [];
      
      // retour direct si *
      if (condition === '*') {
      return table.slice();
      }
      // retourne les éléments r�pondant �  la condition
      result = table.filter( function(obj){
         return obj[key] === value;
      });
      return result;
    }
    /**
    * Affichage du nombre d'<option> pr�sentes dans le <select>
    * @param {Object} obj - <select> parent
    * @param {Number} nb - nombre �  afficher
    */
    function setNombre( obj, nb){
      var oElem = obj.parentNode.querySelector('.nombre');
      if( oElem){
      oElem.innerHTML = nb ? '(' +nb +')' :'';
      }
    }
    /**
    * Fonction d'ajout des <option> �  un <select>
    * @param   {String} id_select - ID du <select> �  mettre �  jour
    * @param   {Array}  liste - Tableau contenant les données �  ajouter
    * @param   {String} valeur - Champ pris en compte pour la value de l'<option>
    * @param   {String} texte - Champ pris en compte pour le texte affich� de l'<option>
    * @returns {String} Valeur s�lectionnée du <select> pour chainage
    */
    function updateSelect( id_select, liste, valeur, texte){
      var oOption,
        oSelect = document.getElementById( id_select),
        i, nb = liste.length;
      // vide le select
      oSelect.options.length = 0;
      // d�sactive si aucune option disponible
      oSelect.disabled = nb ? false : true;
      // affiche info nombre options, facultatif
      setNombre( oSelect, nb);
      // ajoute 1st option
      if( nb){
      oSelect.add( new Option( 'Choisir', ''));
      // focus sur le select
      oSelect.focus();
      }
      // cr�ation des options d'apr�s la liste
      for (i = 0; i < nb; i += 1) {
      // création option
      oOption = new Option( liste[i][texte], liste[i][valeur]);
      // ajout de l'option en fin
      oSelect.add( oOption);
      }
      // si une seule option on la s�lectionne
      oSelect.selectedIndex = nb === 1 ? 1 : 0;
      // on retourne la valeur pour le select suivant
      return oSelect.value;
    }
    /**
    * fonction de chainage des <select>
    * @param {String|Object} ID du <select> �  traiter ou le <select> lui-m�me
    */
    function chainSelect( param){
      // affectation par d�faut
      param = param || 'init';
      var liste,
        id     = param.id || param,
        valeur = param.value || '';
        
      // test �  faire pour r�cup�ration de la value
      if( typeof id === 'string'){
       param = document.getElementById( id);
       valeur = param ? param.value : '';
       }
     
       switch (id){
      case 'init':
        // r�cup. des donn�es
        liste = getDataFromTable( '*', tbl_uap);
        // mise �  jour du select
        valeur = updateSelect( 'uap', liste, 'uap_code', 'uap_nom');
        // chainage sur le select li�
        chainSelect('uap');
        break;
      case 'uap':
        // r�cup. des donn�es
        liste = getDataFromTable( 'uap_code=' +valeur, tbl_region_2016);
        liste1 = getDataFromTable( 'uap_code=' +valeur, tbl_rm_uap);
        // mise �  jour du select
        valeur = updateSelect( 'services', liste, 'reg_2016_code', 'reg_2016_nom');
        valeur1 = updateSelect( 'responsable', liste1, 'rm_code', 'rm_nom');
        // chainage sur le select li�
        chainSelect('services');
        chainSelect('responsable');
        break;
      case 'services':
        // r�cup. des donn�es
        liste = getDataFromTable( 'reg_2016_code=' +valeur, tbl_Linge_prod);
        // mise �  jour du select
        valeur = updateSelect( 'Linge_prod', liste, 'reg_code', 'reg_nom');
        // chainage sur le select li�
        chainSelect('Linge_prod');
        break;
      case 'Linge_prod':
        // affichage final
        document.getElementById('prefecture').value = valeur;
        break;
      }
    }
    // Initialisation après chargement du DOM
    document.addEventListener("DOMContentLoaded", function(event) {
      var oSelects = document.querySelectorAll('#liste select'),
        i, nb = oSelects.length;
      // affectation de la fonction sur le onchange
      for( i = 0; i < nb; i += 1) {
      oSelects[i].onchange = function() {
        chainSelect(this);
        };
      }
      // init du 1st select
      if( nb){
      chainSelect('init');
      }
    });
        
        </script>         

  <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="2">Lalandy Andriamanga - Méthode Technique - 2023</font>


  </body>


  </html>