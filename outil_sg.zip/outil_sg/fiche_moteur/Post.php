<?php

$bdd = mysqli_connect("localhost","root","","fiche_moteur");

if (!$bdd){
  die('Connection Failed'. mysqli_connect_error());
}
 ?>