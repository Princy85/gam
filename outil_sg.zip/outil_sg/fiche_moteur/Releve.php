<!DOCTYPE html>
<html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>RELEVEE PARAMETRE GE</title>
  </head>

 <body style="background-color:#20c997;">
                
  <h3 style="display:flex;justify-content:center;margin-top:1%;margin-bottom:2%;color:#CD5C5C">RELEVE PARAMETRE CAT1</h3>
<form class="row" method="POST" action="Envoie_parametre1.php">
                        

                
                  <div class="container" style="text-align:center">
                    <table class="table"id="table2">
                      <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Début Coupure</th>
                          <th scope="col">Retour Jirama</th>
                          <th scope="col">Marche GE</th>
                        </tr>
                      </thead>
                      <tbody>                      

                          <tr>

                            <?php
                            require 'parametre_cat1.php';
                            ?>


                            <td> <input type="time" step="0.01" class="form-control" name="Debut_coupure"></td>
                            <td> <input type="time" step="0.01" class="form-control" name="Retour_jirama"> </td>
                            <td> <input type="number" value="<?=$fm['Marche_GE']?>" step="0.01" class="form-control" name="Marche_GE" required="required"> </td>
                            
                          </tr>
                         
                      </tbody>

                      <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Tours minutes</th>
                          <th scope="col">Pression huile</th>
                          <th scope="col">Temp moteur</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['Tours_minutes']?>" step="0.01" class="form-control" name="Tours_minutes" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Pression_huile']?>" step="0.01" class="form-control" name="Pression_huile" required="required"> </td>
                             <td> <input type="number" value="<?=$fm['Temp_moteur']?>" step="0.01" class="form-control" name="Temp_moteur" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                    </div>

                      <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Tension batt</th>
                          <th scope="col">Frequence</th>
                          <th scope="col">Tension U1</th>                          
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['Tension_batt']?>" step="0.01" class="form-control" name="Tension_batt" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Frequence']?>" step="0.01" class="form-control" name="Frequence" required="required"> </td>
                             <td> <input type="number" value="<?=$fm['U1']?>" step="0.01" class="form-control" name="U1" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                      </div>

                       <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Tension U2</th>
                          <th scope="col">Tension U3</th>
                          <th scope="col">Intensité I1</th>
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['U2']?>" step="0.01" class="form-control" name="U2" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['U3']?>" step="0.01" class="form-control" name="U3" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['I1']?>" step="0.01" class="form-control" name="I1" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                      </div>


                         <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Intensité I2</th>
                          <th scope="col">Intensité I3</th>
                          <th scope="col">Cos φ</th>                          
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['I2']?>" step="0.01" class="form-control" name="I2" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['I3']?>" step="0.01" class="form-control" name="I3" required="required"> </td>
                            <td> <input type="number" value="<?=$fm['Cos']?>" step="0.01" class="form-control" name="Cos" required="required"> </td>                                                                       
                          </tr>
                      </tbody>
                      </div>

                        <div class="container-fluid" style="text-align:center">
                        <thead class="thead-dark">
                        <tr class="p-3 mb-2 bg-info text-dark">
                          <th scope="col">Compteur puissance</th>
                          <th scope="col">Observation</th>
                          <th scope="col">TDM</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                          <tr>
                            <td> <input type="number" value="<?=$fm['Compteur_puissance']?>" step="0.01" class="form-control" name="Compteur_puissance" required="required"> </td>
                            <td> <input type="text" step="0.01" class="form-control" name="Observation" required="required"> </td>
                            <td> <input type="text" step="0.01" class="form-control" name="Tdm" required="required"> </td>
                                                                                                 
                          </tr>
                      </tbody>
                      </div>

                  </div> 
                        </tr>
                      
                    </table>  
                  </div> 

                  <div style="margin-bottom: 3%"; class="d-grid gap-2 col-6 mx-auto">
                    
                    <input class="btn btn-secondary active" type="submit"name="button" value="Envoyer"onclick="return myconfirm()"/>


                    <form>
                      <input style="display:flex;justify-content:center" type=button class="btn btn-primary" onclick=window.location.href='http://10.0.3.19:8080/outil_sg/groupes/accueil_groupes.html'; value="< Retour">
                    </form>

                    <script> 
                      function myalert() 
                      {
                        alert('Veuillez confirmer...');   
                      return true;
                      return false;                      
                      }
                    </script>

                  </div>

                 </form> 

                   <font style="display:flex;justify-content:center;margin-top:0%;margin-bottom:0%"; color="blue" size="-3">Lalandy Andriamanga - Méthode Technique - copyright 2023</font>


  </body>

  </html>