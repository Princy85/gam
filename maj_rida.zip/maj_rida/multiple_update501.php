<?php

//multiple_update1.php

include('database_connection.php');

if(isset($_POST['zid']))
{
 $zid = $_POST['zid'];
 $anomalie_fait_panne = $_POST['anomalie_fait_panne'];
 $action_action_prev = $_POST['action_action_prev'];
 $situation = $_POST['situation'];
 $realise = $_POST['realise'];
 $zid = $_POST['zid'];
 for($count = 0; $count < count($zid); $count++)
 {
  $data = array(
   ':zid'   => $zid[$count], 
   ':anomalie_fait_panne'  => $anomalie_fait_panne[$count],
   ':action_action_prev'  => $action_action_prev[$count],
   ':situation'  => $situation[$count], 
   ':realise'  => $realise[$count],  
   ':zid'   => $zid[$count]
  );
  $query = "
  UPDATE rida1
  SET anomalie_fait_panne = :anomalie_fait_panne, action_action_prev = :action_action_prev, situation = :situation, realise = :realise
  WHERE zid = :zid
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}
       
?>
