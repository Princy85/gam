<?php

//multiple_update1.php

include('database_connection.php');

if(isset($_POST['zid']))
{
 $zid = $_POST['zid']; 
 $responsable = $_POST['responsable'];
 $zid = $_POST['zid'];
 for($count = 0; $count < count($zid); $count++)
 {
  $data = array(
   ':zid'   => $zid[$count], 
   ':responsable'  => $responsable[$count],  
   ':zid'   => $zid[$count]
  );
  $query = "
  UPDATE rida1
  SET responsable = :responsable
  WHERE zid = :zid
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}
       
?>
