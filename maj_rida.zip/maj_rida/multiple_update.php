<?php

//multiple_update1.php

include('database_connection.php');

if(isset($_POST['zid']))
{
 $zid = $_POST['zid'];
 $situation = $_POST['situation'];
 $realise = $_POST['realise'];
 $zid = $_POST['zid'];
 for($count = 0; $count < count($zid); $count++)
 {
  $data = array(
   ':zid'   => $zid[$count],   
   ':situation'  => $situation[$count], 
   ':realise'  => $realise[$count],  
   ':zid'   => $zid[$count]
  );
  $query = "
  UPDATE rida1
  SET situation = :situation, realise = :realise
  WHERE zid = :zid
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}
       
?>
