
<html>  
    <head>  
        <title>MAJ RIDA</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
          
    </head>  
    <body>  
        <div class="container-fluid">  
            <br />
   <div class="table-responsive">  
    <h3 align="center">Mise à jour RIDA - Support Technique </h3><br />
    <form method="post" id="update_form">

                    <div align="left">
                        <input type="submit" name="multiple_update" id="multiple_update" class="btn btn-info" value="Envoyer" />
                    </div>
                    <br />


                    <div class="container-fluid" style="margin-bottom: 30px;">
                        <input class="form-control" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search">
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered border-succes table-striped">
                            <thead>
                                <th width="1%"></th>
                                <th width="5%">N° RIDA</th>
                                <th width="10%">date</th>
                                <th width="10%">date_T</th>
                                
                                
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
    </form>
   </div>  
  </div>
  
<script>  
$(document).ready(function(){  
    
    function fetch_data()
    {
        $.ajax({
            url:"select.php",
            method:"POST",
            dataType:"json",
            success:function(data)
            {
                var html = '';
                for(var count = 0; count < data.length; count++)
                {
                    html += '<tr>';
                    html += '<td><input type="checkbox" data-id="'+data[count].id+'" data-date="'+data[count].date+'" data-uap="'+data[count].uap+'" data-ligne="'+data[count].ligne+'" data-machine="'+data[count].machine+'" data-organe="'+data[count].organe+'" data-theme_origine="'+data[count].theme_origine+'" data-anomalie_fait_panne="'+data[count].anomalie_fait_panne+'" data-cause="'+data[count].cause+'" data-action_action_prev="'+data[count].action_action_prev+'" data-delai="'+data[count].delai+'" data-ref="'+data[count].ref+'" data-code_x3="'+data[count].code_x3+'" data-qte="'+data[count].qte+'" data-responsable="'+data[count].responsable+'" data-tdm="'+data[count].tdm+'" data-heure_panne="'+data[count].heure_panne+'" data-solution_tech="'+data[count].solution_tech+'" data-situation="'+data[count].situation+'" data-realise="'+data[count].realise+'" class="check_box"/></td>';
                    
                    html += '<td contenteditable="true" class="item_name">'+data[count].id+'</td>';                   
                    html += '<td contenteditable="true" class="item_name">'+data[count].date+'</td>';
                    html += '<td contenteditable="true" class="item_name">'+data[count].realise+'</td>';
                    

                }
                $('tbody').html(html);
            }
        });
    }

    fetch_data();

    $(document).on('click', '.check_box', function(){
        var html = '';
        if(this.checked)
        {
            html = '<td><input type="checkbox" data-id="'+$(this).data('id')+'" data-date="'+$(this).data('date')+'" data-uap="'+$(this).data('uap')+'" data-ligne="'+$(this).data('ligne')+'" data-machine="'+$(this).data('machine')+'" data-organe="'+$(this).data('organe')+'" data-theme_origine="'+$(this).data('theme_origine')+'" data-anomalie_fait_panne="'+$(this).data('anomalie_fait_panne')+'" data-cause="'+$(this).data('cause')+'" data-action_action_prev="'+$(this).data('action_action_prev')+'" data-delai="'+$(this).data('delai')+'" data-ref="'+$(this).data('ref')+'" data-code_x3="'+$(this).data('code_x3')+'" data-qte="'+$(this).data('qte')+'" data-responsable="'+$(this).data('responsable')+'" data-tdm="'+$(this).data('tdm')+'" data-heure_panne="'+$(this).data('heure_panne')+'" data-solution_tech="'+$(this).data('solution_tech')+'" data-situation="'+$(this).data('situation')+'" data-realise="'+$(this).data('realise')+'" class="check_box" checked/></td>';
           
            html += '<td><input type="text" name="id[]" class="form-control" value="'+$(this).data("id")+'" readonly/></td>';            
            html += '<td><input type="text" name="date[]" class="form-control" value="'+$(this).data("date")+'" readonly/></td>';
            html += '<td><input type="text" name="realise[]" class="form-control" value="'+$(this).data('realise')+'" readonly/></td>';
            
        }
        else
        {
            html = '<td><input type="checkbox" data-id="'+$(this).data('id')+'" data-date="'+$(this).data('date')+'" data-uap="'+$(this).data('uap')+'" data-ligne="'+$(this).data('ligne')+'" data-machine="'+$(this).data('machine')+'" data-organe="'+$(this).data('organe')+'" data-theme_origine="'+$(this).data('theme_origine')+'" data-anomalie_fait_panne="'+$(this).data('anomalie_fait_panne')+'" data-cause="'+$(this).data('cause')+'" data-action_action_prev="'+$(this).data('action_action_prev')+'" data-delai="'+$(this).data('delai')+'" data-ref="'+$(this).data('ref')+'" data-code_x3="'+$(this).data('code_x3')+'" data-qte="'+$(this).data('qte')+'" data-responsable="'+$(this).data('responsable')+'" data-tdm="'+$(this).data('tdm')+'" data-heure_panne="'+$(this).data('heure_panne')+'" data-solution_tech="'+$(this).data('solution_tech')+'" data-situation="'+$(this).data('situation')+'" data-realise="'+$(this).data('realise')+'" class="check_box" /></td>';
            
            html += '<td>'+$(this).data('id')+'</td>';          
            html += '<td>'+$(this).data('date')+'</td>';
            html += '<td>'+$(this).data('realise')+'</td>';
                       
        }
        $(this).closest('tr').html(html);
        $('#id'+$(this).data('id')+'').val($(this).data('id'));
    });

    $('#update_form').on('submit', function(event){
        event.preventDefault();
        if($('.check_box:checked').length > 0)
        {
            $.ajax({
                url:"multiple_update.php",
                method:"POST",
                data:$(this).serialize(),
                success:function()
                {
                    alert('Valider?');
                    fetch_data();
                }
            })
        }
    });

});  
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

<script> 
        function myFunction() {
          // script filtre
          var input, filter, table, th, td, i, txtValue;
          input = document.getElementById("myInput");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");

          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[3];

            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }

    </script>
    </body>  
</html>