<?php

//multiple_update.php

include('database_connection.php');

if(isset($_POST['id']))
{

$id = $_POST['id'];
$responsable = $_POST['responsable'];
$id = $_POST['id'];
 
 
 for($count = 0; $count < count($id); $count++)
 {
  $data = array(
  
   ':responsable'   => $responsable[$count]  
  
   
);
   

  $query = "
  UPDATE rida1 
  SET responsable= :responsable
  WHERE id = :id";

  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}

?>
