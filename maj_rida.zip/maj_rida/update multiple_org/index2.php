
<html>  
    <head>  
        <title>MAJ RIDA</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
          
    </head>  
    <body>  
        <div class="container-fluid">  
            <br />
   <div class="table-responsive">  
    <h3 align="center">Mise à jour RIDA - Support Technique </h3><br />
    <form method="post" id="update_form">

                    <div align="left">
                        <input type="submit" name="multiple_update" id="multiple_update" class="btn btn-info" value="Multiple Update"/>
                       
                    </div>
                    <br/>

      
                    <div class="container-fluid" style="margin-bottom: 20px;">
                        <input class="form-control" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search">            
                       
                    </div>

                    <div >                        
                            <table class="table table-bordered table-striped" id="myTable">
                          
                            <thead>
                                <tr>
                                    <th width="1%"></th>
                                    <th width="10%">N°RIDA</th>
                                    <th width="20%">UAP</th>

                            </thead>                                           
                    </div>
                </form>
   </div>  
<tbody>

  
<script>  
$(document).ready(function(){  
    
    function fetch_data()
    {
        $.ajax({
            url:"select2.php",
            method:"POST",
            dataType:"json",
            success:function(data)
            {
                var html = '';
                for(var count = 0; count < data.length; count++)
                {
                    html += '<tr>';
                    html += '<td><input type="checkbox" vid="'+data[count].vid+'" data-vid="'+data[count].vid+'" data-uap="'+data[count].uap+'" class="check_box"  /></td>';
                    html += '<td>'+data[count].vid+'</td>';
                    html += '<td>'+data[count].uap+'</td>';
                    
                }
                $('tbody').html(html);
            }
        });
    }

    fetch_data();

    $(document).on('click', '.check_box', function(){
        var html = '';
        if(this.checked)
        {
            html = '<td><input type="checkbox" vid="'+$(this).attr('vid')+'" data-vid="'+$(this).data('vid')+'" data-responsable="'+$(this).data('responsable')+'" class="check_box" checked /></td>';
            html += '<td><input type="text" name="vid[]" class="form-control" value="'+$(this).data("vid")+'" readonly/></td>';
            html += '<td><input type="text" name="uap[]" class="form-control" value="'+$(this).data("uap")+'"/></td>';
            
        }
        else
        {
            html = '<td><input type="checkbox" vid="'+$(this).attr('vid')+'" data-vid="'+$(this).data('vid')+'" data-uap="'+$(this).data('uap')+'" class="check_box" /></td>';
            html += '<td>'+$(this).data('vid')+'</td>';
            html += '<td>'+$(this).data('uap')+'</td>';
         
        }
        $(this).closest('tr').html(html);
        $('#vid_'+$(this).attr('vid')+'').val($(this).data('vid'));
    });

    $('#update_form').on('submit', function(event){
        event.preventDefault();
        if($('.check_box:checked').length > 0)
        {
            $.ajax({
                url:"multiple_update2.php",
                method:"POST",
                data:$(this).serialize(),
                success:function()
                {
                    alert('Data Updated');
                    fetch_data();
                }
            })
        }
    });

});
</script>

   <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

</table>
    <script> 
        function myFunction() {
          // script filtre
          var input, filter, table, th, td, i, txtValue;
          input = document.getElementById("myInput");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");

          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[2];

            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }

    </script>



</body>
</html>