<?php

//multiple_update1.php

include('database_connection2.php');

if(isset($_POST['vid']))
{
 $vid = $_POST['vid']; 
 $uap = $_POST['uap'];
 $vid = $_POST['vid'];
 for($count = 0; $count < count($vid); $count++)
 {
  $data = array(
   ':vid'   => $vid[$count],
   ':uap'  => $uap[$count],
   ':vid'   => $vid[$count]
  );
  $query = "
  UPDATE ridaa
  SET uap = :uap
  WHERE vid = :vid
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}

?>
