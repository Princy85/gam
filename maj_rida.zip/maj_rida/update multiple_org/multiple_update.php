<?php

//multiple_update.php

include('database_connection.php');

if(isset($_POST['hidden_id']))
{
 $name = $_POST['name'];
 $uap = $_POST['uap'];
 $ligne = $_POST['ligne'];
 $machine = $_POST['machine'];
 $organe = $_POST['organe'];
 $id = $_POST['hidden_id'];
 for($count = 0; $count < count($id); $count++)
 {
  $data = array(
   ':name'   => $name[$count],
   ':uap'  => $uap[$count],
   ':ligne'  => $ligne[$count],
   ':machine' => $machine[$count],
   ':organe'   => $organe[$count],
   ':id'   => $id[$count]
  );
  $query = "
  UPDATE rida 
  SET name = :name, uap = :uap, ligne = :ligne, machine = :machine, organe = :organe 
  WHERE id = :id
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}

?>
