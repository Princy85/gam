
<html>  
    <head>  
        <title>MAJ RIDA</title>
  <script src="http://10.0.3.19:8080/64-etat_panne/js/jquery.min.js"></script>
        <link rel="stylesheet" href="http://10.0.3.19:8080/css/bootstrap.min.css"/>  
        <script src="http://10.0.3.19:8080/64-etat_panne/js/bootstrap.min.js"></script>  
          
    </head>  
    <body>  
        <div class="container-fluid">  
            <br />
   <div class="table-responsive">  
    <h3 class="text-center fst-italic text-primary font-bold" align="center">MISE A JOUR RIDA MAINTENANCE</h3><br/>
    <form method="post" id="update_form">

                    <div align="left">
                        <input type="submit" name="multiple_update" id="multiple_update" class="btn btn-info center" value="Envoyer" style="margin-left: 900px;"/>                       
                    </div>
                    <br/>

      
                   <div class="form-group" style="margin-left: 750px;">
                       <input  class="col p-2 mb-2 bg-secondary text-white" type="text" id="myInput" onkeyup="myFunction1()" placeholder="Search SERVICE">

                       <input style="margin-left: 10px;" class="col p-2 mb-2 bg-success text-white" id="txtInputList" onkeyup="myFunction2()" type="text" placeholder="Search LIGNES">    

                       <input style="margin-left: 10px;" class="col p-2 mb-2 bg-success text-white" id="dates" onkeyup="searchDate()" type="text" placeholder="Search LIGNES">
                       <input style="margin-left: 10px;" class="col p-2 mb-2 bg-success text-white" id="dates" onkeyup="searchDate()" type="text" placeholder="Search LIGNES">                         
                       
                        </div>

                    <div>  

                    <p class="text-center fst-italic text-danger font-bold">Selectionner toutes les actions Terminées puis cliquer sur "Envoyer"</p>

                            <table class="table table-bordered table-striped" id="myTable">                          
                            <thead>
                                <tr>
                                <th class="text-center" width="1%"></th>
                                <th class="text-center" width="5%">N°RIDA</th>
                                <th class="text-center" width="5%">DATE</th>
                                <th class="text-center" width="5%">UAP</th>
                                <th class="text-center" width="5%">LIGNES</th>
                                <th class="text-center" width="10%">MACHINES</th>
                                <th class="text-center" width="15%">ACTIONS PREVENTIVES</th>
                                <th class="text-center" width="5%">DELAIS</th>
                                <th class="text-center" width="5%">RESPONSABLES</th>                
                                <th class="text-center" width="5%">DUREE PANNE</th>          
                                <th class="text-center" width="5%">SITUATIONS</th>
                                <th class="text-center" width="5%">DATE DE CLOTURE</th>                                                             
                            </thead>                                           
                    </div>
                </form>
              
   </div>

<tbody>

  
<script>  
$(document).ready(function(){  
    
    function fetch_data()
    {
        $.ajax({
            url:"select5.php",
            method:"POST",
            dataType:"json",
            success:function(data)
            {
                var html = '';
                for(var count = 0; count < data.length; count++)
                {
                    html += '<tr>';
                    html += '<td><input type="checkbox" zid="'+data[count].zid+'" data-zid="'+data[count].zid+'" data-dates="'+data[count].dates+'" data-uap="'+data[count].uap+'" data-ligne="'+data[count].ligne+'" data-machine="'+data[count].machine+'" data-organe="'+data[count].organe+'" data-theme_origine="'+data[count].theme_origine+'" data-anomalie_fait_panne="'+data[count].anomalie_fait_panne+'" data-cause="'+data[count].cause+'" data-action_action_prev="'+data[count].action_action_prev+'" data-delai="'+data[count].delai+'" data-ref="'+data[count].ref+'" data-code_x3="'+data[count].code_x3+'" data-qte="'+data[count].qte+'" data-responsable="'+data[count].responsable+'" data-tdm="'+data[count].tdm+'" data-heure_panne="'+data[count].heure_panne+'" data-situation="'+data[count].situation+'" data-realise="'+data[count].realise+'" class="check_box"  /></td>';

                    html += '<td>'+data[count].zid+'</td>';
                    html += '<td>'+data[count].dates+'</td>';
                    html += '<td>'+data[count].uap+'</td>';
                    html += '<td>'+data[count].ligne+'</td>';
                    html += '<td>'+data[count].machine+'</td>';
                    html += '<td>'+data[count].action_action_prev+'</td>';
                    html += '<td>'+data[count].delai+'</td>';
                    html += '<td>'+data[count].responsable+'</td>';
                    html += '<td>'+data[count].heure_panne+'</td>';
                    html += '<td>'+data[count].situation+'</td>';
                    html += '<td>'+data[count].realise+'</td>';
                    
                    
                }
                $('tbody').html(html);
            }
        });
    }

    fetch_data();

    $(document).on('click', '.check_box', function(){
        var html = '';
        if(this.checked)
        {
            html = '<td><input type="checkbox" zid="'+$(this).attr('zid')+'" data-zid="'+$(this).data('zid')+'" data-dates="'+$(this).data('dates')+'" data-uap="'+$(this).data('uap')+'" data-ligne="'+$(this).data('ligne')+'" data-machine="'+$(this).data('machine')+'" data-organe="'+$(this).data('organe')+'" data-theme_origine="'+$(this).data('theme_origine')+'" data-anomalie_fait_panne="'+$(this).data('anomalie_fait_panne')+'" data-cause="'+$(this).data('cause')+'" data-action_action_prev="'+$(this).data('action_action_prev')+'" data-delai="'+$(this).data('delai')+'" data-ref="'+$(this).data('ref')+'" data-code_x3="'+$(this).data('code_x3')+'" data-qte="'+$(this).data('qte')+'" data-responsable="'+$(this).data('responsable')+'" data-tdm="'+$(this).data('tdm')+'" data-heure_panne="'+$(this).data('heure_panne')+'" data-solution_tech="'+$(this).data('solution_tech')+'" data-situation="'+$(this).data('situation')+'" data-realise="'+$(this).data('realise')+'" class="check_box" checked /></td>';
            
            html += '<td><input type="text" name="zid[]" class="form-control" value="'+$(this).data("zid")+'" readonly/></td>';
            html += '<td><input type="text" name="dates[]" class="form-control" value="'+$(this).data("dates")+'" readonly/></td>';
            html += '<td><input type="text" name="uap[]" class="form-control" value="'+$(this).data("uap")+'" readonly/></td>';
            html += '<td><input type="text" name="ligne[]" class="form-control" value="'+$(this).data("ligne")+'" readonly/></td>';
            html += '<td><input type="text" name="machine[]" class="form-control" value="'+$(this).data("machine")+'" readonly/></td>';
            html += '<td><input type="text" name="action_action_prev[]" class="form-control" value="'+$(this).data("action_action_prev")+'" readonly/></td>';
            html += '<td><input type="text" name="delai[]" class="form-control" value="'+$(this).data("delai")+'"readonly/></td>';
            html += '<td><input type="text" name="responsable[]" class="form-control" value="'+$(this).data("responsable")+'"/></td>';
            html += '<td><input type="text" name="heure_panne[]" class="form-control" value="'+$(this).data("heure_panne")+'" readonly/></td>';
            html += '<td><select name="situation[]" id="situation'+$(this).attr('id')+'" class="form-control"><option value="0">T</option></select></td>';
            html += '<td><input type="text" name="realise[]" class="form-control" value="'+$(this).data("realise")+'" readonly/></td>';
        }
        else
        {
            html = '<td><input type="checkbox" zid="'+$(this).attr('zid')+'" data-zid="'+$(this).data('zid')+'" data-dates="'+$(this).data('dates')+'" data-uap="'+$(this).data('uap')+'" data-ligne="'+$(this).data('ligne')+'" data-machine="'+$(this).data('machine')+'" data-organe="'+$(this).data('organe')+'" data-theme_origine="'+$(this).data('theme_origine')+'" data-anomalie_fait_panne="'+$(this).data('anomalie_fait_panne')+'" data-cause="'+$(this).data('cause')+'" data-action_action_prev="'+$(this).data('action_action_prev')+'" data-delai="'+$(this).data('delai')+'" data-ref="'+$(this).data('ref')+'" data-code_x3="'+$(this).data('code_x3')+'" data-qte="'+$(this).data('qte')+'" data-responsable="'+$(this).data('responsable')+'" data-tdm="'+$(this).data('tdm')+'" data-heure_panne="'+$(this).data('heure_panne')+'" data-solution_tech="'+$(this).data('solution_tech')+'" data-situation="'+$(this).data('situation')+'" data-realise="'+$(this).data('realise')+'" class="check_box" /></td>';
           
            html += '<td>'+$(this).data('zid')+'</td>';
            html += '<td>'+$(this).data('dates')+'</td>';
            html += '<td>'+$(this).data('uap')+'</td>';
            html += '<td>'+$(this).data('ligne')+'</td>';
            html += '<td>'+$(this).data('machine')+'</td>';
            html += '<td>'+$(this).data('action_action_prev')+'</td>';
            html += '<td>'+$(this).data('delai')+'</td>';
            html += '<td>'+$(this).data('responsable')+'</td>';
            html += '<td>'+$(this).data('heure_panne')+'</td>';
            html += '<td>'+$(this).data('situation')+'</td>';
            html += '<td>'+$(this).data('realise')+'</td>';

         
        }
        $(this).closest('tr').html(html);
        $('#zid_'+$(this).attr('zid')+'').val($(this).data('zid'));
    });

    $('#update_form').on('submit', function(event){
        event.preventDefault();
        if($('.check_box:checked').length > 0)
        {
            $.ajax({
                url:"multiple_update5.php",
                method:"POST",
                data:$(this).serialize(),
                success:function()
                {
                    alert('Etes vous sûr de vouloir clôturer les actions?');
                    fetch_data();
                }
            })
        }
    });

});
</script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>
</table>
    <script> 
        function myFunction1() {
          // script filtre
          var input, filter, table, th, td, i, txtValue;
          input = document.getElementById("myInput");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");

          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[3];

            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }
    </script>

        <script> 
        function myFunction2() {
          // script filtre
          var input, filter, table, th, td, i, txtValue;
          input = document.getElementById("txtInputList");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");

          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[4];

            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }
    </script>

<script>
function searchDate() {
    var input_startDate, input_stopDate, tr, i;
  // get the values and convert to date
  input_startDate =  new Date(document.getElementById("dates").value);
  input_stopDate =  new Date(document.getElementById("dates").value);
      filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");

          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[4];

            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }
</script>


</body>
</html>