<?php

//multiple_update1.php

include('database_connection.php');

if(isset($_POST['zid']))
{
 $zid = $_POST['zid'];
 $delai = $_POST['delai'];
 

 $zid = $_POST['zid'];
 for($count = 0; $count < count($zid); $count++)
 {
  $data = array(
   ':zid'   => $zid[$count], 
   ':delai'  => $delai[$count],
  
    
   ':zid'   => $zid[$count]
  );
  $query = "
  UPDATE rida1
  SET delai = :delai
  WHERE zid = :zid
  ";
  $statement = $connect->prepare($query);
  $statement->execute($data);
 }
}
       
?>
